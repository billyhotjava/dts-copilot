{{ config(materialized='view', tags=['xycyl', 'xycyl-flowerbiz', 'stg', 'flowerbiz_main']) }}

-- 报花单主表 STG：仅做类型转换 + 占位符归 NULL + 字段改名 + 软删过滤。
-- 禁止 CASE WHEN / 别名翻译 / 派生布尔 / 月份格式化 — 这些下沉 DWD。

SELECT
  o.id::bigint                                                                AS source_row_id,
  'ods_flower_biz_info'::text                                                 AS source_table,
  COALESCE({{ nullif_placeholder("o.source_system") }}, 'rs_cloud_flower')    AS source_system,
  o.imported_at                                                               AS imported_at,

  o.id::bigint                                                                AS biz_id,
  {{ nullif_placeholder("o.code") }}                                          AS biz_code,

  {{ nullif_placeholder("o.biz_type") }}                                      AS biz_type_raw,
  {{ nullif_placeholder("o.status") }}                                        AS status_raw,

  {{ parse_numeric_safe("o.project_id") }}::bigint                            AS project_id,
  {{ parse_numeric_safe("o.customer_id") }}::bigint                           AS customer_id,
  {{ parse_numeric_safe("o.apply_user_id") }}::bigint                         AS apply_user_id,
  {{ nullif_placeholder("o.apply_user_name") }}                               AS apply_user_name,
  {{ parse_numeric_safe("o.examine_user_id") }}::bigint                       AS examine_user_id,
  {{ parse_numeric_safe("o.sign_user_id") }}::bigint                          AS sign_user_id,
  {{ parse_numeric_safe("o.curing_user_id") }}::bigint                        AS curing_user_id,
  {{ nullif_placeholder("o.curing_user_name") }}                              AS curing_user_name,
  {{ parse_numeric_safe("o.project_manager_id") }}::bigint                    AS project_manager_id,
  {{ nullif_placeholder("o.project_manager_name") }}                          AS project_manager_name,

  {{ parse_numeric_safe("o.biz_total_rent") }}                                AS biz_total_rent,
  {{ parse_numeric_safe("o.biz_total_cost") }}                                AS biz_total_cost,
  {{ parse_numeric_safe("o.total_amount") }}                                  AS total_amount,
  {{ parse_numeric_safe("o.lease_term") }}::int                               AS lease_term,

  {{ parse_date_safe("o.apply_time") }}                                       AS apply_time,
  {{ parse_date_safe("o.plan_finish_time") }}                                 AS plan_finish_time,
  {{ parse_date_safe("o.settlement_time") }}                                  AS settlement_time,
  {{ parse_date_safe("o.finish_time") }}                                      AS finish_time,
  {{ parse_date_safe("o.start_lease_time") }}                                 AS start_lease_time,
  {{ parse_date_safe("o.end_lease_time") }}                                   AS end_lease_time,

  {{ nullif_placeholder("o.remark") }}                                        AS remark,
  {{ parse_date_safe("o.create_time") }}                                      AS created_date,
  {{ parse_date_safe("o.update_time") }}                                      AS updated_date

FROM {{ source('xycyl_ods', 'flower_biz_info') }} o
WHERE COALESCE(o.del_flag, '0') = '0'
