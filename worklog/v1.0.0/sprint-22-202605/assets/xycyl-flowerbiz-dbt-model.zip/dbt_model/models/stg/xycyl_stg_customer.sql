{{ config(materialized='view', tags=['xycyl', 'xycyl-flowerbiz', 'stg', 'customer']) }}

SELECT
  o.id::bigint                                                                AS source_row_id,
  'ods_customer'::text                                                        AS source_table,
  COALESCE({{ nullif_placeholder("o.source_system") }}, 'rs_cloud_flower')    AS source_system,
  o.imported_at                                                               AS imported_at,

  o.id::bigint                                                                AS customer_id,
  {{ nullif_placeholder("o.code") }}                                          AS customer_code,
  {{ nullif_placeholder("o.name") }}                                          AS customer_name,
  {{ nullif_placeholder("o.customer_type") }}                                 AS customer_type_raw

FROM {{ source('xycyl_ods', 'customer') }} o
WHERE COALESCE(o.del_flag, '0') = '0'
