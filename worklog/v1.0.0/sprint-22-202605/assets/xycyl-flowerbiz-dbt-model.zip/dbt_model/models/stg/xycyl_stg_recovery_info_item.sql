{{ config(materialized='view', tags=['xycyl', 'xycyl-flowerbiz', 'stg', 'recovery_item']) }}

SELECT
  o.id::bigint                                                                AS source_row_id,
  'ods_recovery_info_item'::text                                              AS source_table,
  COALESCE({{ nullif_placeholder("o.source_system") }}, 'rs_cloud_flower')    AS source_system,
  o.imported_at                                                               AS imported_at,

  o.id::bigint                                                                AS recovery_item_id,
  {{ parse_numeric_safe("o.recovery_info_id") }}::bigint                      AS recovery_id,
  {{ parse_numeric_safe("o.biz_item_id") }}::bigint                           AS biz_item_id,

  {{ parse_numeric_safe("o.good_id") }}::bigint                               AS good_id,
  {{ nullif_placeholder("o.good_name") }}                                     AS good_name,

  {{ nullif_placeholder("o.recovery_type") }}                                 AS recovery_type_raw,

  {{ parse_numeric_safe("o.recovery_number") }}::int                          AS recovery_number,
  {{ parse_numeric_safe("o.real_recovery_number") }}::int                     AS real_recovery_number,
  {{ parse_numeric_safe("o.good_cost") }}                                     AS good_cost,

  {{ parse_date_safe("o.create_time") }}                                      AS created_date,
  {{ parse_date_safe("o.update_time") }}                                      AS updated_date

FROM {{ source('xycyl_ods', 'recovery_info_item') }} o
WHERE COALESCE(o.del_flag, '0') = '0'
