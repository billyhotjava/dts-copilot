{{ config(materialized='view', tags=['xycyl', 'xycyl-flowerbiz', 'stg', 'rent_time_log']) }}

SELECT
  o.id::bigint                                                                AS source_row_id,
  'ods_flower_rent_time_log'::text                                            AS source_table,
  COALESCE({{ nullif_placeholder("o.source_system") }}, 'rs_cloud_flower')    AS source_system,
  o.imported_at                                                               AS imported_at,

  o.id::bigint                                                                AS log_id,
  {{ parse_numeric_safe("o.biz_id") }}::bigint                                AS biz_id,

  {{ nullif_placeholder("o.rent_time_type") }}                                AS rent_time_type_raw,

  {{ parse_date_safe("o.old_rent_time") }}                                    AS old_rent_time,
  {{ parse_date_safe("o.new_rent_time") }}                                    AS new_rent_time,

  {{ parse_numeric_safe("o.change_user_id") }}::bigint                        AS change_user_id,
  {{ nullif_placeholder("o.change_user_name") }}                              AS change_user_name,
  {{ nullif_placeholder("o.change_reason") }}                                 AS change_reason,

  {{ parse_date_safe("o.create_time") }}                                      AS created_date,
  {{ parse_date_safe("o.update_time") }}                                      AS updated_date

FROM {{ source('xycyl_ods', 'flower_rent_time_log') }} o
WHERE COALESCE(o.del_flag, '0') = '0'
