{{ config(materialized='view', tags=['xycyl', 'xycyl-flowerbiz', 'stg', 'change']) }}

SELECT
  o.id::bigint                                                                AS source_row_id,
  'ods_change_info'::text                                                     AS source_table,
  COALESCE({{ nullif_placeholder("o.source_system") }}, 'rs_cloud_flower')    AS source_system,
  o.imported_at                                                               AS imported_at,

  o.id::bigint                                                                AS change_id,
  {{ nullif_placeholder("o.code") }}                                          AS change_code,
  {{ parse_numeric_safe("o.biz_id") }}::bigint                                AS biz_id,

  {{ nullif_placeholder("o.change_type") }}                                   AS change_type_raw,
  {{ nullif_placeholder("o.status") }}                                        AS status_raw,

  {{ parse_numeric_safe("o.before_total_amount") }}                           AS before_total_amount,
  {{ parse_numeric_safe("o.after_total_amount") }}                            AS after_total_amount,
  {{ parse_date_safe("o.before_settlement_time") }}                           AS before_settlement_time,
  {{ parse_date_safe("o.after_settlement_time") }}                            AS after_settlement_time,

  {{ nullif_placeholder("o.change_reason") }}                                 AS change_reason,
  {{ parse_numeric_safe("o.change_user_id") }}::bigint                        AS change_user_id,
  {{ parse_date_safe("o.change_time") }}                                      AS change_time,

  {{ parse_date_safe("o.create_time") }}                                      AS created_date,
  {{ parse_date_safe("o.update_time") }}                                      AS updated_date

FROM {{ source('xycyl_ods', 'change_info') }} o
WHERE COALESCE(o.del_flag, '0') = '0'
