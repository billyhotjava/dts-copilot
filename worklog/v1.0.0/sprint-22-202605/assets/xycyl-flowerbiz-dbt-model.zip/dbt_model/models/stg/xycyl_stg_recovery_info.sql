{{ config(materialized='view', tags=['xycyl', 'xycyl-flowerbiz', 'stg', 'recovery']) }}

SELECT
  o.id::bigint                                                                AS source_row_id,
  'ods_recovery_info'::text                                                   AS source_table,
  COALESCE({{ nullif_placeholder("o.source_system") }}, 'rs_cloud_flower')    AS source_system,
  o.imported_at                                                               AS imported_at,

  o.id::bigint                                                                AS recovery_id,
  {{ nullif_placeholder("o.code") }}                                          AS recovery_code,
  {{ parse_numeric_safe("o.biz_info_id") }}::bigint                           AS biz_id,

  {{ parse_numeric_safe("o.distribution_user_id") }}::bigint                  AS distribution_user_id,
  {{ parse_numeric_safe("o.recovery_user_id") }}::bigint                      AS recovery_user_id,
  {{ nullif_placeholder("o.recovery_user_name") }}                            AS recovery_user_name,
  {{ parse_numeric_safe("o.store_house_id") }}::bigint                        AS store_house_id,
  {{ nullif_placeholder("o.store_house_name") }}                              AS store_house_name,

  {{ nullif_placeholder("o.status") }}                                        AS status_raw,

  {{ parse_date_safe("o.plan_recovery_time") }}                               AS plan_recovery_time,
  {{ parse_date_safe("o.recovery_time") }}                                    AS recovery_time,

  {{ parse_date_safe("o.create_time") }}                                      AS created_date,
  {{ parse_date_safe("o.update_time") }}                                      AS updated_date

FROM {{ source('xycyl_ods', 'recovery_info') }} o
WHERE COALESCE(o.del_flag, '0') = '0'
