{{ config(materialized='view', tags=['xycyl', 'xycyl-flowerbiz', 'stg', 'flowerbiz_item']) }}

SELECT
  o.id::bigint                                                                AS source_row_id,
  'ods_flower_biz_item'::text                                                 AS source_table,
  COALESCE({{ nullif_placeholder("o.source_system") }}, 'rs_cloud_flower')    AS source_system,
  o.imported_at                                                               AS imported_at,

  o.id::bigint                                                                AS biz_item_id,
  {{ parse_numeric_safe("o.flower_biz_id") }}::bigint                         AS flower_biz_id,
  {{ parse_numeric_safe("o.position_id") }}::bigint                           AS position_id,
  {{ nullif_placeholder("o.position_name") }}                                 AS position_name,

  {{ nullif_placeholder("o.biz_type") }}                                      AS biz_type_raw,
  {{ nullif_placeholder("o.status") }}                                        AS status_raw,

  {{ parse_numeric_safe("o.good_id") }}::bigint                               AS good_id,
  {{ parse_numeric_safe("o.good_price_id") }}::bigint                         AS good_price_id,
  {{ nullif_placeholder("o.good_name") }}                                     AS good_name,
  {{ nullif_placeholder("o.spec_name") }}                                     AS spec_name,

  {{ parse_numeric_safe("o.plant_number") }}::int                             AS plant_number,
  {{ parse_numeric_safe("o.rent") }}                                          AS rent,
  {{ parse_numeric_safe("o.cost") }}                                          AS cost,
  {{ parse_numeric_safe("o.amount") }}                                        AS amount,

  {{ parse_date_safe("o.put_time") }}                                         AS put_time,
  {{ parse_date_safe("o.start_time") }}                                       AS start_time,
  {{ parse_date_safe("o.end_time") }}                                         AS end_time,

  {{ parse_numeric_safe("o.net_receipts_number") }}::int                      AS net_receipts_number,
  {{ parse_numeric_safe("o.frm_loss_number") }}::int                          AS frm_loss_number,
  {{ parse_numeric_safe("o.buyback_number") }}::int                           AS buyback_number,
  {{ parse_numeric_safe("o.keep_number") }}::int                              AS keep_number,

  {{ parse_date_safe("o.create_time") }}                                      AS created_date,
  {{ parse_date_safe("o.update_time") }}                                      AS updated_date

FROM {{ source('xycyl_ods', 'flower_biz_item') }} o
WHERE COALESCE(o.del_flag, '0') = '0'
