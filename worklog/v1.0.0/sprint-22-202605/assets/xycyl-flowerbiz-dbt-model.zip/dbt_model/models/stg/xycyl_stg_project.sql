{{ config(materialized='view', tags=['xycyl', 'xycyl-flowerbiz', 'stg', 'project']) }}

SELECT
  o.id::bigint                                                                AS source_row_id,
  'ods_project'::text                                                         AS source_table,
  COALESCE({{ nullif_placeholder("o.source_system") }}, 'rs_cloud_flower')    AS source_system,
  o.imported_at                                                               AS imported_at,

  o.id::bigint                                                                AS project_id,
  {{ nullif_placeholder("o.code") }}                                          AS project_code,
  {{ nullif_placeholder("o.name") }}                                          AS project_name,
  {{ parse_numeric_safe("o.customer_id") }}::bigint                           AS customer_id,
  {{ nullif_placeholder("o.customer_name") }}                                 AS customer_name,
  {{ parse_numeric_safe("o.project_manager_id") }}::bigint                    AS project_manager_id,
  {{ nullif_placeholder("o.project_manager_name") }}                          AS project_manager_name,
  {{ nullif_placeholder("o.status") }}                                        AS project_status_raw

FROM {{ source('xycyl_ods', 'project') }} o
WHERE COALESCE(o.del_flag, '0') = '0'
