{{ config(materialized='view', tags=['xycyl', 'xycyl-flowerbiz', 'stg', 'flowerbiz_item_detailed']) }}

SELECT
  o.id::bigint                                                                AS source_row_id,
  'ods_flower_biz_item_detailed'::text                                        AS source_table,
  COALESCE({{ nullif_placeholder("o.source_system") }}, 'rs_cloud_flower')    AS source_system,
  o.imported_at                                                               AS imported_at,

  o.id::bigint                                                                AS biz_item_detail_id,
  {{ parse_numeric_safe("o.flower_biz_item_id") }}::bigint                    AS flower_biz_item_id,
  {{ parse_numeric_safe("o.project_green_item_id") }}::bigint                 AS project_green_item_id,
  {{ parse_numeric_safe("o.position_id") }}::bigint                           AS position_id,
  {{ parse_numeric_safe("o.good_id") }}::bigint                               AS good_id,
  {{ nullif_placeholder("o.good_name") }}                                     AS good_name,

  {{ parse_numeric_safe("o.plant_number") }}::int                             AS plant_number,
  {{ parse_numeric_safe("o.rent") }}                                          AS rent,
  {{ parse_numeric_safe("o.cost") }}                                          AS cost,

  {{ parse_date_safe("o.create_time") }}                                      AS created_date,
  {{ parse_date_safe("o.update_time") }}                                      AS updated_date

FROM {{ source('xycyl_ods', 'flower_biz_item_detailed') }} o
WHERE COALESCE(o.del_flag, '0') = '0'
