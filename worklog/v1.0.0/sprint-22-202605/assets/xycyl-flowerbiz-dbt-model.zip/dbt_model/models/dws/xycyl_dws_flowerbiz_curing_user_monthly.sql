{{ config(materialized='table', tags=['xycyl', 'xycyl-flowerbiz', 'dws', 'monthly', 'curing']) }}

-- 报花域 养护人 × 月份 × biz_category 汇总
-- 注意 curing_user_id 在 main 表，明细继承 main；以 main 为粒度即可

WITH src AS (
  SELECT
    biz_year,
    biz_month,
    curing_user_id,
    curing_user_name,
    biz_category,
    biz_type,
    biz_id,
    amount_abs,
    is_finished,
    is_in_progress,
    is_cancelled
  FROM {{ ref('xycyl_dwd_flowerbiz_main') }}
  WHERE biz_month IS NOT NULL
    AND curing_user_id IS NOT NULL
    AND NOT is_cancelled
)

SELECT
  s.biz_year                                                                              AS period_year,
  s.biz_month                                                                             AS period_month,
  s.curing_user_id,
  s.curing_user_name,
  s.biz_category,

  COUNT(DISTINCT s.biz_id)                                                                AS biz_count,
  COUNT(DISTINCT CASE WHEN s.is_finished THEN s.biz_id END)                               AS finished_biz_count,
  COUNT(DISTINCT CASE WHEN s.is_in_progress THEN s.biz_id END)                            AS in_progress_biz_count,

  ROUND(SUM(CASE WHEN s.is_finished THEN s.amount_abs ELSE 0 END), 2)                     AS total_amount_finished,
  ROUND(SUM(s.amount_abs), 2)                                                             AS total_amount_all,

  COUNT(DISTINCT CASE WHEN s.biz_type IN ('1','2','3','4') THEN s.biz_id END)             AS biz_count_lease,
  COUNT(DISTINCT CASE WHEN s.biz_type = '7' THEN s.biz_id END)                            AS biz_count_sale,
  COUNT(DISTINCT CASE WHEN s.biz_type = '8' THEN s.biz_id END)                            AS biz_count_gift

FROM src s
GROUP BY s.biz_year, s.biz_month, s.curing_user_id, s.curing_user_name, s.biz_category
