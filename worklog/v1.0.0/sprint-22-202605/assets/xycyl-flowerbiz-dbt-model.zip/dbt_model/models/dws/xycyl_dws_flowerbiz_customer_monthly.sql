{{ config(materialized='table', tags=['xycyl', 'xycyl-flowerbiz', 'dws', 'monthly']) }}

-- 报花域 客户 × 月份 × biz_category 汇总
-- 用于"客户级"问句（坏账客户、客户欠款、销售排行）

WITH src AS (
  SELECT
    biz_year,
    biz_month,
    customer_id,
    biz_category,
    biz_type,
    biz_id,
    amount_abs,
    amount_signed,
    amount_direction,
    is_finished,
    is_cancelled,
    is_in_progress
  FROM {{ ref('xycyl_dwd_flowerbiz_main') }}
  WHERE biz_month IS NOT NULL
    AND customer_id IS NOT NULL
    AND NOT is_cancelled
)

SELECT
  s.biz_year                                                                              AS period_year,
  s.biz_month                                                                             AS period_month,
  s.customer_id,
  s.biz_category,

  COUNT(DISTINCT s.biz_id)                                                                AS biz_count,
  COUNT(DISTINCT CASE WHEN s.is_finished THEN s.biz_id END)                               AS finished_biz_count,
  COUNT(DISTINCT CASE WHEN s.is_in_progress THEN s.biz_id END)                            AS in_progress_biz_count,

  ROUND(SUM(CASE WHEN s.is_finished AND s.amount_direction = 'in'  THEN s.amount_abs ELSE 0 END), 2) AS amount_in_finished,
  ROUND(SUM(CASE WHEN s.is_finished AND s.amount_direction = 'out' THEN s.amount_abs ELSE 0 END), 2) AS amount_out_finished,
  ROUND(SUM(CASE WHEN s.is_finished AND s.amount_direction = 'in'  THEN s.amount_abs ELSE 0 END)
      - SUM(CASE WHEN s.is_finished AND s.amount_direction = 'out' THEN s.amount_abs ELSE 0 END), 2) AS amount_net_finished,
  ROUND(SUM(CASE WHEN s.is_finished THEN s.amount_signed ELSE 0 END), 2)                  AS amount_signed_finished,

  ROUND(SUM(CASE WHEN s.amount_direction = 'in'  THEN s.amount_abs ELSE 0 END), 2)        AS amount_in_all,
  ROUND(SUM(CASE WHEN s.amount_direction = 'out' THEN s.amount_abs ELSE 0 END), 2)        AS amount_out_all,

  COUNT(DISTINCT CASE WHEN s.biz_type = '6' THEN s.biz_id END)                            AS biz_count_baddebt,
  COUNT(DISTINCT CASE WHEN s.biz_type = '7' THEN s.biz_id END)                            AS biz_count_sale

FROM src s
GROUP BY s.biz_year, s.biz_month, s.customer_id, s.biz_category
