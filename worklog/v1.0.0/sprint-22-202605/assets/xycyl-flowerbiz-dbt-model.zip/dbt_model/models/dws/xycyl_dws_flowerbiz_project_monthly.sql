{{ config(materialized='table', tags=['xycyl', 'xycyl-flowerbiz', 'dws', 'monthly']) }}

-- 报花域 项目 × 客户 × 月份 × biz_category 汇总
-- biz_category: lease / sale / gift / baddebt / material（决策 2）
-- 金额按 amount_direction 拆 amount_in / amount_out / amount_neutral
-- 仅取 status='5' 已结束 + 进行中的非作废单（is_in_progress=true）共同纳入；ads 层再过滤

WITH src AS (
  SELECT
    biz_year,
    biz_month,
    project_id,
    customer_id,
    biz_category,
    biz_type,
    biz_type_label,
    amount_direction,
    biz_id,
    amount_abs,
    amount_signed,
    is_finished,
    is_cancelled,
    is_in_progress
  FROM {{ ref('xycyl_dwd_flowerbiz_main') }}
  WHERE biz_month IS NOT NULL
    AND project_id IS NOT NULL
    AND NOT is_cancelled                  -- 已作废不计入汇总
)

SELECT
  s.biz_year                                                                              AS period_year,
  s.biz_month                                                                             AS period_month,
  s.project_id,
  s.customer_id,
  s.biz_category,

  -- 单数
  COUNT(DISTINCT s.biz_id)                                                                AS biz_count,
  COUNT(DISTINCT CASE WHEN s.is_finished THEN s.biz_id END)                               AS finished_biz_count,
  COUNT(DISTINCT CASE WHEN s.is_in_progress THEN s.biz_id END)                            AS in_progress_biz_count,

  -- 按方向归并金额（已结束）— 只对 finished 求金额，避免在途单污染
  ROUND(SUM(CASE WHEN s.is_finished AND s.amount_direction = 'in'  THEN s.amount_abs ELSE 0 END), 2) AS amount_in_finished,
  ROUND(SUM(CASE WHEN s.is_finished AND s.amount_direction = 'out' THEN s.amount_abs ELSE 0 END), 2) AS amount_out_finished,
  ROUND(SUM(CASE WHEN s.is_finished AND s.amount_direction = 'neutral' THEN s.amount_abs ELSE 0 END), 2) AS amount_neutral_finished,
  ROUND(SUM(CASE WHEN s.is_finished THEN s.amount_signed ELSE 0 END), 2)                  AS amount_signed_finished,
  ROUND(SUM(CASE WHEN s.is_finished AND s.amount_direction = 'in'  THEN s.amount_abs ELSE 0 END)
      - SUM(CASE WHEN s.is_finished AND s.amount_direction = 'out' THEN s.amount_abs ELSE 0 END), 2) AS amount_net_finished,

  -- 全口径（含在途）— 决策 3 选项 B：分两个口径
  ROUND(SUM(CASE WHEN s.amount_direction = 'in'  THEN s.amount_abs ELSE 0 END), 2)        AS amount_in_all,
  ROUND(SUM(CASE WHEN s.amount_direction = 'out' THEN s.amount_abs ELSE 0 END), 2)        AS amount_out_all,
  ROUND(SUM(CASE WHEN s.amount_direction = 'neutral' THEN s.amount_abs ELSE 0 END), 2)    AS amount_neutral_all,
  ROUND(SUM(s.amount_signed), 2)                                                          AS amount_signed_all,

  -- 按 bizType 统计单数（lease 内 4 类拆开：换/加/减/调）
  COUNT(DISTINCT CASE WHEN s.biz_type = '1' THEN s.biz_id END)  AS biz_count_change,
  COUNT(DISTINCT CASE WHEN s.biz_type = '2' THEN s.biz_id END)  AS biz_count_add,
  COUNT(DISTINCT CASE WHEN s.biz_type = '3' THEN s.biz_id END)  AS biz_count_cut,
  COUNT(DISTINCT CASE WHEN s.biz_type = '4' THEN s.biz_id END)  AS biz_count_transfer,
  COUNT(DISTINCT CASE WHEN s.biz_type = '6' THEN s.biz_id END)  AS biz_count_baddebt,
  COUNT(DISTINCT CASE WHEN s.biz_type = '7' THEN s.biz_id END)  AS biz_count_sale,
  COUNT(DISTINCT CASE WHEN s.biz_type = '8' THEN s.biz_id END)  AS biz_count_gift,
  COUNT(DISTINCT CASE WHEN s.biz_type = '10' THEN s.biz_id END) AS biz_count_material,
  COUNT(DISTINCT CASE WHEN s.biz_type = '11' THEN s.biz_id END) AS biz_count_add_basket,
  COUNT(DISTINCT CASE WHEN s.biz_type = '12' THEN s.biz_id END) AS biz_count_cut_basket

FROM src s
GROUP BY s.biz_year, s.biz_month, s.project_id, s.customer_id, s.biz_category
