{{ config(materialized='view', tags=['xycyl', 'xycyl-flowerbiz', 'ads', 'recovery', 'detail']) }}

-- 7. 回收明细
-- 主要问句: 本月回收清单、报损了多少、回购量

WITH proj AS (
  SELECT * FROM {{ ref('xycyl_stg_project') }}
),
cust AS (
  SELECT * FROM {{ ref('xycyl_stg_customer') }}
),
src AS (
  SELECT * FROM {{ ref('xycyl_dwd_flowerbiz_recovery') }}
)

SELECT
  r.recovery_item_id                                         AS 回收明细id,
  r.recovery_id                                              AS 回收单id,
  r.recovery_code                                            AS 回收单号,
  r.biz_id                                                   AS 报花单id,
  r.biz_code                                                 AS 报花单号,
  r.biz_item_id                                              AS 报花明细id,

  r.project_id                                               AS 项目id,
  COALESCE(p.project_name, '未知项目')                        AS 项目,
  r.customer_id                                              AS 客户id,
  COALESCE(c.customer_name, p.customer_name)                 AS 客户,

  r.main_biz_type_label                                      AS 报花业务类型,

  r.recovery_type                                            AS 回收类型code,
  r.recovery_type_label                                      AS 回收类型,
  r.recovery_status_label                                    AS 回收状态,

  r.good_id                                                  AS 绿植id,
  r.good_name                                                AS 绿植名,

  r.recovery_number                                          AS 计划回收数,
  r.real_recovery_number                                     AS 实际回收数,
  r.effective_recovery_number                                AS 实际或计划回收数,
  r.good_cost                                                AS 单棵成本,

  r.distribution_user_id                                     AS 配送人id,
  r.recovery_user_id                                         AS 回收人id,
  r.recovery_user_name                                       AS 回收人,
  r.store_house_id                                           AS 入库库房id,
  r.store_house_name                                         AS 入库库房,

  r.plan_recovery_time                                       AS 计划回收时间,
  r.recovery_time                                            AS 实际回收时间,
  r.effective_date                                           AS 业务时间,
  r.recovery_month                                           AS 业务月份

FROM src r
LEFT JOIN proj p ON p.project_id  = r.project_id
LEFT JOIN cust c ON c.customer_id = r.customer_id
