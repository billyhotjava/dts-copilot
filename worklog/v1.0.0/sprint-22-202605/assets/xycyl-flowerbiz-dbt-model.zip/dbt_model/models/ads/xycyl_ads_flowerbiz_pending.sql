{{ config(materialized='view', tags=['xycyl', 'xycyl-flowerbiz', 'ads', 'pending', 'realtime']) }}

-- 3. 待处理报花单：bizType 全部，状态非 已结束/作废
-- 主要问句: 审核中超过 7 天、各状态报花单数、待结算清单

WITH proj AS (
  SELECT * FROM {{ ref('xycyl_stg_project') }}
),
cust AS (
  SELECT * FROM {{ ref('xycyl_stg_customer') }}
),
src AS (
  SELECT * FROM {{ ref('xycyl_dwd_flowerbiz_main') }}
  WHERE is_in_progress = true
)

SELECT
  s.biz_id                                                   AS 报花单id,
  s.biz_code                                                 AS 报花单号,
  s.biz_type                                                 AS 业务类型code,
  s.biz_type_label                                           AS 业务类型,
  s.biz_category                                             AS 业务大类,
  s.status                                                   AS 状态code,
  s.status_label                                             AS 状态,

  s.project_id                                               AS 项目id,
  COALESCE(p.project_name, '未知项目')                        AS 项目,
  s.customer_id                                              AS 客户id,
  COALESCE(c.customer_name, p.customer_name)                 AS 客户,

  s.apply_user_id                                            AS 申请人id,
  s.apply_user_name                                          AS 申请人,
  s.curing_user_name                                         AS 养护人,
  s.project_manager_name                                     AS 项目经理,

  s.amount_abs                                               AS 金额,
  s.biz_total_rent                                           AS 总租金,

  s.apply_time                                               AS 申请时间,
  s.start_lease_time                                         AS 起租时间,
  s.plan_finish_time                                         AS 计划完工时间,
  s.business_date                                            AS 业务时间,
  s.biz_month                                                AS 业务月份,

  s.pending_days                                             AS 已挂起天数,

  CASE
    WHEN s.is_pending_audit       AND s.pending_days > 7  THEN true
    WHEN s.is_picking             AND s.pending_days > 14 THEN true
    WHEN s.is_pending_settlement  AND s.pending_days > 30 THEN true
    ELSE false
  END                                                        AS 是否超期

FROM src s
LEFT JOIN proj p ON p.project_id  = s.project_id
LEFT JOIN cust c ON c.customer_id = s.customer_id
