{{ config(materialized='table', tags=['xycyl', 'xycyl-flowerbiz', 'ads', 'sale', 'summary', 'monthly']) }}

-- 4. 销售/赠花汇总：项目 × 客户 × 业务月份
-- bizType 范围: 7/8（售/赠）—— biz_category IN ('sale', 'gift')
-- 注意：与 lease_summary 分离！bizType=7/8 走 SaleAccount
-- 主要问句: 本月销售金额、销售前 10 项目、赠送数量

WITH proj AS (
  SELECT * FROM {{ ref('xycyl_stg_project') }}
),
cust AS (
  SELECT * FROM {{ ref('xycyl_stg_customer') }}
),
src AS (
  SELECT * FROM {{ ref('xycyl_dws_flowerbiz_project_monthly') }}
  WHERE biz_category IN ('sale', 'gift')
),
agg AS (
  SELECT
    period_year,
    period_month,
    project_id,
    customer_id,

    SUM(biz_count)                                                       AS biz_count_total,
    SUM(CASE WHEN biz_category='sale' THEN biz_count ELSE 0 END)         AS sale_count,
    SUM(CASE WHEN biz_category='gift' THEN biz_count ELSE 0 END)         AS gift_count,

    SUM(CASE WHEN biz_category='sale' THEN amount_in_finished ELSE 0 END)  AS sale_amount_finished,
    SUM(CASE WHEN biz_category='gift' THEN amount_neutral_finished ELSE 0 END) AS gift_amount_finished,

    SUM(CASE WHEN biz_category='sale' THEN amount_in_all ELSE 0 END)     AS sale_amount_all,
    SUM(CASE WHEN biz_category='gift' THEN amount_neutral_all ELSE 0 END) AS gift_amount_all
  FROM src
  GROUP BY period_year, period_month, project_id, customer_id
)

SELECT
  a.period_year                                              AS 年份,
  a.period_month                                             AS 业务月份,
  a.project_id                                               AS 项目id,
  COALESCE(p.project_name, '未知项目')                        AS 项目,
  a.customer_id                                              AS 客户id,
  COALESCE(c.customer_name, p.customer_name, '未知客户')      AS 客户,

  a.biz_count_total                                          AS 总单数,
  a.sale_count                                               AS 销售单数,
  a.gift_count                                               AS 赠送单数,

  ROUND(a.sale_amount_finished, 2)                           AS 销售金额,
  ROUND(a.gift_amount_finished, 2)                           AS 赠送金额,
  ROUND(a.sale_amount_all, 2)                                AS 销售金额含在途,
  ROUND(a.gift_amount_all, 2)                                AS 赠送金额含在途,

  now() AS etl_time
FROM agg a
LEFT JOIN proj p ON p.project_id  = a.project_id
LEFT JOIN cust c ON c.customer_id = a.customer_id
