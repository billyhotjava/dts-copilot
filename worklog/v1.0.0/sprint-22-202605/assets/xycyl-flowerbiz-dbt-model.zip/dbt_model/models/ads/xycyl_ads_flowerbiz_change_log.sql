{{ config(materialized='view', tags=['xycyl', 'xycyl-flowerbiz', 'ads', 'change', 'audit']) }}

-- 6. 变更日志：变更单粒度
-- 主要问句: 起租期变更记录、金额变更、规格变更

WITH proj AS (
  SELECT * FROM {{ ref('xycyl_stg_project') }}
),
src AS (
  SELECT * FROM {{ ref('xycyl_dwd_flowerbiz_change') }}
)

SELECT
  c.change_id                                                AS 变更id,
  c.change_code                                              AS 变更单号,
  c.biz_id                                                   AS 报花单id,
  c.biz_code                                                 AS 报花单号,
  c.project_id                                               AS 项目id,
  COALESCE(p.project_name, '未知项目')                        AS 项目,
  c.customer_id                                              AS 客户id,

  c.main_biz_type_label                                      AS 报花业务类型,

  c.change_type                                              AS 变更类型code,
  c.change_type_label                                        AS 变更类型,
  c.change_status                                            AS 变更状态code,
  c.change_status_label                                      AS 变更状态,

  c.before_total_amount                                      AS 变更前金额,
  c.after_total_amount                                       AS 变更后金额,
  c.amount_delta                                             AS 金额差额,

  c.before_settlement_time                                   AS 变更前起租时间,
  c.after_settlement_time                                    AS 变更后起租时间,

  c.change_time                                              AS 变更时间,
  c.change_month                                             AS 变更月份,
  c.change_user_id                                           AS 变更人id,
  c.change_reason                                            AS 变更原因

FROM src c
LEFT JOIN proj p ON p.project_id = c.project_id
