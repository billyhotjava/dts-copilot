{{ config(materialized='table', tags=['xycyl', 'xycyl-flowerbiz', 'ads', 'extra_cost', 'summary', 'monthly']) }}

-- 10. 报花额外费用汇总：项目 × 客户 × 业务月份 × 费用类型
-- 主要问句: 本月运费、人工成本、税费占比、垃圾清理费用、附加成本 TOP 项目

WITH proj AS (
  SELECT * FROM {{ ref('xycyl_stg_project') }}
),
cust AS (
  SELECT * FROM {{ ref('xycyl_stg_customer') }}
),
src AS (
  SELECT * FROM {{ ref('xycyl_dwd_flowerbiz_extra_cost') }}
  WHERE biz_month IS NOT NULL
)

SELECT
  s.biz_year                                                 AS 年份,
  s.biz_month                                                AS 业务月份,
  s.project_id                                               AS 项目id,
  COALESCE(p.project_name, '未知项目')                        AS 项目,
  s.customer_id                                              AS 客户id,
  COALESCE(c.customer_name, p.customer_name, '未知客户')      AS 客户,

  COUNT(DISTINCT s.biz_id)                                   AS 涉及单数,
  COUNT(DISTINCT s.extra_cost_id)                            AS 费用条数,

  ROUND(SUM(s.free_amount), 2)                               AS 不含税成本合计,
  ROUND(SUM(s.price_amount), 2)                              AS 含税金额合计,

  ROUND(SUM(CASE WHEN s.is_freight THEN s.price_amount ELSE 0 END), 2) AS 运费合计,
  ROUND(SUM(CASE WHEN s.is_labor   THEN s.price_amount ELSE 0 END), 2) AS 人工费合计,
  ROUND(SUM(CASE WHEN s.is_tax     THEN s.price_amount ELSE 0 END), 2) AS 税费合计,
  ROUND(SUM(CASE WHEN s.is_garbage THEN s.price_amount ELSE 0 END), 2) AS 垃圾清理费合计,
  ROUND(SUM(CASE WHEN s.is_other   THEN s.price_amount ELSE 0 END), 2) AS 其他费用合计,

  COUNT(DISTINCT CASE WHEN s.is_freight THEN s.extra_cost_id END) AS 运费条数,
  COUNT(DISTINCT CASE WHEN s.is_labor   THEN s.extra_cost_id END) AS 人工费条数,
  COUNT(DISTINCT CASE WHEN s.is_tax     THEN s.extra_cost_id END) AS 税费条数,
  COUNT(DISTINCT CASE WHEN s.is_garbage THEN s.extra_cost_id END) AS 垃圾清理费条数,
  COUNT(DISTINCT CASE WHEN s.is_other   THEN s.extra_cost_id END) AS 其他费用条数,

  now() AS etl_time
FROM src s
LEFT JOIN proj p ON p.project_id  = s.project_id
LEFT JOIN cust c ON c.customer_id = s.customer_id
GROUP BY s.biz_year, s.biz_month, s.project_id, s.customer_id, p.project_name, c.customer_name, p.customer_name
