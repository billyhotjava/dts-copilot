{{ config(materialized='view', tags=['xycyl', 'xycyl-flowerbiz', 'ads', 'audit', 'trail']) }}

-- 9. 报花单审批/操作流水
-- 主要问句: 审批耗时、操作链路、谁经手了哪些单、X 单挂在哪一步
-- 与 xycyl_ads_flowerbiz_pending 互补：pending 看"现在在哪"，audit_trail 看"走过哪"

WITH proj AS (
  SELECT * FROM {{ ref('xycyl_stg_project') }}
),
src AS (
  SELECT * FROM {{ ref('xycyl_dwd_flowerbiz_log') }}
)

SELECT
  l.log_id                                                   AS 日志id,
  l.biz_id                                                   AS 报花单id,
  l.biz_code                                                 AS 报花单号,

  l.biz_type                                                 AS 业务类型code,
  l.biz_type_label                                           AS 业务类型,
  l.biz_category                                             AS 业务大类,

  l.project_id                                               AS 项目id,
  COALESCE(p.project_name, '未知项目')                        AS 项目,
  l.customer_id                                              AS 客户id,

  l.sorts                                                    AS 顺序号,
  l.status                                                   AS 状态code,
  l.status_label                                             AS 状态,
  l.operation_title                                          AS 操作动作,
  l.operation_content                                        AS 操作内容,

  l.operation_user_id                                        AS 操作人id,
  l.operation_user_name                                      AS 操作人,

  l.operation_date                                           AS 操作时间,
  l.operation_month                                          AS 操作月份,
  l.prev_operation_date                                      AS 上一步时间,
  l.days_since_prev                                          AS 距上一步天数,

  l.is_finished_at_log                                       AS 该步是否已结束,
  l.is_cancelled_at_log                                      AS 该步是否作废

FROM src l
LEFT JOIN proj p ON p.project_id = l.project_id
