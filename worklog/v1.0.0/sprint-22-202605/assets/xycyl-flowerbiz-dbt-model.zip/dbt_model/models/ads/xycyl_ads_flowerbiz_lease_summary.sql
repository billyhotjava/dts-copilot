{{ config(materialized='table', tags=['xycyl', 'xycyl-flowerbiz', 'ads', 'lease', 'summary', 'monthly']) }}

-- 1. 租赁汇总：项目 × 客户 × 业务月份
-- bizType 范围: 1/2/3/4（换/加/减/调）—— biz_category='lease'
-- 主要问句: 本月加摆撤摆净增减、项目租金变动、月度报花趋势

WITH proj AS (
  SELECT * FROM {{ ref('xycyl_stg_project') }}
),
cust AS (
  SELECT * FROM {{ ref('xycyl_stg_customer') }}
),
src AS (
  SELECT * FROM {{ ref('xycyl_dws_flowerbiz_project_monthly') }}
  WHERE biz_category = 'lease'
)

SELECT
  s.period_year                                              AS 年份,
  s.period_month                                             AS 业务月份,
  s.project_id                                               AS 项目id,
  COALESCE(p.project_name, '未知项目')                        AS 项目,
  s.customer_id                                              AS 客户id,
  COALESCE(c.customer_name, p.customer_name, '未知客户')      AS 客户,
  s.biz_category                                             AS 业务大类,

  s.biz_count                                                AS 报花单数,
  s.finished_biz_count                                       AS 已结束单数,
  s.in_progress_biz_count                                    AS 在途单数,

  s.biz_count_change                                         AS 换花单数,
  s.biz_count_add                                            AS 加摆单数,
  s.biz_count_cut                                            AS 撤摆单数,
  s.biz_count_transfer                                       AS 调花单数,

  s.amount_in_finished                                       AS 加摆金额,
  s.amount_out_finished                                      AS 撤摆金额,
  s.amount_neutral_finished                                  AS 中性金额,
  s.amount_net_finished                                      AS 净增金额,
  s.amount_signed_finished                                   AS 原符号合计金额,

  s.amount_in_all                                            AS 加摆金额含在途,
  s.amount_out_all                                           AS 撤摆金额含在途,

  now() AS etl_time
FROM src s
LEFT JOIN proj p ON p.project_id   = s.project_id
LEFT JOIN cust c ON c.customer_id  = s.customer_id
