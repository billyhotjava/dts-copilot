{{ config(materialized='table', tags=['xycyl', 'xycyl-flowerbiz', 'dwd', 'biz', 'flowerbiz_log']) }}

-- 报花单操作日志事实层 — JOIN main 透传业务上下文
-- 关键派生：上一次操作到本次操作的间隔（用于回答"审批耗时""挂起天数"）

WITH stg AS (
  SELECT * FROM {{ ref('xycyl_stg_flower_biz_log') }}
),
main AS (
  SELECT * FROM {{ ref('xycyl_dwd_flowerbiz_main') }}
),
normalized AS (
  SELECT
    s.*,
    bta.canonical_code AS biz_type,
    sa.canonical_code  AS status
  FROM stg s
  LEFT JOIN {{ ref('xycyl_dim_flowerbiz_biztype_alias') }} bta
    ON bta.alias_raw = s.biz_type_raw
  LEFT JOIN {{ ref('xycyl_dim_flowerbiz_status_alias') }} sa
    ON sa.alias_raw = s.status_raw
),
ordered AS (
  SELECT
    n.*,
    LAG(n.operation_date) OVER (PARTITION BY n.biz_id ORDER BY n.sorts NULLS LAST, n.operation_date) AS prev_operation_date
  FROM normalized n
)

SELECT
  o.log_id,
  o.source_row_id,
  o.source_table,

  o.biz_id,
  m.biz_code,
  m.project_id,
  m.customer_id,

  o.sorts,
  o.biz_type_raw,
  o.biz_type,
  bt.label                    AS biz_type_label,
  m.biz_category,

  o.status_raw,
  o.status,
  st.label                    AS status_label,
  COALESCE(st.is_finished, false)  AS is_finished_at_log,
  COALESCE(st.is_cancelled, false) AS is_cancelled_at_log,

  o.operation_title,
  o.operation_user_id,
  o.operation_user_name,
  o.operation_date,
  o.operation_content,

  o.prev_operation_date,
  CASE
    WHEN o.prev_operation_date IS NULL THEN NULL
    ELSE GREATEST((o.operation_date - o.prev_operation_date)::int, 0)
  END                         AS days_since_prev,

  to_char(o.operation_date, 'YYYY-MM') AS operation_month,
  EXTRACT(YEAR FROM o.operation_date)::int AS operation_year,

  now() AS etl_time

FROM ordered o
LEFT JOIN main m
  ON m.biz_id = o.biz_id
LEFT JOIN {{ ref('xycyl_dim_flowerbiz_biztype') }} bt
  ON bt.code = o.biz_type
LEFT JOIN {{ ref('xycyl_dim_flowerbiz_status') }} st
  ON st.code = o.status
