{{ config(materialized='table', tags=['xycyl', 'xycyl-flowerbiz', 'dim', 'dwd']) }}

-- 报花额外费用类型 canonical 维度
-- 真值源: rs_cloud_flower t_flower_extra_cost.cost_type

SELECT cost_type_id, code, label,
       is_freight, is_labor, is_tax, is_garbage, is_other,
       sort_order
FROM (VALUES
  ('flowerbiz_cost_type_freight', '1', '运费',         true,  false, false, false, false, 10),
  ('flowerbiz_cost_type_labor',   '2', '人工费用',     false, true,  false, false, false, 20),
  ('flowerbiz_cost_type_tax',     '3', '税费',         false, false, true,  false, false, 30),
  ('flowerbiz_cost_type_other',   '4', '其他费用',     false, false, false, false, true,  40),
  ('flowerbiz_cost_type_garbage', '5', '垃圾清理费',   false, false, false, true,  false, 50)
) AS t(cost_type_id, code, label,
       is_freight, is_labor, is_tax, is_garbage, is_other, sort_order)
