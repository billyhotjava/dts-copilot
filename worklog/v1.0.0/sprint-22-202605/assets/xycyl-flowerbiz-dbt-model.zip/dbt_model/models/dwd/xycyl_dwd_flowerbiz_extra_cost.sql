{{ config(materialized='table', tags=['xycyl', 'xycyl-flowerbiz', 'dwd', 'biz', 'extra_cost']) }}

-- 报花额外费用事实层

WITH stg AS (
  SELECT * FROM {{ ref('xycyl_stg_flower_extra_cost') }}
),
main AS (
  SELECT * FROM {{ ref('xycyl_dwd_flowerbiz_main') }}
),
normalized AS (
  SELECT
    s.*,
    bta.canonical_code AS biz_type,
    cta.canonical_code AS cost_type
  FROM stg s
  LEFT JOIN {{ ref('xycyl_dim_flowerbiz_biztype_alias') }} bta
    ON bta.alias_raw = s.biz_type_raw
  LEFT JOIN {{ ref('xycyl_dim_flowerbiz_cost_type_alias') }} cta
    ON cta.alias_raw = s.cost_type_raw
)

SELECT
  s.extra_cost_id,
  s.source_row_id,
  s.source_table,

  s.biz_id,
  m.biz_code,
  m.project_id,
  m.customer_id,

  s.biz_type_raw,
  s.biz_type,
  bt.label                AS biz_type_label,
  m.biz_category,

  s.cost_type_raw,
  s.cost_type,
  ct.cost_type_id,
  ct.label                AS cost_type_label,
  COALESCE(ct.is_freight, false) AS is_freight,
  COALESCE(ct.is_labor, false)   AS is_labor,
  COALESCE(ct.is_tax, false)     AS is_tax,
  COALESCE(ct.is_garbage, false) AS is_garbage,
  COALESCE(ct.is_other, false)   AS is_other,

  s.title,
  COALESCE(s.free_amount, 0)  AS free_amount,
  COALESCE(s.price_amount, 0) AS price_amount,
  s.tax_rate,

  s.pay_user_id,
  s.pay_user_name,
  s.pay_date,

  s.expense_id,
  s.expense_code,

  -- 业务时间用主表 business_date，pay_date 兜底
  COALESCE(m.business_date, s.pay_date)                                 AS business_date,
  to_char(COALESCE(m.business_date, s.pay_date), 'YYYY-MM')             AS biz_month,
  EXTRACT(YEAR FROM COALESCE(m.business_date, s.pay_date))::int         AS biz_year,

  s.created_date,
  s.updated_date,
  now() AS etl_time

FROM normalized s
LEFT JOIN main m
  ON m.biz_id = s.biz_id
LEFT JOIN {{ ref('xycyl_dim_flowerbiz_biztype') }} bt
  ON bt.code = s.biz_type
LEFT JOIN {{ ref('xycyl_dim_flowerbiz_cost_type') }} ct
  ON ct.code = s.cost_type
