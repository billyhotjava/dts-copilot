{{ config(materialized='table', tags=['xycyl', 'xycyl-flowerbiz', 'dwd', 'biz', 'recovery']) }}

-- 回收事实层 — 主表 + 明细 + 报花单 主表 三方 JOIN
-- 关键口径：业务关心 real_recovery_number（实际回收数）而非 recovery_number（计划回收数）

WITH ri AS (
  SELECT * FROM {{ ref('xycyl_stg_recovery_info') }}
),
rii AS (
  SELECT * FROM {{ ref('xycyl_stg_recovery_info_item') }}
),
main AS (
  SELECT * FROM {{ ref('xycyl_dwd_flowerbiz_main') }}
),
joined AS (
  SELECT
    rii.recovery_item_id,
    rii.source_row_id      AS item_source_row_id,
    rii.source_table       AS item_source_table,

    rii.recovery_id,
    ri.recovery_code,
    ri.biz_id,

    rii.biz_item_id,
    rii.good_id,
    rii.good_name,

    rii.recovery_type_raw,

    rii.recovery_number,
    rii.real_recovery_number,
    rii.good_cost,

    -- 主表透传
    ri.distribution_user_id,
    ri.recovery_user_id,
    ri.recovery_user_name,
    ri.store_house_id,
    ri.store_house_name,
    ri.status_raw          AS recovery_status_raw,
    ri.plan_recovery_time,
    ri.recovery_time,

    -- 报花单主表透传
    main.biz_code,
    main.project_id,
    main.customer_id,
    main.biz_type          AS main_biz_type,
    main.biz_type_label    AS main_biz_type_label,
    main.business_date     AS biz_business_date,

    rii.created_date,
    rii.updated_date
  FROM rii
  LEFT JOIN ri   ON ri.recovery_id = rii.recovery_id
  LEFT JOIN main ON main.biz_id    = ri.biz_id
),
normalized AS (
  SELECT j.*,
         rta.canonical_code AS recovery_type
  FROM joined j
  LEFT JOIN {{ ref('xycyl_dim_flowerbiz_recovery_type_alias') }} rta
    ON rta.alias_raw = j.recovery_type_raw
)

SELECT
  n.recovery_item_id,
  n.recovery_id,
  n.recovery_code,
  n.biz_id,
  n.biz_code,
  n.biz_item_id,
  n.project_id,
  n.customer_id,
  n.main_biz_type,
  n.main_biz_type_label,

  n.good_id,
  n.good_name,

  n.recovery_type_raw,
  n.recovery_type,
  rt.recovery_type_id,
  rt.label              AS recovery_type_label,
  COALESCE(rt.is_loss, false)    AS is_loss,
  COALESCE(rt.is_buyback, false) AS is_buyback,
  COALESCE(rt.is_keep, false)    AS is_keep,

  n.recovery_number,
  n.real_recovery_number,
  COALESCE(n.real_recovery_number, n.recovery_number, 0) AS effective_recovery_number,
  n.good_cost,

  n.distribution_user_id,
  n.recovery_user_id,
  n.recovery_user_name,
  n.store_house_id,
  n.store_house_name,

  n.recovery_status_raw,
  CASE
    WHEN n.recovery_status_raw = '1' THEN '待回收'
    WHEN n.recovery_status_raw = '2' THEN '确认入库'
    WHEN n.recovery_status_raw = '3' THEN '已结束'
    ELSE n.recovery_status_raw
  END AS recovery_status_label,

  n.plan_recovery_time,
  n.recovery_time,
  COALESCE(n.recovery_time, n.plan_recovery_time, n.biz_business_date) AS effective_date,
  to_char(COALESCE(n.recovery_time, n.plan_recovery_time, n.biz_business_date), 'YYYY-MM') AS recovery_month,
  EXTRACT(YEAR FROM COALESCE(n.recovery_time, n.plan_recovery_time, n.biz_business_date))::int AS recovery_year,

  n.item_source_row_id,
  n.item_source_table,

  n.created_date,
  n.updated_date,
  now() AS etl_time

FROM normalized n
LEFT JOIN {{ ref('xycyl_dim_flowerbiz_recovery_type') }} rt
  ON rt.code = n.recovery_type
