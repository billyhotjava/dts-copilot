{{ config(materialized='table', tags=['xycyl', 'xycyl-flowerbiz', 'dwd', 'biz', 'flowerbiz_main']) }}

-- 报花单主表事实层 — 三段论：normalized → derived → final
-- 要点（对齐 assets/flowerbiz-source-catalog.md §七 6 个陷阱）：
--   * 业务时间 = COALESCE(start_lease_time, apply_time)（决策 1 默认 B）
--   * 金额方向归一: amount_abs + amount_direction（决策 4 推荐 B）
--   * biz_category: lease/sale/gift/baddebt/material（决策 2 推荐 B）
--   * 软删已在 STG 过滤
--   * 在途状态 pending_days 派生（基于 apply_time）

WITH stg AS (
  SELECT * FROM {{ ref('xycyl_stg_flower_biz_info') }}
),
normalized AS (
  SELECT
    s.*,
    bta.canonical_code AS biz_type,
    sa.canonical_code  AS status
  FROM stg s
  LEFT JOIN {{ ref('xycyl_dim_flowerbiz_biztype_alias') }} bta
    ON bta.alias_raw = s.biz_type_raw
  LEFT JOIN {{ ref('xycyl_dim_flowerbiz_status_alias') }} sa
    ON sa.alias_raw = s.status_raw
),
derived AS (
  SELECT
    n.*,
    COALESCE(n.start_lease_time, n.apply_time) AS business_date,
    to_char(COALESCE(n.start_lease_time, n.apply_time), 'YYYY-MM') AS biz_month,
    EXTRACT(YEAR FROM COALESCE(n.start_lease_time, n.apply_time))::int AS biz_year,
    EXTRACT(QUARTER FROM COALESCE(n.start_lease_time, n.apply_time))::int AS biz_quarter,
    ABS(COALESCE(n.biz_total_rent, 0)) AS amount_abs,
    n.biz_total_rent AS amount_signed,
    CASE
      WHEN n.status IN ('5','-1') THEN 0
      WHEN n.apply_time IS NULL THEN 0
      ELSE GREATEST((current_date - n.apply_time)::int, 0)
    END AS pending_days
  FROM normalized n
)

SELECT
  -- 业务键
  d.biz_id,
  d.biz_code,
  d.source_row_id,
  d.source_table,
  d.source_system,
  d.imported_at AS source_imported_at,

  -- 业务对象
  d.project_id,
  d.customer_id,

  -- 人员
  d.apply_user_id,
  d.apply_user_name,
  d.examine_user_id,
  d.sign_user_id,
  d.curing_user_id,
  d.curing_user_name,
  d.project_manager_id,
  d.project_manager_name,

  -- bizType（已归一化）+ 翻译
  d.biz_type_raw,
  d.biz_type,
  bt.biztype_id,
  bt.label             AS biz_type_label,
  bt.amount_direction,
  bt.biz_category,
  COALESCE(bt.is_lease, false)    AS is_lease_biz,
  COALESCE(bt.is_sale, false)     AS is_sale_biz,
  COALESCE(bt.is_gift, false)     AS is_gift_biz,
  COALESCE(bt.is_baddebt, false)  AS is_baddebt_biz,
  COALESCE(bt.is_material, false) AS is_material_biz,

  -- 状态（已归一化）+ 翻译
  d.status_raw,
  d.status,
  st.status_id,
  st.label                            AS status_label,
  COALESCE(st.is_draft, false)              AS is_draft,
  COALESCE(st.is_pending_audit, false)      AS is_pending_audit,
  COALESCE(st.is_rejected, false)           AS is_rejected,
  COALESCE(st.is_picking, false)            AS is_picking,
  COALESCE(st.is_accounting, false)         AS is_accounting,
  COALESCE(st.is_pending_settlement, false) AS is_pending_settlement,
  COALESCE(st.is_finished, false)           AS is_finished,
  COALESCE(st.is_cancelled, false)          AS is_cancelled,
  COALESCE(st.is_in_progress, false)        AS is_in_progress,

  -- 金额（含归一化）
  d.biz_total_rent,
  d.biz_total_cost,
  d.total_amount,
  d.amount_signed,
  d.amount_abs,
  d.lease_term,

  -- 时间
  d.apply_time,
  d.plan_finish_time,
  d.settlement_time,
  d.finish_time,
  d.start_lease_time,
  d.end_lease_time,
  d.business_date,
  d.biz_year,
  d.biz_quarter,
  d.biz_month,

  -- 在途天数
  d.pending_days,

  -- 元数据
  d.created_date,
  d.updated_date,
  now() AS etl_time

FROM derived d
LEFT JOIN {{ ref('xycyl_dim_flowerbiz_biztype') }} bt
  ON bt.code = d.biz_type
LEFT JOIN {{ ref('xycyl_dim_flowerbiz_status') }} st
  ON st.code = d.status
