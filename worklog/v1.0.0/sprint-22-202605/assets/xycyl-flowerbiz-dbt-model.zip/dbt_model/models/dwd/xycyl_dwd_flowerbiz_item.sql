{{ config(materialized='table', tags=['xycyl', 'xycyl-flowerbiz', 'dwd', 'biz', 'flowerbiz_item']) }}

-- 报花明细事实层
-- 软外键 flower_biz_id LEFT JOIN main，main 缺失时该行仍保留（孤儿率监控见 dws）

WITH item AS (
  SELECT * FROM {{ ref('xycyl_stg_flower_biz_item') }}
),
main AS (
  SELECT * FROM {{ ref('xycyl_dwd_flowerbiz_main') }}
),
normalized AS (
  SELECT
    i.*,
    bta.canonical_code AS biz_type
  FROM item i
  LEFT JOIN {{ ref('xycyl_dim_flowerbiz_biztype_alias') }} bta
    ON bta.alias_raw = i.biz_type_raw
)

SELECT
  i.biz_item_id,
  i.source_row_id,
  i.source_table,

  i.flower_biz_id,
  m.biz_code,
  m.project_id,
  m.customer_id,
  m.curing_user_id,
  m.curing_user_name,

  i.position_id,
  i.position_name,
  i.good_id,
  i.good_price_id,
  i.good_name,
  i.spec_name,

  -- bizType（明细自身的 biz_type，理论上与主表一致）
  i.biz_type_raw,
  i.biz_type,
  bt.label             AS biz_type_label,
  bt.amount_direction,
  bt.biz_category,
  COALESCE(bt.is_lease, false)    AS is_lease_biz,
  COALESCE(bt.is_sale, false)     AS is_sale_biz,
  COALESCE(bt.is_gift, false)     AS is_gift_biz,
  COALESCE(bt.is_baddebt, false)  AS is_baddebt_biz,
  COALESCE(bt.is_material, false) AS is_material_biz,

  i.plant_number,
  i.rent,
  i.cost,
  i.amount,
  ABS(COALESCE(i.amount, 0))                       AS amount_abs,
  ABS(COALESCE(i.plant_number, 0))                 AS plant_number_abs,

  i.put_time,
  i.start_time,
  i.end_time,

  i.net_receipts_number,
  i.frm_loss_number,
  i.buyback_number,
  i.keep_number,

  -- 派生月份（用 main.business_date，孤儿用 item.start_time 兜底）
  COALESCE(m.business_date, i.start_time, i.put_time)               AS business_date,
  to_char(COALESCE(m.business_date, i.start_time, i.put_time), 'YYYY-MM') AS biz_month,
  EXTRACT(YEAR FROM COALESCE(m.business_date, i.start_time, i.put_time))::int AS biz_year,

  -- main 状态透传
  m.status              AS main_status,
  m.status_label        AS main_status_label,
  m.is_finished         AS main_is_finished,
  m.is_cancelled        AS main_is_cancelled,
  m.is_in_progress      AS main_is_in_progress,

  -- 孤儿标记
  CASE WHEN m.biz_id IS NULL THEN true ELSE false END AS is_orphan,

  i.created_date,
  i.updated_date,
  now() AS etl_time

FROM normalized i
LEFT JOIN main m
  ON m.biz_id = i.flower_biz_id
LEFT JOIN {{ ref('xycyl_dim_flowerbiz_biztype') }} bt
  ON bt.code = i.biz_type
