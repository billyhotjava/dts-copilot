{{ config(materialized='table', tags=['xycyl', 'xycyl-flowerbiz', 'dim', 'dwd']) }}

-- 报花 bizType canonical 维度表
-- 真值源: rs_cloud_flower t_flower_biz_info.biz_type
-- amount_direction: 金额方向 in/out/neutral （决策 4：dws/ads 按方向归一化）
-- biz_category: 5 类合并 lease/sale/gift/baddebt/material （决策 2）

SELECT biztype_id, code, label,
       amount_direction,
       biz_category,
       is_lease, is_sale, is_gift, is_baddebt, is_material,
       sort_order
FROM (VALUES
  ('flowerbiz_biztype_change',     '1',  '换花',     'neutral', 'lease',     true,  false, false, false, false, 10),
  ('flowerbiz_biztype_add',        '2',  '加花',     'in',      'lease',     true,  false, false, false, false, 20),
  ('flowerbiz_biztype_cut',        '3',  '减花',     'out',     'lease',     true,  false, false, false, false, 30),
  ('flowerbiz_biztype_transfer',   '4',  '调花',     'neutral', 'lease',     true,  false, false, false, false, 40),
  ('flowerbiz_biztype_baddebt',    '6',  '坏账',     'out',     'baddebt',   false, false, false, true,  false, 50),
  ('flowerbiz_biztype_sale',       '7',  '售花',     'in',      'sale',      false, true,  false, false, false, 60),
  ('flowerbiz_biztype_gift',       '8',  '赠花',     'neutral', 'gift',      false, false, true,  false, false, 70),
  ('flowerbiz_biztype_material',   '10', '配料',     'in',      'material',  false, false, false, false, true,  80),
  ('flowerbiz_biztype_add_basket', '11', '加盆架',   'in',      'material',  false, false, false, false, true,  90),
  ('flowerbiz_biztype_cut_basket', '12', '减盆架',   'out',     'material',  false, false, false, false, true, 100)
) AS t(biztype_id, code, label,
       amount_direction, biz_category,
       is_lease, is_sale, is_gift, is_baddebt, is_material,
       sort_order)
