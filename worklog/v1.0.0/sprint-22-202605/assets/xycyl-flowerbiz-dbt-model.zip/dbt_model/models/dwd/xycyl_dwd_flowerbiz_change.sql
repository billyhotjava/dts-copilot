{{ config(materialized='table', tags=['xycyl', 'xycyl-flowerbiz', 'dwd', 'biz', 'change']) }}

-- 变更单事实层
WITH stg AS (
  SELECT * FROM {{ ref('xycyl_stg_change_info') }}
),
main AS (
  SELECT * FROM {{ ref('xycyl_dwd_flowerbiz_main') }}
),
normalized AS (
  SELECT
    s.*,
    cta.canonical_code AS change_type,
    sa.canonical_code  AS status
  FROM stg s
  LEFT JOIN {{ ref('xycyl_dim_flowerbiz_change_type_alias') }} cta
    ON cta.alias_raw = s.change_type_raw
  LEFT JOIN {{ ref('xycyl_dim_flowerbiz_status_alias') }} sa
    ON sa.alias_raw = s.status_raw
)

SELECT
  s.change_id,
  s.change_code,
  s.source_row_id,
  s.source_table,

  s.biz_id,
  m.biz_code,
  m.project_id,
  m.customer_id,
  m.biz_type AS main_biz_type,
  m.biz_type_label AS main_biz_type_label,

  s.change_type_raw,
  s.change_type,
  ct.change_type_id,
  ct.label                                  AS change_type_label,
  COALESCE(ct.is_amount_change, false)      AS is_amount_change,
  COALESCE(ct.is_warehouse_change, false)   AS is_warehouse_change,
  COALESCE(ct.is_cost_change, false)        AS is_cost_change,
  COALESCE(ct.is_lease_time_change, false)  AS is_lease_time_change,

  s.status_raw,
  s.status                                  AS change_status,
  CASE
    WHEN s.status = '2'  THEN '已结束'
    WHEN s.status = '-1' THEN '作废'
    ELSE '确认中'
  END AS change_status_label,

  s.before_total_amount,
  s.after_total_amount,
  COALESCE(s.after_total_amount, 0) - COALESCE(s.before_total_amount, 0) AS amount_delta,

  s.before_settlement_time,
  s.after_settlement_time,

  s.change_reason,
  s.change_user_id,
  s.change_time,
  to_char(s.change_time, 'YYYY-MM')         AS change_month,
  EXTRACT(YEAR FROM s.change_time)::int     AS change_year,

  s.created_date,
  s.updated_date,
  now() AS etl_time

FROM normalized s
LEFT JOIN main m
  ON m.biz_id = s.biz_id
LEFT JOIN {{ ref('xycyl_dim_flowerbiz_change_type') }} ct
  ON ct.code = s.change_type
