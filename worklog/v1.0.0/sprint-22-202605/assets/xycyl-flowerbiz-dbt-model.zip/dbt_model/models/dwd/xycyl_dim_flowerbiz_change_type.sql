{{ config(materialized='table', tags=['xycyl', 'xycyl-flowerbiz', 'dim', 'dwd']) }}

-- 变更类型 canonical 维度表
-- 真值源: rs_cloud_flower t_change_info.change_type

SELECT change_type_id, code, label,
       is_amount_change, is_warehouse_change, is_cost_change, is_lease_time_change,
       sort_order
FROM (VALUES
  ('flowerbiz_change_type_amount',     '1', '销售金额',     true,  false, false, false, 10),
  ('flowerbiz_change_type_warehouse',  '2', '库房物品类型', false, true,  false, false, 20),
  ('flowerbiz_change_type_cost',       '3', '成本',         false, false, true,  false, 30),
  ('flowerbiz_change_type_lease_time', '4', '起租减租',     false, false, false, true,  40)
) AS t(change_type_id, code, label,
       is_amount_change, is_warehouse_change, is_cost_change, is_lease_time_change,
       sort_order)
