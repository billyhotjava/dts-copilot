{{ config(materialized='table', tags=['xycyl', 'xycyl-flowerbiz', 'dim', 'dwd', 'alias']) }}

SELECT alias_raw, canonical_code FROM (VALUES
  ('1',         '1'),
  ('销售金额',   '1'),
  ('金额',       '1'),
  ('AMOUNT',    '1'),

  ('2',           '2'),
  ('库房物品类型', '2'),
  ('物品类型',     '2'),
  ('WAREHOUSE',   '2'),

  ('3',     '3'),
  ('成本',   '3'),
  ('COST',  '3'),

  ('4',           '4'),
  ('起租减租',     '4'),
  ('起租期',       '4'),
  ('LEASE_TIME',  '4')
) AS t(alias_raw, canonical_code)
