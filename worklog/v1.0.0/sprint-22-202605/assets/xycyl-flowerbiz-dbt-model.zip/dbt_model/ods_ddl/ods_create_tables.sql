-- ============================================================
-- 馨懿诚绿植租摆 报花域 ODS 建表 DDL
-- 命名空间: xycyl   |   schema: xycyl_ods
-- 来源: rs_cloud_flower 业务库（MySQL）入湖镜像
-- 字段全部 varchar — 类型转换由 dbt STG 层处理
-- 注意: 执行此脚本会 DROP 报花域 ODS 表并重建！已有数据会丢失。
-- ============================================================

CREATE SCHEMA IF NOT EXISTS xycyl_ods;
SET search_path TO xycyl_ods, public;

-- ─── 1. 报花单主表（t_flower_biz_info） ───────────────────────
DROP TABLE IF EXISTS xycyl_ods.ods_flower_biz_info CASCADE;
CREATE TABLE xycyl_ods.ods_flower_biz_info (
    id                   varchar(64),    -- BIGINT PK
    code                 varchar(64),    -- 单据编号（业务唯一）
    biz_type             varchar(16),    -- 13 bizType: 1/2/3/4/6/7/8/10/11/12
    status               varchar(16),    -- -1/1/2/3/4/5/20/21
    project_id           varchar(64),    -- 软外键 → p_project.id
    customer_id          varchar(64),    -- 软外键 → p_customer.id
    apply_user_id        varchar(64),    -- u_personnel.user_id
    apply_user_name      varchar(255),
    apply_time           varchar(40),    -- 申请时间
    plan_finish_time     varchar(40),
    settlement_time      varchar(40),    -- NULL 表未结算
    finish_time          varchar(40),
    biz_total_rent       varchar(40),    -- DECIMAL(14,2) 报花单总租金（金额方向因 bizType 异）
    biz_total_cost       varchar(40),
    total_amount         varchar(40),    -- 销售场景用
    examine_user_id      varchar(64),
    sign_user_id         varchar(64),
    curing_user_id       varchar(64),
    curing_user_name     varchar(255),
    project_manager_id   varchar(64),
    project_manager_name varchar(255),
    lease_term           varchar(16),    -- 是否填写租期
    start_lease_time     varchar(40),    -- 起租时间（可被 t_flower_rent_time_log 事后修改）
    end_lease_time       varchar(40),
    remark               varchar(2000),
    del_flag             varchar(4),     -- '0' 有效
    create_time          varchar(40),    -- 仅审计
    update_time          varchar(40),    -- 多 service 写
    source_system        varchar(64) DEFAULT 'rs_cloud_flower',
    imported_at          timestamp DEFAULT now()
);

-- ─── 2. 报花明细（t_flower_biz_item） ─────────────────────────
DROP TABLE IF EXISTS xycyl_ods.ods_flower_biz_item CASCADE;
CREATE TABLE xycyl_ods.ods_flower_biz_item (
    id                   varchar(64),
    flower_biz_id        varchar(64),    -- 软外键 → ods_flower_biz_info.id
    position_id          varchar(64),    -- p_position.id 摆位
    position_name        varchar(255),
    biz_type             varchar(16),
    status               varchar(16),
    good_id              varchar(64),
    good_price_id        varchar(64),
    good_name            varchar(255),   -- 绿植品种名
    spec_name            varchar(255),
    plant_number         varchar(16),    -- 数量（加+ 减-）
    rent                 varchar(40),    -- 单棵月租金
    cost                 varchar(40),    -- 单棵成本
    amount               varchar(40),    -- 行金额
    put_time             varchar(40),    -- 摆放时间
    start_time           varchar(40),    -- 起租时间（可事后改）
    end_time             varchar(40),    -- 停租时间
    net_receipts_number  varchar(16),    -- 回收时净收回数量
    frm_loss_number      varchar(16),    -- 回收时报损数量
    buyback_number       varchar(16),    -- 回收时回购数量
    keep_number          varchar(16),    -- 回收时留用数量
    del_flag             varchar(4),
    create_time          varchar(40),
    update_time          varchar(40),
    source_system        varchar(64) DEFAULT 'rs_cloud_flower',
    imported_at          timestamp DEFAULT now()
);

-- ─── 3. 报花子项明细（t_flower_biz_item_detailed） ────────────
DROP TABLE IF EXISTS xycyl_ods.ods_flower_biz_item_detailed CASCADE;
CREATE TABLE xycyl_ods.ods_flower_biz_item_detailed (
    id                       varchar(64),
    flower_biz_item_id       varchar(64),    -- 软外键 → ods_flower_biz_item.id
    project_green_item_id    varchar(64),    -- 软外键 → p_project_green_item.id
    position_id              varchar(64),
    good_id                  varchar(64),
    good_name                varchar(255),
    plant_number             varchar(16),
    rent                     varchar(40),
    cost                     varchar(40),
    del_flag                 varchar(4),
    create_time              varchar(40),
    update_time              varchar(40),
    source_system            varchar(64) DEFAULT 'rs_cloud_flower',
    imported_at              timestamp DEFAULT now()
);

-- ─── 4. 变更单（t_change_info） ──────────────────────────────
DROP TABLE IF EXISTS xycyl_ods.ods_change_info CASCADE;
CREATE TABLE xycyl_ods.ods_change_info (
    id                       varchar(64),
    code                     varchar(64),    -- 变更单号
    biz_id                   varchar(64),    -- 软外键 → ods_flower_biz_info.id
    change_type              varchar(16),    -- 1销售金额 / 2库房物品类型 / 3成本 / 4起租减租
    before_total_amount      varchar(40),
    after_total_amount       varchar(40),
    before_settlement_time   varchar(40),
    after_settlement_time    varchar(40),
    status                   varchar(16),    -- 1 确认中 / 2 已结束 / -1 作废
    change_reason            varchar(2000),
    change_user_id           varchar(64),
    change_time              varchar(40),
    del_flag                 varchar(4),
    create_time              varchar(40),
    update_time              varchar(40),
    source_system            varchar(64) DEFAULT 'rs_cloud_flower',
    imported_at              timestamp DEFAULT now()
);

-- ─── 5. 回收主表（t_recovery_info） ──────────────────────────
DROP TABLE IF EXISTS xycyl_ods.ods_recovery_info CASCADE;
CREATE TABLE xycyl_ods.ods_recovery_info (
    id                       varchar(64),
    code                     varchar(64),
    biz_info_id              varchar(64),    -- 软外键 → ods_flower_biz_info.id
    distribution_user_id     varchar(64),    -- 配送人
    recovery_user_id         varchar(64),    -- 回收人
    recovery_user_name       varchar(255),
    store_house_id           varchar(64),    -- 入库目标库房
    store_house_name         varchar(255),
    plan_recovery_time       varchar(40),    -- 计划回收时间
    recovery_time            varchar(40),    -- 实际回收时间
    status                   varchar(16),    -- 1 待回收 / 2 确认入库 / 3 已结束
    del_flag                 varchar(4),
    create_time              varchar(40),
    update_time              varchar(40),
    source_system            varchar(64) DEFAULT 'rs_cloud_flower',
    imported_at              timestamp DEFAULT now()
);

-- ─── 6. 回收明细（t_recovery_info_item） ─────────────────────
DROP TABLE IF EXISTS xycyl_ods.ods_recovery_info_item CASCADE;
CREATE TABLE xycyl_ods.ods_recovery_info_item (
    id                       varchar(64),
    recovery_info_id         varchar(64),    -- 软外键 → ods_recovery_info.id
    biz_item_id              varchar(64),    -- 软外键 → ods_flower_biz_item.id
    good_id                  varchar(64),
    good_name                varchar(255),
    recovery_type            varchar(16),    -- 1 报损 / 2 回购 / 3 留用
    recovery_number          varchar(16),    -- 计划回收数
    real_recovery_number     varchar(16),    -- 实际回收数（业务关心）
    good_cost                varchar(40),    -- 单棵成本
    del_flag                 varchar(4),
    create_time              varchar(40),
    update_time              varchar(40),
    source_system            varchar(64) DEFAULT 'rs_cloud_flower',
    imported_at              timestamp DEFAULT now()
);

-- ─── 7a. 报花单操作日志（t_flower_biz_log） ──────────────────
-- 业务作用：审批/状态切换流水。回答"审批耗时"、"操作人"、"挂起原因"问题
DROP TABLE IF EXISTS xycyl_ods.ods_flower_biz_log CASCADE;
CREATE TABLE xycyl_ods.ods_flower_biz_log (
    id                       varchar(64),
    sorts                    varchar(16),    -- 顺序号
    biz_type                 varchar(16),    -- 报花业务类型（与 t_flower_biz_info.biz_type 一致）
    biz_id                   varchar(64),    -- 软外键 → ods_flower_biz_info.id
    status                   varchar(16),    -- 操作时该单据的状态
    operation_title          varchar(255),   -- 操作标题（提交/审核/驳回/备货/入库/结算...）
    operation_user_id        varchar(64),
    operation_user_name      varchar(255),
    operation_time           varchar(40),
    operation_content        varchar(2000),
    source_system            varchar(64) DEFAULT 'rs_cloud_flower',
    imported_at              timestamp DEFAULT now()
);

-- ─── 7b. 报花额外费用（t_flower_extra_cost） ─────────────────
-- 业务作用：报花单的运费/人工/税费/垃圾清理 等附加成本，影响真实成本核算
DROP TABLE IF EXISTS xycyl_ods.ods_flower_extra_cost CASCADE;
CREATE TABLE xycyl_ods.ods_flower_extra_cost (
    id                       varchar(64),
    biz_id                   varchar(64),    -- 软外键 → ods_flower_biz_info.id
    biz_type                 varchar(16),    -- 报花业务类型
    cost_type                varchar(16),    -- 1运费 / 2人工 / 3税费 / 4其他 / 5垃圾清理
    title                    varchar(255),   -- 费用名称
    free_amount              varchar(40),    -- 成本总金额（不含税）
    price_amount             varchar(40),    -- 含税金额
    tax_rate                 varchar(40),    -- 税率
    pay_user_id              varchar(64),
    pay_user_name            varchar(255),
    pay_time                 varchar(40),
    expense_id               varchar(64),    -- 报销单 id
    expense_code             varchar(64),    -- 报销单号
    del_flag                 varchar(4),
    create_time              varchar(40),
    update_time              varchar(40),
    source_system            varchar(64) DEFAULT 'rs_cloud_flower',
    imported_at              timestamp DEFAULT now()
);

-- ─── 8. 起租期变更日志（t_flower_rent_time_log） ──────────────
DROP TABLE IF EXISTS xycyl_ods.ods_flower_rent_time_log CASCADE;
CREATE TABLE xycyl_ods.ods_flower_rent_time_log (
    id                       varchar(64),
    biz_id                   varchar(64),    -- 软外键 → ods_flower_biz_info.id
    rent_time_type           varchar(16),    -- 1 起租 / 2 减租
    old_rent_time            varchar(40),
    new_rent_time            varchar(40),
    change_user_id           varchar(64),
    change_user_name         varchar(255),
    change_reason            varchar(2000),
    del_flag                 varchar(4),
    create_time              varchar(40),
    update_time              varchar(40),
    source_system            varchar(64) DEFAULT 'rs_cloud_flower',
    imported_at              timestamp DEFAULT now()
);

-- ─── 业务实体支持表（项目/客户/摆位/库房）的简化镜像 ─────────
-- 注：完整业务实体在后续 sprint（24 摆放域）建模，本 sprint 仅维持下游 JOIN 所需最小列
DROP TABLE IF EXISTS xycyl_ods.ods_project CASCADE;
CREATE TABLE xycyl_ods.ods_project (
    id            varchar(64),
    code          varchar(64),
    name          varchar(255),
    customer_id   varchar(64),
    customer_name varchar(255),
    project_manager_id   varchar(64),
    project_manager_name varchar(255),
    status        varchar(16),
    del_flag      varchar(4),
    source_system varchar(64) DEFAULT 'rs_cloud_flower',
    imported_at   timestamp DEFAULT now()
);

DROP TABLE IF EXISTS xycyl_ods.ods_customer CASCADE;
CREATE TABLE xycyl_ods.ods_customer (
    id            varchar(64),
    code          varchar(64),
    name          varchar(255),
    customer_type varchar(16),
    del_flag      varchar(4),
    source_system varchar(64) DEFAULT 'rs_cloud_flower',
    imported_at   timestamp DEFAULT now()
);
