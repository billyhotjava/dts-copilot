# 馨懿诚 报花域 dbt Model (xycyl-flowerbiz)

sprint-22 F4 主交付物。报花（flowerbiz）域 5 层 dbt 模型，标准 dbt 项目，现场部署使用。

## 业务背景

报花是馨懿诚绿植租摆业务的事实链源头：

```
报花 → 采购 → 配送/入库 → 摆放/养护 → 结算 → 收款
 ↑
 业务事实源头
```

报花单 `t_flower_biz_info` 是业务事实核心。**财务 settlement / month_accounting / customer_ar 都是报花的聚合衍生**。

## 目录结构

```text
dbt_model/
├── dbt_project.yml                           # dbt 项目配置（profile=dts，namespace=xycyl_flowerbiz）
├── README.md                                 # 本文件
├── model-governance.md                       # 建模分层与命名治理规则
├── macros/                                   # 通用宏（含 ensure_date_helpers / nullif_placeholder / parse_*_safe）
├── models/
│   ├── xycyl_flowerbiz_sources.yml           # ODS 源表声明（schema=xycyl_ods）
│   ├── xycyl_flowerbiz_stg.yml               # STG 字段与测试
│   ├── xycyl_flowerbiz_schema.yml            # DWD/DWS/ADS 字段与测试
│   ├── stg/                                  # 标准化层（view，11 张）
│   ├── dwd/                                  # 5 dim canonical + 5 dim alias + 6 biz fact
│   ├── dws/                                  # 主题汇总（table，3 张：project/customer/curing_user 月度）
│   └── ads/                                  # 看板 mart（10 张，按 sprint-22 mart-catalog + adminapi 实际覆盖）
└── ods_ddl/
    ├── ods_create_tables.sql                 # 11 张 ODS 镜像表 DDL（schema=xycyl_ods）
    ├── ods-field-mapping/                    # rs_cloud_flower 业务字段 → ODS 列映射
    └── ods-verify/                           # 各报花表字段口径核对文档
```

## 分层约定

```text
ODS (xycyl_ods.ods_*) → STG (view) → DWD (table) → DWS (table) → ADS (table/view)
```

- 全部 dbt 资产使用 `xycyl_` 前缀（参考 sprint-22 `assets/dts-stack-dbt-conventions.md`）
- `dwd/* / dws/* / ads/*` 禁止直接 `source(...)`，必须经 `xycyl_stg_*` 进入
- STG 强制保留来源元数据：`source_row_id / source_table / source_system / imported_at`
- 详细规则见 `model-governance.md`

## 部署流程

### 1. 在目标库执行 ODS 建表

```bash
psql "$DTS_PG_URL" -f ods_ddl/ods_create_tables.sql
```

执行后会得到 schema `xycyl_ods` 与 9 张 ODS 镜像表（全部 varchar）。生产环境由入湖任务向这些表写入 rs_cloud_flower 镜像数据。

### 2. 配置 dbt profile

确认 `~/.dbt/profiles.yml` 中存在 `dts` profile，且当前 target 指向现场库。建议 schema 配置：

```yaml
dts:
  outputs:
    prod:
      type: postgres
      host: <pg-host>
      user: <pg-user>
      password: <pg-pwd>
      port: 5432
      dbname: <db>
      schema: xycyl   # 项目层默认 schema；STG/DWD/DWS/ADS 实际落 xycyl_stg / xycyl_dwd / xycyl_dws / xycyl_ads
      threads: 4
```

`get_custom_schema` macro 会按 `xycyl_<layer>` 自动分发各层落地 schema。

### 3. 跑全量

```bash
dbt deps
dbt run --profile dts --select tag:xycyl-flowerbiz
dbt test --profile dts --select tag:xycyl-flowerbiz
```

### 4. 选择性运行某一层

```bash
# 仅 STG（view，几乎瞬完成）
dbt run --select tag:xycyl-flowerbiz,tag:stg

# 仅 ADS（mart 表，业务直接消费）
dbt run --select tag:xycyl-flowerbiz,tag:ads

# 仅租赁主题
dbt run --select tag:xycyl-flowerbiz,tag:lease

# 某 mart + 上游
dbt run --select +xycyl_ads_flowerbiz_lease_summary
```

## 与 dts-copilot / OpenMetadata 集成

| 场景 | 操作 |
|---|---|
| dts-copilot 直读 mart | 在 copilot_ai 注册"花卉报花 mart" datasource，schema=`xycyl_ads`，账号给 SELECT 权限 |
| OpenMetadata 拉取 manifest | services/dts-openmetadata/ingestion/xycyl_dbt.yml（sprint-22 F4-T04 落地） |
| dts-copilot 独立部署 | bin/export-dbt-artifacts.sh xycyl-flowerbiz → dist/xycyl-flowerbiz/ |

## 10 张 ads mart 速查

| # | 模型 | 粒度 | bizType | 物化 | 主要问句 |
|---|---|---|---|---|---|
| 1 | `xycyl_ads_flowerbiz_lease_summary` | 项目 × 客户 × 月 | 1/2/3/4 | table | 加摆撤摆净增减、月度报花趋势 |
| 2 | `xycyl_ads_flowerbiz_lease_detail` | 单据 × 摆位 × 绿植 | 1/2/3/4 | view | XX 项目最近报花、养护人 X 经手 |
| 3 | `xycyl_ads_flowerbiz_pending` | 单据 | 全部 | view | 审核中超 7 天、待结算清单 |
| 4 | `xycyl_ads_flowerbiz_sale_summary` | 项目 × 客户 × 月 | 7/8 | table | 销售金额、销售前 10、赠送数量 |
| 5 | `xycyl_ads_flowerbiz_baddebt_summary` | 项目 × 客户 × 月 | 6 | table | 坏账客户、坏账 TOP |
| 6 | `xycyl_ads_flowerbiz_change_log` | 变更单 | 全部 | view | 起租期变更、金额变更 |
| 7 | `xycyl_ads_flowerbiz_recovery_detail` | 回收明细 | 3/4 触发 | view | 回收清单、报损量、回购量 |
| 8 | `xycyl_ads_flowerbiz_curing_workload` | 养护人 × 月 | 全部 | table | 养护人工作量排行 |
| 9 | `xycyl_ads_flowerbiz_audit_trail` | 操作日志 | 全部 | view | 审批耗时、操作链路、X 单挂在哪一步 |
| 10 | `xycyl_ads_flowerbiz_extra_cost_summary` | 项目 × 客户 × 月 × cost_type | 全部 | table | 运费/人工/税费/垃圾清理/其他费用 |

## 与 sprint-22 边界

**本 zip 覆盖 11 张 rs_cloud_flower 报花域源表**（基于 adminapi rs-flowers-base/flowerbiz 模块代码盘点）：
- ✅ `t_flower_biz_info`, `t_flower_biz_item`, `t_flower_biz_item_detailed`
- ✅ `t_change_info`, `t_recovery_info`, `t_recovery_info_item`, `t_flower_rent_time_log`
- ✅ `t_flower_biz_log`（操作日志）, `t_flower_extra_cost`（额外费用）
- ✅ `p_project`, `p_customer`（简化镜像，sprint-24 摆放域将完整建模）

**不在本 sprint（明确归后续 sprint）**：
- `t_warehousing_info` / `t_warehousing_item` / `t_plan_purchase_info` → **sprint-23 采购域**
- `p_project_green` / `p_project_green_item` / `p_position` 完整建模 → **sprint-24 摆放域**
- `a_sale_account` / `a_flower_biz_accounting` / `a_month_accounting` / `t_settlement_info` → **sprint-25 财务域**
  - 注意：`a_flower_biz_accounting.biz_type` 体系**不同**于 `t_flower_biz_info.biz_type`：前者用 4=调减/5=调加，后者 4=调花（统称）
  - sprint-22 的 sale_summary 仅基于 t_flower_biz_info（"业务发起金额"），**实收/未收/开票**留 sprint-25 接 a_sale_account

## 参考

- 业务字段口径：`docs-copilot worklog/v1.0.0/sprint-22-202605/assets/flowerbiz-source-catalog.md`
- mart 设计清单：`worklog/v1.0.0/sprint-22-202605/assets/flowerbiz-mart-catalog.md`
- 命名 / tag 规范：`worklog/v1.0.0/sprint-22-202605/assets/dts-stack-dbt-conventions.md`
- 5 个口径决策：`worklog/v1.0.0/sprint-22-202605/assets/flowerbiz-caliber-decisions.md`
