{{ config(materialized='table', tags=['xycyl', 'finance', 'dws', 'monthly-summary']) }}

WITH settlement AS (
  SELECT
    business_month AS finance_month,
    project_id,
    project_name,
    count(*) AS settlement_record_count,
    sum(receivable_total_amount) AS receivable_before_discount,
    sum(folding_after_total_amount) AS discounted_receivable,
    sum(accounted_paid_amount) AS accounted_paid_amount,
    sum(net_receipt_total_amount) AS net_receipt_amount,
    sum(period_receivable_total_amount) AS period_receivable_amount,
    sum(add_receivable_total_amount) AS add_receivable_amount,
    sum(cut_receivable_total_amount) AS cut_receivable_amount,
    sum(adjust_receivable_total_amount) AS adjust_receivable_amount,
    sum(sale_receipt_total_amount) AS sale_receipt_amount
  FROM {{ ref('xycyl_dwd_finance_month_settlement') }}
  GROUP BY business_month, project_id, project_name
),
collection AS (
  SELECT
    collection_month AS finance_month,
    project_id,
    project_name,
    count(*) AS collection_record_count,
    sum(pay_amount) AS collection_amount
  FROM {{ ref('xycyl_dwd_finance_collection') }}
  WHERE collection_month IS NOT NULL
  GROUP BY collection_month, project_id, project_name
)
SELECT
  coalesce(s.finance_month, c.finance_month) AS finance_month,
  coalesce(s.project_id, c.project_id) AS project_id,
  coalesce(s.project_name, c.project_name, '未填项目') AS project_name,
  md5(
    coalesce(coalesce(s.finance_month, c.finance_month), '')
    || '|'
    || coalesce(coalesce(s.project_id, c.project_id)::text, coalesce(s.project_name, c.project_name, '未填项目'))
  ) AS project_key,
  coalesce(s.settlement_record_count, 0) AS settlement_record_count,
  coalesce(s.receivable_before_discount, 0) AS receivable_before_discount,
  coalesce(s.discounted_receivable, 0) AS discounted_receivable,
  coalesce(s.accounted_paid_amount, 0) AS accounted_paid_amount,
  coalesce(s.net_receipt_amount, 0) AS net_receipt_amount,
  coalesce(s.period_receivable_amount, 0) AS period_receivable_amount,
  coalesce(s.add_receivable_amount, 0) AS add_receivable_amount,
  coalesce(s.cut_receivable_amount, 0) AS cut_receivable_amount,
  coalesce(s.adjust_receivable_amount, 0) AS adjust_receivable_amount,
  coalesce(s.sale_receipt_amount, 0) AS sale_receipt_amount,
  coalesce(c.collection_record_count, 0) AS collection_record_count,
  coalesce(c.collection_amount, 0) AS collection_amount,
  coalesce(c.collection_amount, s.accounted_paid_amount, 0) AS paid_amount,
  greatest(coalesce(s.discounted_receivable, 0) - coalesce(c.collection_amount, s.accounted_paid_amount, 0), 0) AS unpaid_amount,
  CASE
    WHEN coalesce(s.discounted_receivable, 0) = 0 THEN 0::numeric
    ELSE round(coalesce(c.collection_amount, s.accounted_paid_amount, 0) * 1.0 / s.discounted_receivable, 4)
  END AS payment_progress,
  now() AS etl_time
FROM settlement s
FULL OUTER JOIN collection c
  ON s.finance_month = c.finance_month
 AND (
   (s.project_id IS NOT NULL AND c.project_id IS NOT NULL AND s.project_id = c.project_id)
   OR (s.project_id IS NULL AND c.project_id IS NULL AND s.project_name = c.project_name)
 )
