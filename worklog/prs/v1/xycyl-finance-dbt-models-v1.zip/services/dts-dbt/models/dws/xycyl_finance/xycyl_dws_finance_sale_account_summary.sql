{{ config(materialized='table', tags=['xycyl', 'finance', 'dws', 'sale-account-summary']) }}

SELECT
  business_month AS finance_month,
  project_id,
  project_name,
  count(*) AS sale_account_count,
  sum(receivable_amount) AS receivable_amount,
  sum(CASE WHEN invoice_status = 2 THEN receivable_amount ELSE 0 END) AS invoiced_amount,
  sum(CASE WHEN sale_status = 3 THEN receivable_amount ELSE 0 END) AS received_amount,
  sum(biz_amount) AS biz_amount,
  sum(net_receipts_amount) AS net_receipts_amount,
  sum(total_cost) AS total_cost,
  CASE
    WHEN coalesce(sum(receivable_amount), 0) = 0 THEN 0::numeric
    ELSE round(sum(CASE WHEN invoice_status = 2 THEN receivable_amount ELSE 0 END) * 1.0 / sum(receivable_amount), 4)
  END AS invoice_progress,
  CASE
    WHEN coalesce(sum(receivable_amount), 0) = 0 THEN 0::numeric
    ELSE round(sum(CASE WHEN sale_status = 3 THEN receivable_amount ELSE 0 END) * 1.0 / sum(receivable_amount), 4)
  END AS receipt_progress,
  now() AS etl_time
FROM {{ ref('xycyl_dwd_finance_sale_account') }}
GROUP BY business_month, project_id, project_name
