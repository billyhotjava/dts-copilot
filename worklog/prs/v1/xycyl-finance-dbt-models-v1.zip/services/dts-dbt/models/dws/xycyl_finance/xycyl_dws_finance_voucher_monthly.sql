{{ config(materialized='table', tags=['xycyl', 'finance', 'dws', 'voucher-monthly']) }}

WITH ledger AS (
  SELECT *
  FROM {{ ref('xycyl_dwd_finance_voucher_ledger') }}
),
voucher_balance AS (
  SELECT
    account_period,
    voucher_id,
    sum(debit_amount) AS voucher_debit_amount,
    sum(credit_amount) AS voucher_credit_amount
  FROM ledger
  GROUP BY account_period, voucher_id
)
SELECT
  l.account_period AS finance_month,
  coalesce(l.biz_type, 0) AS biz_type,
  coalesce(l.biz_type_name, '未分类') AS biz_type_name,
  coalesce(l.voucher_status, 0) AS voucher_status,
  coalesce(l.voucher_status_name, '未知') AS voucher_status_name,
  count(DISTINCT l.voucher_id) AS voucher_count,
  count(l.voucher_item_id) AS voucher_item_count,
  sum(l.debit_amount) AS debit_amount,
  sum(l.credit_amount) AS credit_amount,
  sum(l.debit_amount) - sum(l.credit_amount) AS balance_diff_amount,
  count(DISTINCT l.voucher_id) FILTER (
    WHERE abs(coalesce(vb.voucher_debit_amount, 0) - coalesce(vb.voucher_credit_amount, 0)) < 0.005
  ) AS balanced_voucher_count,
  count(DISTINCT l.voucher_id) FILTER (
    WHERE abs(coalesce(vb.voucher_debit_amount, 0) - coalesce(vb.voucher_credit_amount, 0)) >= 0.005
  ) AS unbalanced_voucher_count,
  now() AS etl_time
FROM ledger l
LEFT JOIN voucher_balance vb
  ON l.account_period = vb.account_period
 AND l.voucher_id = vb.voucher_id
GROUP BY
  l.account_period,
  coalesce(l.biz_type, 0),
  coalesce(l.biz_type_name, '未分类'),
  coalesce(l.voucher_status, 0),
  coalesce(l.voucher_status_name, '未知')
