{{ config(materialized='table', tags=['xycyl', 'finance', 'dwd', 'sale-account']) }}

WITH joined AS (
  SELECT
    a.sale_account_id,
    a.biz_id,
    b.biz_code,
    b.project_id,
    coalesce(b.project_name, '未填项目') AS project_name,
    b.biz_type,
    b.biz_status,
    a.settlement_type,
    a.sale_status,
    a.invoice_status,
    a.sale_finish_date,
    a.invoice_date,
    b.apply_date,
    b.finish_date AS biz_finish_date,
    CASE
      WHEN b.biz_code IS NOT NULL
        AND length(b.biz_code) >= 7
        AND SUBSTRING(b.biz_code, 2, 6) ~ '^\d{6}$'
        THEN SUBSTRING(b.biz_code, 2, 4) || '-' || SUBSTRING(b.biz_code, 6, 2)
      WHEN b.finish_date IS NOT NULL THEN to_char(b.finish_date, 'YYYY-MM')
      WHEN b.apply_date IS NOT NULL THEN to_char(b.apply_date, 'YYYY-MM')
      ELSE NULL
    END AS business_month,
    coalesce(a.receivable_amount, 0) AS receivable_amount,
    coalesce(a.biz_amount, 0) AS biz_amount,
    coalesce(a.net_receipts_amount, 0) AS net_receipts_amount,
    coalesce(a.total_cost, 0) AS total_cost,
    a.imported_at
  FROM {{ ref('xycyl_stg_finance_sale_account') }} a
  JOIN {{ ref('xycyl_stg_finance_flower_biz_info') }} b
    ON a.biz_id = b.flower_biz_id
  WHERE b.biz_type IN (5, 6, 7)
)
SELECT
  *,
  now() AS etl_time
FROM joined
WHERE business_month IS NOT NULL
