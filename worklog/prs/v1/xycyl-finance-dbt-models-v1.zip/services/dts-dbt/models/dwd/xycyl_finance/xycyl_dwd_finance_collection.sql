{{ config(materialized='table', tags=['xycyl', 'finance', 'dwd', 'collection']) }}

SELECT
  collection_record_id,
  collection_code,
  income_type,
  project_id,
  coalesce(project_name, '未填项目') AS project_name,
  collection_status,
  with_invoice,
  payment_type,
  pay_mode,
  collection_name,
  collection_bank_account,
  pay_date,
  to_char(pay_date, 'YYYY-MM') AS collection_month,
  coalesce(pay_amount, 0) AS pay_amount,
  create_by,
  create_date,
  update_by,
  update_date,
  remark,
  tenant_id,
  imported_at,
  now() AS etl_time
FROM {{ ref('xycyl_stg_finance_collection_record') }}
WHERE pay_amount IS NOT NULL
