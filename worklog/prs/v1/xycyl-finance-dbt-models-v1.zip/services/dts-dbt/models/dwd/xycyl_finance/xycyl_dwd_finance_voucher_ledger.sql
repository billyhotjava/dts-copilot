{{ config(materialized='table', tags=['xycyl', 'finance', 'dwd', 'voucher-ledger']) }}

WITH vouchers AS (
  SELECT *
  FROM {{ ref('xycyl_stg_finance_voucher') }}
),
active_items AS (
  SELECT *
  FROM {{ ref('xycyl_stg_finance_voucher_item') }}
  WHERE coalesce(item_status, 0) > 0
)
SELECT
  coalesce(v.voucher_id, i.voucher_id) AS voucher_id,
  i.voucher_item_id,
  coalesce(v.voucher_code, i.voucher_code) AS voucher_code,
  coalesce(v.account_period, i.account_period) AS account_period,
  CASE
    WHEN coalesce(v.account_period, i.account_period) IS NOT NULL
      THEN to_date(coalesce(v.account_period, i.account_period) || '-01', 'YYYY-MM-DD')
    ELSE NULL
  END AS account_month_start_date,
  v.biz_id,
  v.biz_code,
  v.biz_type,
  CASE
    WHEN v.biz_type = 1 THEN '结算'
    WHEN v.biz_type = 2 THEN '预支冲抵'
    WHEN v.biz_type IN (11) THEN '日常报销付款'
    WHEN v.biz_type IN (12, 13, 14) THEN '预支付款'
    WHEN v.biz_type IN (3, 15, 16) THEN '付款'
    WHEN v.biz_type = 17 THEN '采购报销付款'
    WHEN v.biz_type = 20 THEN '银行流水'
    WHEN v.biz_type = 30 THEN '手工凭证'
    ELSE '未分类'
  END AS biz_type_name,
  v.voucher_status,
  CASE
    WHEN v.voucher_status = 1 THEN '已提交'
    WHEN v.voucher_status = 2 THEN '已审核'
    WHEN v.voucher_status = 3 THEN '已记账'
    WHEN v.voucher_status = -1 THEN '已作废'
    ELSE '未知'
  END AS voucher_status_name,
  i.item_status,
  CASE
    WHEN i.item_status = 1 THEN '草稿'
    WHEN i.item_status = 2 THEN '已提交'
    WHEN i.item_status = 3 THEN '已审核'
    WHEN i.item_status = 4 THEN '已记账'
    WHEN i.item_status = -1 THEN '已作废'
    ELSE '未知'
  END AS item_status_name,
  i.subject_id,
  i.subject_code,
  i.gl_account,
  i.detail_account,
  v.voucher_description,
  i.item_description,
  coalesce(i.debit_amount, 0) AS debit_amount,
  coalesce(i.credit_amount, 0) AS credit_amount,
  coalesce(v.header_debit_amount, 0) AS header_debit_amount,
  coalesce(v.header_credit_amount, 0) AS header_credit_amount,
  v.create_date AS voucher_create_date,
  i.create_date AS item_create_date,
  greatest(coalesce(v.update_date, i.update_date), coalesce(i.update_date, v.update_date)) AS last_update_date,
  coalesce(v.imported_at, i.imported_at) AS imported_at,
  now() AS etl_time
FROM vouchers v
FULL OUTER JOIN active_items i
  ON v.voucher_id = i.voucher_id
WHERE coalesce(v.account_period, i.account_period) IS NOT NULL
  AND coalesce(v.voucher_code, i.voucher_code) IS NOT NULL
