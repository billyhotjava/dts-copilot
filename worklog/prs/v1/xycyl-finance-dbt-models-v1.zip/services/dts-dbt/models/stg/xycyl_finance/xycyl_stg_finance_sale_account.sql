{{ config(materialized='view', tags=['xycyl', 'finance', 'stg', 'sale-account']) }}

WITH typed AS (
  SELECT
    {{ parse_numeric_safe("id") }}::bigint AS sale_account_id,
    {{ parse_numeric_safe("biz_id") }}::bigint AS biz_id,
    {{ parse_numeric_safe("settlement_type") }}::int AS settlement_type,
    {{ parse_numeric_safe("status") }}::int AS sale_status,
    {{ parse_date_safe("finish_time") }} AS sale_finish_date,
    {{ parse_date_safe("update_time") }} AS update_date,
    {{ parse_numeric_safe("receivable_amount") }}::numeric(18,4) AS receivable_amount,
    {{ parse_numeric_safe("biz_amount") }}::numeric(18,4) AS biz_amount,
    {{ parse_numeric_safe("net_receipts_amount") }}::numeric(18,4) AS net_receipts_amount,
    {{ parse_numeric_safe("total_cost") }}::numeric(18,4) AS total_cost,
    {{ parse_numeric_safe("invoice_status") }}::int AS invoice_status,
    {{ nullif_placeholder("invoice_no") }} AS invoice_no,
    {{ parse_date_safe("invoice_time") }} AS invoice_date
  FROM {{ source('xycyl_finance_ods', 'sale_account') }}
)
SELECT
  md5(coalesce(sale_account_id::text, '') || '|a_sale_account') AS source_row_id,
  'ods_ptr_mysql_a_sale_account'::text AS source_table,
  'rs_cloud_flower'::text AS source_system,
  now() AS imported_at,
  *
FROM typed
WHERE sale_account_id IS NOT NULL
