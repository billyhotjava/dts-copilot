{{ config(materialized='view', tags=['xycyl', 'finance', 'stg', 'collection-record']) }}

WITH typed AS (
  SELECT
    {{ parse_numeric_safe("id") }}::bigint AS collection_record_id,
    {{ nullif_placeholder("code") }} AS collection_code,
    {{ parse_numeric_safe("income_type") }}::int AS income_type,
    {{ parse_numeric_safe("project_id") }}::bigint AS project_id,
    {{ nullif_placeholder("project_name") }} AS project_name,
    {{ parse_numeric_safe("status") }}::int AS collection_status,
    {{ parse_numeric_safe("with_invoice") }}::int AS with_invoice,
    {{ parse_numeric_safe("payment_type") }}::int AS payment_type,
    {{ nullif_placeholder("pay_mode") }} AS pay_mode,
    {{ nullif_placeholder("colloection_name") }} AS collection_name,
    {{ nullif_placeholder("colloection_bank_account") }} AS collection_bank_account,
    {{ parse_date_safe("pay_time") }} AS pay_date,
    {{ parse_numeric_safe("pay_amoney") }}::numeric(18,4) AS pay_amount,
    {{ parse_numeric_safe("create_by") }}::bigint AS create_by,
    {{ parse_date_safe("create_time") }} AS create_date,
    {{ parse_numeric_safe("update_by") }}::bigint AS update_by,
    {{ parse_date_safe("update_time") }} AS update_date,
    {{ nullif_placeholder("remark") }} AS remark,
    {{ parse_numeric_safe("tenant_id") }}::bigint AS tenant_id
  FROM {{ source('xycyl_finance_ods', 'collection_record') }}
)
SELECT
  md5(coalesce(collection_record_id::text, '') || '|a_collection_record') AS source_row_id,
  'ods_ptr_mysql_a_collection_record'::text AS source_table,
  'rs_cloud_flower'::text AS source_system,
  now() AS imported_at,
  *
FROM typed
WHERE collection_record_id IS NOT NULL
