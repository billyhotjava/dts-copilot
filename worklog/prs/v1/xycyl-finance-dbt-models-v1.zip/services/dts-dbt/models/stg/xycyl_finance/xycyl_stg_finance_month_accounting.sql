{{ config(materialized='view', tags=['xycyl', 'finance', 'stg', 'month-accounting']) }}

WITH typed AS (
  SELECT
    {{ parse_numeric_safe("id") }}::bigint AS month_accounting_id,
    {{ nullif_placeholder("company_name") }} AS company_name,
    {{ parse_numeric_safe("project_id") }}::bigint AS project_id,
    {{ nullif_placeholder("project_name") }} AS project_name,
    {{ parse_numeric_safe("settlement_year") }}::int AS settlement_year,
    {{ parse_numeric_safe("settlement_month") }}::int AS settlement_month,
    {{ nullif_placeholder("year_and_month") }} AS year_and_month_raw,
    {{ parse_numeric_safe("status") }}::int AS settlement_status,
    {{ parse_date_safe("start_time") }} AS start_date,
    {{ parse_date_safe("end_time") }} AS end_date,
    {{ parse_numeric_safe("total_day") }}::int AS total_day,
    {{ parse_numeric_safe("project_manage_user_id") }}::bigint AS project_manage_user_id,
    {{ nullif_placeholder("project_manage_user_name") }} AS project_manage_user_name,
    {{ parse_numeric_safe("supervise_user_id") }}::bigint AS supervise_user_id,
    {{ nullif_placeholder("supervise_user_name") }} AS supervise_user_name,
    {{ parse_numeric_safe("biz_user_id") }}::bigint AS biz_user_id,
    {{ nullif_placeholder("biz_user_name") }} AS biz_user_name,
    {{ parse_numeric_safe("discount_rate") }}::numeric(12,4) AS discount_rate,
    {{ parse_numeric_safe("bit_number") }}::int AS position_count,
    {{ parse_numeric_safe("rent_type") }}::int AS rent_type,
    {{ parse_numeric_safe("regular_rent") }}::numeric(18,4) AS regular_rent,
    {{ parse_numeric_safe("receivable_total_amount") }}::numeric(18,4) AS receivable_total_amount,
    {{ parse_numeric_safe("net_receipt_total_amount") }}::numeric(18,4) AS net_receipt_total_amount,
    {{ parse_numeric_safe("folding_after_total_amount") }}::numeric(18,4) AS folding_after_total_amount,
    {{ parse_numeric_safe("period_total_amount") }}::numeric(18,4) AS period_total_amount,
    {{ parse_numeric_safe("period_receivable_total_amount") }}::numeric(18,4) AS period_receivable_total_amount,
    {{ parse_numeric_safe("period_net_receivable_total_amount") }}::numeric(18,4) AS period_net_receivable_total_amount,
    {{ parse_numeric_safe("add_total_amount") }}::numeric(18,4) AS add_total_amount,
    {{ parse_numeric_safe("add_receivable_total_amount") }}::numeric(18,4) AS add_receivable_total_amount,
    {{ parse_numeric_safe("add_net_receipt_total_amount") }}::numeric(18,4) AS add_net_receipt_total_amount,
    {{ parse_numeric_safe("cut_total_amount") }}::numeric(18,4) AS cut_total_amount,
    {{ parse_numeric_safe("cut_receivable_total_amount") }}::numeric(18,4) AS cut_receivable_total_amount,
    {{ parse_numeric_safe("cut_net_receipt_total_amount") }}::numeric(18,4) AS cut_net_receipt_total_amount,
    {{ parse_numeric_safe("adjust_total_amount") }}::numeric(18,4) AS adjust_total_amount,
    {{ parse_numeric_safe("adjust_receivable_total_amount") }}::numeric(18,4) AS adjust_receivable_total_amount,
    {{ parse_numeric_safe("adjust_net_receipt_total_amount") }}::numeric(18,4) AS adjust_net_receipt_total_amount,
    {{ parse_numeric_safe("sale_total_amount") }}::numeric(18,4) AS sale_total_amount,
    {{ parse_numeric_safe("sale_receipt_total_amount") }}::numeric(18,4) AS sale_receipt_total_amount,
    {{ parse_numeric_safe("sale_net_receipt_total_amount") }}::numeric(18,4) AS sale_net_receipt_total_amount,
    {{ parse_date_safe("update_time") }} AS update_date,
    {{ parse_numeric_safe("total_amount") }}::numeric(18,4) AS accounted_paid_amount
  FROM {{ source('xycyl_finance_ods', 'month_accounting') }}
),
normalized AS (
  SELECT
    *,
    CASE
      WHEN settlement_year BETWEEN 1900 AND 2999 AND settlement_month BETWEEN 1 AND 12
        THEN settlement_year::text || '-' || lpad(settlement_month::text, 2, '0')
      WHEN year_and_month_raw ~ '^\d{4}-\d{2}$'
        AND substr(year_and_month_raw, 6, 2)::int BETWEEN 1 AND 12
        THEN year_and_month_raw
      WHEN year_and_month_raw ~ '^\d{6}$'
        AND substr(year_and_month_raw, 5, 2)::int BETWEEN 1 AND 12
        THEN substr(year_and_month_raw, 1, 4) || '-' || substr(year_and_month_raw, 5, 2)
      ELSE NULL
    END AS business_month
  FROM typed
)
SELECT
  md5(coalesce(month_accounting_id::text, '') || '|a_month_accounting') AS source_row_id,
  'ods_ptr_mysql_a_month_accounting'::text AS source_table,
  'rs_cloud_flower'::text AS source_system,
  now() AS imported_at,
  *
FROM normalized
WHERE month_accounting_id IS NOT NULL
