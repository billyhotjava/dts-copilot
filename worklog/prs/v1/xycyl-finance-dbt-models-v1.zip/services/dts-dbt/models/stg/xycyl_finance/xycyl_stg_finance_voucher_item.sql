{{ config(materialized='view', tags=['xycyl', 'finance', 'stg', 'voucher-item']) }}

WITH typed AS (
  SELECT
    {{ parse_numeric_safe("id") }}::bigint AS voucher_item_id,
    {{ parse_numeric_safe("voucher_id") }}::bigint AS voucher_id,
    {{ nullif_placeholder("voucher_code") }} AS voucher_code,
    {{ nullif_placeholder("account_priod") }} AS account_period_raw,
    {{ parse_numeric_safe("subject_id") }}::bigint AS subject_id,
    {{ nullif_placeholder("subject_code") }} AS subject_code,
    {{ nullif_placeholder("description") }} AS item_description,
    {{ nullif_placeholder("gl_account") }} AS gl_account,
    {{ nullif_placeholder("detail_account") }} AS detail_account,
    {{ parse_numeric_safe("debit_amount") }}::numeric(18,4) AS debit_amount,
    {{ parse_numeric_safe("credit_amount") }}::numeric(18,4) AS credit_amount,
    {{ nullif_placeholder("memo") }} AS item_memo,
    {{ parse_numeric_safe("status") }}::int AS item_status,
    {{ parse_numeric_safe("create_by") }}::bigint AS create_by,
    {{ parse_date_safe("create_time") }} AS create_date,
    {{ parse_numeric_safe("update_by") }}::bigint AS update_by,
    {{ parse_date_safe("update_time") }} AS update_date,
    {{ nullif_placeholder("remark") }} AS remark
  FROM {{ source('xycyl_finance_ods', 'voucher_item') }}
),
normalized AS (
  SELECT
    *,
    CASE
      WHEN account_period_raw ~ '^\d{4}-\d{2}$'
        AND substr(account_period_raw, 6, 2)::int BETWEEN 1 AND 12
        THEN account_period_raw
      WHEN account_period_raw ~ '^\d{4}-\d{1}$'
        AND substr(account_period_raw, 6, 1)::int BETWEEN 1 AND 9
        THEN substr(account_period_raw, 1, 5) || '0' || substr(account_period_raw, 6, 1)
      WHEN account_period_raw ~ '^\d{6}$'
        AND substr(account_period_raw, 5, 2)::int BETWEEN 1 AND 12
        THEN substr(account_period_raw, 1, 4) || '-' || substr(account_period_raw, 5, 2)
      ELSE NULL
    END AS account_period
  FROM typed
)
SELECT
  md5(coalesce(voucher_item_id::text, '') || '|f_voucher_item') AS source_row_id,
  'ods_ptr_mysql_f_voucher_item'::text AS source_table,
  'rs_cloud_flower'::text AS source_system,
  now() AS imported_at,
  *
FROM normalized
WHERE voucher_item_id IS NOT NULL
