{{ config(materialized='view', tags=['xycyl', 'finance', 'stg', 'voucher']) }}

WITH typed AS (
  SELECT
    {{ parse_numeric_safe("id") }}::bigint AS voucher_id,
    {{ nullif_placeholder("code") }} AS voucher_code,
    {{ nullif_placeholder("account_priod") }} AS account_period_raw,
    {{ parse_numeric_safe("biz_id") }}::bigint AS biz_id,
    {{ nullif_placeholder("biz_code") }} AS biz_code,
    {{ parse_numeric_safe("biz_type") }}::int AS biz_type,
    {{ nullif_placeholder("description") }} AS voucher_description,
    {{ nullif_placeholder("memo") }} AS voucher_memo,
    {{ parse_numeric_safe("status") }}::int AS voucher_status,
    {{ parse_numeric_safe("total_debit_amount") }}::numeric(18,4) AS header_debit_amount,
    {{ parse_numeric_safe("total_credit_amount") }}::numeric(18,4) AS header_credit_amount,
    {{ parse_numeric_safe("create_by") }}::bigint AS create_by,
    {{ parse_date_safe("create_time") }} AS create_date,
    {{ parse_numeric_safe("update_by") }}::bigint AS update_by,
    {{ parse_date_safe("update_time") }} AS update_date,
    {{ nullif_placeholder("remark") }} AS remark
  FROM {{ source('xycyl_finance_ods', 'voucher') }}
),
normalized AS (
  SELECT
    *,
    CASE
      WHEN account_period_raw ~ '^\d{4}-\d{2}$'
        AND substr(account_period_raw, 6, 2)::int BETWEEN 1 AND 12
        THEN account_period_raw
      WHEN account_period_raw ~ '^\d{4}-\d{1}$'
        AND substr(account_period_raw, 6, 1)::int BETWEEN 1 AND 9
        THEN substr(account_period_raw, 1, 5) || '0' || substr(account_period_raw, 6, 1)
      WHEN account_period_raw ~ '^\d{6}$'
        AND substr(account_period_raw, 5, 2)::int BETWEEN 1 AND 12
        THEN substr(account_period_raw, 1, 4) || '-' || substr(account_period_raw, 5, 2)
      ELSE NULL
    END AS account_period
  FROM typed
)
SELECT
  md5(coalesce(voucher_id::text, '') || '|f_voucher') AS source_row_id,
  'ods_ptr_mysql_f_voucher'::text AS source_table,
  'rs_cloud_flower'::text AS source_system,
  now() AS imported_at,
  *
FROM normalized
WHERE voucher_id IS NOT NULL
