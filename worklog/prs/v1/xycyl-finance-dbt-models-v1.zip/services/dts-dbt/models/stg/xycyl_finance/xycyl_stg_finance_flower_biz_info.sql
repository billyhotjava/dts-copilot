{{ config(materialized='view', tags=['xycyl', 'finance', 'stg', 'flower-biz-info']) }}

WITH typed AS (
  SELECT
    {{ parse_numeric_safe("id") }}::bigint AS flower_biz_id,
    {{ parse_numeric_safe("project_id") }}::bigint AS project_id,
    {{ nullif_placeholder("project_name") }} AS project_name,
    {{ nullif_placeholder("code") }} AS biz_code,
    {{ parse_numeric_safe("biz_type") }}::int AS biz_type,
    {{ parse_date_safe("apply_time") }} AS apply_date,
    {{ parse_date_safe("finish_time") }} AS finish_date,
    {{ parse_numeric_safe("status") }}::int AS biz_status,
    {{ nullif_placeholder("del_flag") }} AS del_flag
  FROM {{ source('xycyl_finance_ods', 'flower_biz_info') }}
)
SELECT
  md5(coalesce(flower_biz_id::text, '') || '|t_flower_biz_info') AS source_row_id,
  'ods_ptr_mysql_t_flower_biz_info'::text AS source_table,
  'rs_cloud_flower'::text AS source_system,
  now() AS imported_at,
  *
FROM typed
WHERE flower_biz_id IS NOT NULL
