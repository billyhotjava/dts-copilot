{{ config(materialized='table', tags=['xycyl', 'finance', 'ads', 'sale-account-summary']) }}

SELECT
  finance_month AS "业务月份",
  project_id AS "projectId",
  project_name AS "项目",
  sale_account_count AS "售账单数",
  round(receivable_amount, 2) AS "应收金额",
  round(invoiced_amount, 2) AS "已开票金额",
  round(received_amount, 2) AS "已回款金额",
  round(biz_amount, 2) AS "业务金额",
  round(net_receipts_amount, 2) AS "净收金额",
  round(total_cost, 2) AS "总成本",
  round(invoice_progress, 4) AS "开票进度",
  round(receipt_progress, 4) AS "回款进度",
  etl_time
FROM {{ ref('xycyl_dws_finance_sale_account_summary') }}
ORDER BY finance_month, project_name
