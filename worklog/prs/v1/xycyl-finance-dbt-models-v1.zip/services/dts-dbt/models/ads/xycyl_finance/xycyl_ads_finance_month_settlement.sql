{{ config(materialized='table', tags=['xycyl', 'finance', 'ads', 'month-settlement']) }}

SELECT
  finance_month AS "业务月份",
  project_id AS "projectId",
  project_name AS "项目",
  settlement_record_count AS "结算单数",
  round(receivable_before_discount, 2) AS "应收折前",
  round(discounted_receivable, 2) AS "折后实收",
  round(paid_amount, 2) AS "已回款",
  round(unpaid_amount, 2) AS "未回款",
  round(payment_progress, 4) AS "回款进度",
  round(net_receipt_amount, 2) AS "净收金额",
  round(period_receivable_amount, 2) AS "本期应收",
  round(add_receivable_amount, 2) AS "加摆应收",
  round(cut_receivable_amount, 2) AS "撤摆应收",
  round(adjust_receivable_amount, 2) AS "调整应收",
  round(sale_receipt_amount, 2) AS "售卖回款",
  etl_time
FROM {{ ref('xycyl_dws_finance_monthly_summary') }}
WHERE settlement_record_count > 0
ORDER BY finance_month, project_name
