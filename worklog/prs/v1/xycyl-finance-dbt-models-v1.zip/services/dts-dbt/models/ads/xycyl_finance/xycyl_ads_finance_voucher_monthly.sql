{{ config(materialized='table', tags=['xycyl', 'finance', 'ads', 'voucher-monthly']) }}

SELECT
  finance_month AS "会计月份",
  biz_type_name AS "业务类型",
  voucher_status_name AS "凭证状态",
  voucher_count AS "凭证数",
  voucher_item_count AS "分录数",
  round(debit_amount, 2) AS "借方金额",
  round(credit_amount, 2) AS "贷方金额",
  round(balance_diff_amount, 2) AS "借贷差额",
  balanced_voucher_count AS "平衡凭证数",
  unbalanced_voucher_count AS "不平衡凭证数",
  CASE
    WHEN abs(balance_diff_amount) < 0.005 THEN '平衡'
    ELSE '不平衡'
  END AS "是否平衡",
  etl_time
FROM {{ ref('xycyl_dws_finance_voucher_monthly') }}
ORDER BY finance_month, biz_type_name, voucher_status_name
