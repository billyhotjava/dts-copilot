{{ config(materialized='table', tags=['xycyl', 'finance', 'ads', 'collection']) }}

SELECT
  finance_month AS "收款月份",
  project_name AS "项目",
  round(collection_amount, 2) AS "收款金额",
  collection_record_count AS "收款单数",
  round(paid_amount, 2) AS "结算匹配回款",
  round(discounted_receivable, 2) AS "折后实收",
  round(payment_progress, 4) AS "回款进度",
  etl_time
FROM {{ ref('xycyl_dws_finance_monthly_summary') }}
WHERE collection_record_count > 0
ORDER BY finance_month, project_name
