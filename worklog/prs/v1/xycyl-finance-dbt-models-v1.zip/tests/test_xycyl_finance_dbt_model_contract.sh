#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
MODELS_DIR="$ROOT_DIR/services/dts-dbt/models"
DBT_PROJECT="$ROOT_DIR/services/dts-dbt/dbt_project.yml"
MACROS_DIR="$ROOT_DIR/services/dts-dbt/macros"

required_files=(
  "$MACROS_DIR/ensure_date_helpers.sql"
  "$MODELS_DIR/xycyl_finance_sources.yml"
  "$MODELS_DIR/xycyl_finance_stg.yml"
  "$MODELS_DIR/xycyl_finance_schema.yml"
  "$MODELS_DIR/stg/xycyl_finance/xycyl_stg_finance_month_accounting.sql"
  "$MODELS_DIR/stg/xycyl_finance/xycyl_stg_finance_collection_record.sql"
  "$MODELS_DIR/stg/xycyl_finance/xycyl_stg_finance_sale_account.sql"
  "$MODELS_DIR/stg/xycyl_finance/xycyl_stg_finance_flower_biz_info.sql"
  "$MODELS_DIR/stg/xycyl_finance/xycyl_stg_finance_voucher.sql"
  "$MODELS_DIR/stg/xycyl_finance/xycyl_stg_finance_voucher_item.sql"
  "$MODELS_DIR/dwd/xycyl_finance/xycyl_dwd_finance_month_settlement.sql"
  "$MODELS_DIR/dwd/xycyl_finance/xycyl_dwd_finance_collection.sql"
  "$MODELS_DIR/dwd/xycyl_finance/xycyl_dwd_finance_sale_account.sql"
  "$MODELS_DIR/dwd/xycyl_finance/xycyl_dwd_finance_voucher_ledger.sql"
  "$MODELS_DIR/dws/xycyl_finance/xycyl_dws_finance_monthly_summary.sql"
  "$MODELS_DIR/dws/xycyl_finance/xycyl_dws_finance_sale_account_summary.sql"
  "$MODELS_DIR/dws/xycyl_finance/xycyl_dws_finance_voucher_monthly.sql"
  "$MODELS_DIR/ads/xycyl_finance/xycyl_ads_finance_month_settlement.sql"
  "$MODELS_DIR/ads/xycyl_finance/xycyl_ads_finance_collection.sql"
  "$MODELS_DIR/ads/xycyl_finance/xycyl_ads_sale_account_summary.sql"
  "$MODELS_DIR/ads/xycyl_finance/xycyl_ads_finance_voucher_monthly.sql"
)

for file in "${required_files[@]}"; do
  [[ -f "$file" ]] || {
    echo "[xycyl-finance-dbt] missing required model file: ${file#$ROOT_DIR/}" >&2
    exit 1
  }
done

grep -q "xycyl_stg_finance_month_accounting:" "$DBT_PROJECT"
grep -q "xycyl_stg_finance_collection_record:" "$DBT_PROJECT"
grep -q "xycyl_dwd_finance_month_settlement:" "$DBT_PROJECT"
grep -q "xycyl_dwd_finance_collection:" "$DBT_PROJECT"
grep -q "xycyl_dws_finance_monthly_summary:" "$DBT_PROJECT"
grep -q "xycyl_ads_finance_month_settlement:" "$DBT_PROJECT"
grep -q "xycyl_ads_finance_collection:" "$DBT_PROJECT"
if [[ "$(grep -c '+enabled: false' "$DBT_PROJECT")" -lt 7 ]]; then
  echo "[xycyl-finance-dbt] legacy duplicate finance model nodes must stay disabled in dbt_project.yml" >&2
  exit 1
fi

grep -q 'identifier: "ods_ptr_mysql_a_month_accounting"' "$MODELS_DIR/xycyl_finance_sources.yml"
grep -q 'identifier: "ods_ptr_mysql_a_collection_record"' "$MODELS_DIR/xycyl_finance_sources.yml"
grep -q 'identifier: "ods_ptr_mysql_a_sale_account"' "$MODELS_DIR/xycyl_finance_sources.yml"
grep -q 'identifier: "ods_ptr_mysql_t_flower_biz_info"' "$MODELS_DIR/xycyl_finance_sources.yml"
grep -q 'identifier: "ods_ptr_mysql_f_voucher"' "$MODELS_DIR/xycyl_finance_sources.yml"
grep -q 'identifier: "ods_ptr_mysql_f_voucher_item"' "$MODELS_DIR/xycyl_finance_sources.yml"
grep -q 'name: "receivable_total_amount"' "$MODELS_DIR/xycyl_finance_sources.yml"
grep -q 'name: "folding_after_total_amount"' "$MODELS_DIR/xycyl_finance_sources.yml"
grep -q 'name: "total_amount"' "$MODELS_DIR/xycyl_finance_sources.yml"
grep -q 'name: "pay_amoney"' "$MODELS_DIR/xycyl_finance_sources.yml"
grep -q 'name: "colloection_bank_account"' "$MODELS_DIR/xycyl_finance_sources.yml"
grep -q 'name: "receivable_amount"' "$MODELS_DIR/xycyl_finance_sources.yml"
grep -q 'name: "biz_type"' "$MODELS_DIR/xycyl_finance_sources.yml"
grep -q 'name: "account_priod"' "$MODELS_DIR/xycyl_finance_sources.yml"
grep -q 'name: "voucher_code"' "$MODELS_DIR/xycyl_finance_sources.yml"
grep -q 'name: "debit_amount"' "$MODELS_DIR/xycyl_finance_sources.yml"
grep -q 'name: "credit_amount"' "$MODELS_DIR/xycyl_finance_sources.yml"
grep -q '状态: 1待确认/2已对账/3开票中/4待回款/5已回款' "$MODELS_DIR/xycyl_finance_sources.yml"

grep -q "ref('xycyl_stg_finance_month_accounting')" "$MODELS_DIR/dwd/xycyl_finance/xycyl_dwd_finance_month_settlement.sql"
grep -q "ref('xycyl_stg_finance_collection_record')" "$MODELS_DIR/dwd/xycyl_finance/xycyl_dwd_finance_collection.sql"
grep -q "ref('xycyl_stg_finance_sale_account')" "$MODELS_DIR/dwd/xycyl_finance/xycyl_dwd_finance_sale_account.sql"
grep -q "ref('xycyl_stg_finance_flower_biz_info')" "$MODELS_DIR/dwd/xycyl_finance/xycyl_dwd_finance_sale_account.sql"
grep -q "biz_type IN (5, 6, 7)" "$MODELS_DIR/dwd/xycyl_finance/xycyl_dwd_finance_sale_account.sql"
grep -q "SUBSTRING(b.biz_code, 2, 6)" "$MODELS_DIR/dwd/xycyl_finance/xycyl_dwd_finance_sale_account.sql"
grep -q "ref('xycyl_stg_finance_voucher')" "$MODELS_DIR/dwd/xycyl_finance/xycyl_dwd_finance_voucher_ledger.sql"
grep -q "ref('xycyl_stg_finance_voucher_item')" "$MODELS_DIR/dwd/xycyl_finance/xycyl_dwd_finance_voucher_ledger.sql"
grep -q "v.voucher_id = i.voucher_id" "$MODELS_DIR/dwd/xycyl_finance/xycyl_dwd_finance_voucher_ledger.sql"
! grep -q "v.voucher_code = i.voucher_code" "$MODELS_DIR/dwd/xycyl_finance/xycyl_dwd_finance_voucher_ledger.sql"
grep -q "ref('xycyl_dwd_finance_month_settlement')" "$MODELS_DIR/dws/xycyl_finance/xycyl_dws_finance_monthly_summary.sql"
grep -q "ref('xycyl_dwd_finance_collection')" "$MODELS_DIR/dws/xycyl_finance/xycyl_dws_finance_monthly_summary.sql"
grep -q "ref('xycyl_dwd_finance_sale_account')" "$MODELS_DIR/dws/xycyl_finance/xycyl_dws_finance_sale_account_summary.sql"
grep -q "ref('xycyl_dwd_finance_voucher_ledger')" "$MODELS_DIR/dws/xycyl_finance/xycyl_dws_finance_voucher_monthly.sql"
grep -q "GROUP BY account_period, voucher_id" "$MODELS_DIR/dws/xycyl_finance/xycyl_dws_finance_voucher_monthly.sql"
grep -q "count(DISTINCT l.voucher_id) AS voucher_count" "$MODELS_DIR/dws/xycyl_finance/xycyl_dws_finance_voucher_monthly.sql"
grep -q "s.project_id = c.project_id" "$MODELS_DIR/dws/xycyl_finance/xycyl_dws_finance_monthly_summary.sql"
! grep -q "AND s.project_name = c.project_name" "$MODELS_DIR/dws/xycyl_finance/xycyl_dws_finance_monthly_summary.sql"
for optional_column in \
  'parse_numeric_safe("department_id")' \
  'nullif_placeholder("department_name")' \
  'parse_numeric_safe("contract_id")'
do
  if grep -q "$optional_column" "$MODELS_DIR/stg/xycyl_finance/xycyl_stg_finance_month_accounting.sql"; then
    echo "[xycyl-finance-dbt] STG model must not query optional source column: $optional_column" >&2
    exit 1
  fi
done

grep -q "ref('xycyl_dws_finance_monthly_summary')" "$MODELS_DIR/ads/xycyl_finance/xycyl_ads_finance_month_settlement.sql"
grep -q "ref('xycyl_dws_finance_monthly_summary')" "$MODELS_DIR/ads/xycyl_finance/xycyl_ads_finance_collection.sql"
grep -q "ref('xycyl_dws_finance_sale_account_summary')" "$MODELS_DIR/ads/xycyl_finance/xycyl_ads_sale_account_summary.sql"
grep -q "ref('xycyl_dws_finance_voucher_monthly')" "$MODELS_DIR/ads/xycyl_finance/xycyl_ads_finance_voucher_monthly.sql"
grep -q 'project_id AS "projectId"' "$MODELS_DIR/ads/xycyl_finance/xycyl_ads_finance_month_settlement.sql"
grep -q 'project_id AS "projectId"' "$MODELS_DIR/ads/xycyl_finance/xycyl_ads_sale_account_summary.sql"
grep -q '"应收金额"' "$MODELS_DIR/ads/xycyl_finance/xycyl_ads_sale_account_summary.sql"
grep -q '"会计月份"' "$MODELS_DIR/ads/xycyl_finance/xycyl_ads_finance_voucher_monthly.sql"
grep -q '"凭证数"' "$MODELS_DIR/ads/xycyl_finance/xycyl_ads_finance_voucher_monthly.sql"
grep -q '"借贷差额"' "$MODELS_DIR/ads/xycyl_finance/xycyl_ads_finance_voucher_monthly.sql"

if grep -R "mysql.rs_cloud_flower" "$MODELS_DIR" >/dev/null; then
  echo "[xycyl-finance-dbt] dbt models must not query application MySQL directly" >&2
  exit 1
fi

echo "[xycyl-finance-dbt] contract ok"
