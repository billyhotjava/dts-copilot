{{ config(materialized='table', tags=['xycyl', 'xycyl-flowerbiz', 'ads', 'finance', 'cost', 'fixed_report']) }}

-- PRS 销售坏账与费用看板固定报表入口。
-- 粒度：业务月份 × 项目 × 客户。
-- 合并销售/赠送、坏账、额外费用三类 ADS，避免固定报表只预览单一坏账表。

WITH sale AS (
  SELECT
    年份,
    业务月份,
    项目,
    客户,
    SUM(总单数) AS 销售相关单数,
    SUM(销售单数) AS 销售单数,
    SUM(赠送单数) AS 赠送单数,
    SUM(销售金额全口径) AS 销售金额全口径,
    SUM(销售成本全口径) AS 销售成本全口径,
    SUM(赠送成本全口径) AS 赠送成本全口径
  FROM {{ ref('xycyl_ads_flowerbiz_sale_summary') }}
  GROUP BY 年份, 业务月份, 项目, 客户
),
baddebt AS (
  SELECT
    年份,
    业务月份,
    项目,
    客户,
    SUM(坏账单数) AS 坏账单数,
    SUM(坏账成本全口径) AS 坏账成本全口径,
    SUM(坏账租金损失全口径) AS 坏账租金损失全口径
  FROM {{ ref('xycyl_ads_flowerbiz_baddebt_summary') }}
  GROUP BY 年份, 业务月份, 项目, 客户
),
extra AS (
  SELECT
    年份,
    业务月份,
    项目,
    客户,
    SUM(涉及单数) AS 额外费用涉及单数,
    SUM(费用条数) AS 费用条数,
    SUM(不含税成本合计) AS 不含税成本合计,
    SUM(含税金额合计) AS 含税金额合计,
    SUM(运费合计) AS 运费合计,
    SUM(人工费合计) AS 人工费合计,
    SUM(垃圾清理费合计) AS 垃圾清理费合计,
    SUM(其他费用合计) AS 其他费用合计
  FROM {{ ref('xycyl_ads_flowerbiz_extra_cost_summary') }}
  GROUP BY 年份, 业务月份, 项目, 客户
),
keys AS (
  SELECT 年份, 业务月份, 项目, 客户 FROM sale
  UNION
  SELECT 年份, 业务月份, 项目, 客户 FROM baddebt
  UNION
  SELECT 年份, 业务月份, 项目, 客户 FROM extra
)

SELECT
  k.年份,
  k.业务月份,
  k.项目,
  k.客户,

  COALESCE(s.销售相关单数, 0) AS 销售相关单数,
  COALESCE(s.销售单数, 0) AS 销售单数,
  COALESCE(s.赠送单数, 0) AS 赠送单数,
  ROUND(COALESCE(s.销售金额全口径, 0), 2) AS 销售金额全口径,
  ROUND(COALESCE(s.销售成本全口径, 0), 2) AS 销售成本全口径,
  ROUND(COALESCE(s.赠送成本全口径, 0), 2) AS 赠送成本全口径,

  COALESCE(b.坏账单数, 0) AS 坏账单数,
  ROUND(COALESCE(b.坏账成本全口径, 0), 2) AS 坏账成本全口径,
  ROUND(COALESCE(b.坏账租金损失全口径, 0), 2) AS 坏账租金损失全口径,

  COALESCE(e.额外费用涉及单数, 0) AS 额外费用涉及单数,
  COALESCE(e.费用条数, 0) AS 费用条数,
  ROUND(COALESCE(e.不含税成本合计, 0), 2) AS 不含税成本合计,
  ROUND(COALESCE(e.含税金额合计, 0), 2) AS 含税金额合计,
  ROUND(COALESCE(e.运费合计, 0), 2) AS 运费合计,
  ROUND(COALESCE(e.人工费合计, 0), 2) AS 人工费合计,
  ROUND(COALESCE(e.垃圾清理费合计, 0), 2) AS 垃圾清理费合计,
  ROUND(COALESCE(e.其他费用合计, 0), 2) AS 其他费用合计,

  ROUND(
    COALESCE(s.销售成本全口径, 0)
    + COALESCE(s.赠送成本全口径, 0)
    + COALESCE(b.坏账成本全口径, 0)
    + COALESCE(e.含税金额合计, 0),
    2
  ) AS 成本费用合计,

  now() AS etl_time
FROM keys k
LEFT JOIN sale s
  ON s.年份 = k.年份
 AND s.业务月份 = k.业务月份
 AND s.项目 = k.项目
 AND s.客户 = k.客户
LEFT JOIN baddebt b
  ON b.年份 = k.年份
 AND b.业务月份 = k.业务月份
 AND b.项目 = k.项目
 AND b.客户 = k.客户
LEFT JOIN extra e
  ON e.年份 = k.年份
 AND e.业务月份 = k.业务月份
 AND e.项目 = k.项目
 AND e.客户 = k.客户
