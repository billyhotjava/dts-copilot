{{ config(materialized='table', tags=['xycyl', 'xycyl-flowerbiz', 'ads', 'project', 'customer', 'fixed_report']) }}

-- PRS 项目客户经营看板固定报表入口。
-- 粒度：业务月份 × 项目 × 客户。
-- 聚合租赁、销售、坏账、额外费用和在途状态，避免固定报表运行时只落到 DWS 英文字段。

WITH src AS (
  SELECT *
  FROM {{ ref('xycyl_dwd_flowerbiz_main') }}
  WHERE biz_month IS NOT NULL
    AND NOT is_cancelled
)

SELECT
  s.biz_year                                             AS 年份,
  s.biz_month                                            AS 业务月份,
  s.project_id                                           AS 项目id,
  COALESCE(s.project_name, '未知项目')                   AS 项目,
  COALESCE(s.customer_name, '未知客户')                  AS 客户,

  COUNT(DISTINCT s.biz_id)                               AS 报花单数,
  COUNT(DISTINCT CASE WHEN s.is_finished THEN s.biz_id END)    AS 已结束单数,
  COUNT(DISTINCT CASE WHEN s.is_in_progress THEN s.biz_id END) AS 在途单数,

  COUNT(DISTINCT CASE WHEN s.biz_category = 'lease' THEN s.biz_id END)   AS 租赁单数,
  COUNT(DISTINCT CASE WHEN s.biz_category = 'sale' THEN s.biz_id END)    AS 销售单数,
  COUNT(DISTINCT CASE WHEN s.biz_category = 'gift' THEN s.biz_id END)    AS 赠送单数,
  COUNT(DISTINCT CASE WHEN s.biz_category = 'baddebt' THEN s.biz_id END) AS 坏账单数,
  COUNT(DISTINCT CASE WHEN s.biz_category = 'material' THEN s.biz_id END) AS 物料单数,

  ROUND(SUM(s.rent_amount), 2)                           AS 租金净额,
  ROUND(SUM(s.cost_amount), 2)                           AS 处理成本,
  ROUND(SUM(s.sale_amount), 2)                           AS 销售金额,
  ROUND(SUM(s.extra_cost_amount), 2)                     AS 额外费用,

  ROUND(SUM(CASE WHEN s.biz_category = 'baddebt' THEN s.cost_amount ELSE 0 END), 2) AS 坏账成本,
  ROUND(SUM(CASE WHEN s.biz_category = 'baddebt' THEN s.rent_amount ELSE 0 END), 2) AS 坏账租金损失,

  ROUND(SUM(CASE WHEN s.is_finished THEN s.rent_amount ELSE 0 END), 2)       AS 租金净额已结束,
  ROUND(SUM(CASE WHEN s.is_finished THEN s.cost_amount ELSE 0 END), 2)       AS 处理成本已结束,
  ROUND(SUM(CASE WHEN s.is_finished THEN s.sale_amount ELSE 0 END), 2)       AS 销售金额已结束,
  ROUND(SUM(CASE WHEN s.is_finished THEN s.extra_cost_amount ELSE 0 END), 2) AS 额外费用已结束,

  now() AS etl_time
FROM src s
GROUP BY
  s.biz_year,
  s.biz_month,
  s.project_id,
  COALESCE(s.project_name, '未知项目'),
  COALESCE(s.customer_name, '未知客户')
