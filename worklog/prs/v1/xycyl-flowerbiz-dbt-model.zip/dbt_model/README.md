# 馨懿诚 报花域 dbt Model (xycyl-flowerbiz) — v2

sprint-22 F4 主交付物。报花（flowerbiz）域 5 层 dbt 模型，标准 dbt 项目，现场部署使用。

## 版本历史

- **v2 (2026-05-02)** — 基于生产数据库副本 review 后修正
  - **CRITICAL**：列名对齐生产 schema (`apply_use_id` 不是 `apply_user_id`、`project_manage_id` 不是 `project_manager_id`、删除不存在的 `customer_id`/`end_lease_time`)
  - **CRITICAL**：移除 5 个表的 phantom `del_flag` 过滤（change_info / recovery_info / recovery_info_item / rent_time_log / flower_biz_log 都不存在 del_flag）
  - **HIGH**：移除 `dim_biztype.amount_direction` 与 `amount_signed/abs` 派生 — biz_total_rent 已自带正负号，避免重复加签
  - **HIGH**：4 列分类金额：`rent_amount` / `cost_amount` / `sale_amount` / `extra_cost_amount` — 替代单一 amount
  - **HIGH**：`total_amount` 字段定位修正（仅 biz_type=7 售有值）
  - **MEDIUM**：`t_flower_biz_item_detailed` 重写为真实 8 字段（之前 11 字段全是 phantom）
  - **MEDIUM**：log.biz_type 改名 `log_biz_type_raw`（98% NULL，与父表 biz_type 区分）
  - **MEDIUM**：change_info 暴露完整 BEFORE/AFTER 货物对 + 申请/确认双角色
  - 详见 `worklog/v1.0.0/sprint-22-202605/assets/dbt-model-review-against-prod-2026-05-02.md`
- v1 (2026-05-01) — 初版，基于 adminapi 源码盘点

## 业务背景

报花是馨懿诚绿植租摆业务的事实链源头：

```
报花 → 采购 → 配送/入库 → 摆放/养护 → 结算 → 收款
 ↑
 业务事实源头
```

报花单 `t_flower_biz_info` 是业务事实核心。**财务 settlement / month_accounting / customer_ar 都是报花的聚合衍生**。

## 关键事实（生产数据画像 2026-05-02）

| 指标 | 真实情况 |
|---|---|
| 报花单总数 | 29,405（active del_flag='0'） |
| 主导 biz_type | 1=换花 (47.6%) > 4=调花 (12.9%) > 2=加花 (9.2%) |
| 主导 status | 5=已结束 (89.9%) |
| `biz_total_rent` 符号 | biz_type=3 全负 / biz_type=4 正负皆有 / 已自带方向 |
| `total_amount` 用途 | 仅 biz_type=7 (售) 有值，其他场景 NULL |
| `start_lease_time` 覆盖率 | 仅 biz_type 2/3/4 有 (24.7% 总覆盖) |
| 起租期事后修改率 | 6.4% (468 / 7275) |
| item.flower_biz_id 孤儿率 | **0%** (FK 干净) |
| item_detailed 孤儿率 | **25.5%** (历史 hard-delete) |
| log.biz_type NULL 率 | **98%** (不应当父表 biz_type 用) |

## 目录结构

```text
dbt_model/
├── dbt_project.yml                           # dbt 项目配置（profile=dts，namespace=xycyl_flowerbiz）
├── README.md                                 # 本文件
├── model-governance.md                       # 建模分层与命名治理规则
├── macros/                                   # 通用宏（含 ensure_date_helpers / nullif_placeholder / parse_*_safe）
├── models/
│   ├── xycyl_flowerbiz_sources.yml           # ODS 源表声明（schema=xycyl_ods）
│   ├── xycyl_flowerbiz_stg.yml               # STG 字段与测试
│   ├── xycyl_flowerbiz_schema.yml            # DWD/DWS/ADS 字段与测试
│   ├── stg/                                  # 标准化层（view，11 张）
│   ├── dwd/                                  # 5 dim canonical + 5 dim alias + 6 biz fact
│   ├── dws/                                  # 主题汇总（table，3 张：project/customer/curing_user 月度）
│   └── ads/                                  # 看板 mart（10 张）
└── ods_ddl/
    ├── ods_create_tables.sql                 # 11 张 ODS 镜像表 DDL（schema=xycyl_ods）
    ├── ods-field-mapping/                    # rs_cloud_flower 业务字段 → ODS 列映射
    └── ods-verify/                           # 各报花表字段口径核对文档
```

## 分层约定

```text
ODS (xycyl_ods.ods_*) → STG (view) → DWD (table) → DWS (table) → ADS (table/view)
```

- 全部 dbt 资产使用 `xycyl_` 前缀
- `dwd/* / dws/* / ads/*` 禁止直接 `source(...)`，必须经 `xycyl_stg_*` 进入
- STG 强制保留来源元数据：`source_row_id / source_table / source_system / imported_at`
- 详细规则见 `model-governance.md`

## 部署流程

### 1. 在目标库执行 ODS 建表

```bash
psql "$DTS_PG_URL" -f ods_ddl/ods_create_tables.sql
```

执行后会得到 schema `xycyl_ods` 与 11 张 ODS 镜像表（全部 varchar）。生产环境由入湖任务向这些表写入 rs_cloud_flower 镜像数据。

### 2. 配置 dbt profile

确认 `~/.dbt/profiles.yml` 中存在 `dts` profile，且当前 target 指向现场库。建议 schema 配置：

```yaml
dts:
  outputs:
    prod:
      type: postgres
      host: <pg-host>
      user: <pg-user>
      password: <pg-pwd>
      port: 5432
      dbname: <db>
      schema: xycyl   # 项目层默认 schema；STG/DWD/DWS/ADS 实际落 xycyl_stg / xycyl_dwd / xycyl_dws / xycyl_ads
      threads: 4
```

`get_custom_schema` macro 会按 `xycyl_<layer>` 自动分发各层落地 schema。

### 3. 跑全量

```bash
dbt deps
dbt run --profile dts --select tag:xycyl-flowerbiz
dbt test --profile dts --select tag:xycyl-flowerbiz
```

### 4. 选择性运行某一层

```bash
# 仅 STG（view，几乎瞬完成）
dbt run --select tag:xycyl-flowerbiz,tag:stg

# 仅 ADS（mart 表，业务直接消费）
dbt run --select tag:xycyl-flowerbiz,tag:ads

# 仅租赁主题
dbt run --select tag:xycyl-flowerbiz,tag:lease

# 某 mart + 上游
dbt run --select +xycyl_ads_flowerbiz_lease_summary
```

## 与 dts-copilot / OpenMetadata 集成

| 场景 | 操作 |
|---|---|
| dts-copilot 直读 mart | 在 copilot_ai 注册"花卉报花 mart" datasource，schema=`xycyl_ads`，账号给 SELECT 权限 |
| OpenMetadata 拉取 manifest | services/dts-openmetadata/ingestion/xycyl_dbt.yml（sprint-22 F4-T04 落地） |

## 10 张 ads mart 速查

| # | 模型 | 粒度 | bizType | 物化 | 主要问句 |
|---|---|---|---|---|---|
| 1 | `xycyl_ads_flowerbiz_lease_summary` | 项目 × 客户 × 月 | 1/2/3/4 | table | 加摆撤摆净增减、月度报花趋势 |
| 2 | `xycyl_ads_flowerbiz_lease_detail` | 单据 × 摆位 × 绿植 | 1/2/3/4 | view | XX 项目最近报花、养护人 X 经手 |
| 3 | `xycyl_ads_flowerbiz_pending` | 单据 | 全部 | view | 审核中超 7 天、待结算清单 |
| 4 | `xycyl_ads_flowerbiz_sale_summary` | 项目 × 客户 × 月 | 7/8 | table | 销售金额、销售前 10、赠送数量 |
| 5 | `xycyl_ads_flowerbiz_baddebt_summary` | 项目 × 客户 × 月 | 6 | table | 坏账客户、坏账 TOP |
| 6 | `xycyl_ads_flowerbiz_change_log` | 变更单 | 全部 | view | 起租期变更、金额变更、货物变更 |
| 7 | `xycyl_ads_flowerbiz_recovery_detail` | 回收明细 | 3/4 触发 | view | 回收清单、报损量、回购量 |
| 8 | `xycyl_ads_flowerbiz_curing_workload` | 养护人 × 月 | 全部 | table | 养护人工作量排行 |
| 9 | `xycyl_ads_flowerbiz_audit_trail` | 操作日志 | 全部 | view | 审批耗时、操作链路、X 单挂在哪一步 |
| 10 | `xycyl_ads_flowerbiz_extra_cost_summary` | 项目 × 客户 × 月 × cost_type | 全部 | table | 运费/人工/垃圾清理/其他费用 |

## 与 sprint-22 边界

**本 zip 覆盖 11 张 rs_cloud_flower 报花域源表**（基于 adminapi rs-flowers-base/flowerbiz 模块代码盘点 + 生产数据库 review 确认）：
- ✅ `t_flower_biz_info` (29,405)、`t_flower_biz_item` (196k)、`t_flower_biz_item_detailed` (225k)
- ✅ `t_change_info` (1,180)、`t_recovery_info` (2,527)、`t_recovery_info_item` (20k)
- ✅ `t_flower_rent_time_log` (6k)、`t_flower_biz_log` (295k)、`t_flower_extra_cost` (575)
- ✅ `p_project` (240)、`p_customer` (178) — 简化镜像，sprint-24 摆放域将完整建模

**不在本 sprint（明确归后续 sprint）**：
- `t_warehousing_info` / `t_warehousing_item` / `t_plan_purchase_info` (33k+98k) → **sprint-23 采购域**
- `p_project_green` (36k) / `p_project_green_item` (86k) / `p_position` 完整建模 → **sprint-24 摆放域**
- `a_sale_account` (967) / `a_flower_biz_accounting` (空) / `a_month_accounting` (531) / `a_green_accounting` (166k) / `t_settlement_info` → **sprint-25 财务域**
  - 注意：sprint-22 的 sale_summary 仅基于 t_flower_biz_info（"业务发起金额"），**实收/未收/开票**留 sprint-25 接 a_sale_account

## v2 关键改动详细列表

### ODS DDL
- `t_flower_biz_info` 全字段对齐：`apply_use_id` (非 user)、`project_manage_id` (非 manager)、移除 `customer_id`/`end_lease_time`/`change_reason`/`change_user_id`/`change_time`
- 5 个表移除 phantom `del_flag`：change_info / recovery_info / recovery_info_item / rent_time_log / flower_biz_log
- `t_flower_biz_item_detailed` 缩减为真实 8 字段
- `p_project` 改 `manager_id` (非 project_manager_id)、移除 `customer_id`/`customer_name`（不存在；客户经 p_contract 中转）

### STG
- 11 个 STG 全部对齐 ODS 真实列
- 主表 STG 暴露 60+ 字段（之前 ~20）：urgent / bad_debt_type / transfer_type / source_type / sales_payment_type / accounting_status / cut_confirm_status / examine_time / review_time / sign_time / expense_id / settle_id / batch_code / customer_phone / customer_address / fare / labor_cost / cleaning_fee / total_extra_cost
- change STG 暴露完整 before/after 货物对（price_id/name/type/norms/specs/unit）+ 申请/确认双角色

### DWD
- `dim_biztype`：移除 `amount_direction`、`is_lease/sale/gift/baddebt/material` 标志保留；新增 `prod_volume` (active/pilot/unused)
- `dim_change_type`：3 值（金额/货物/比率），不是 4
- `dim_cost_type`：标签改为 1运费/2人工/3其他-旧/4其他/5垃圾清理 (与 title 真实分布对齐)
- `dwd_main`：4 列分类金额 `rent_amount` / `cost_amount` / `sale_amount` / `extra_cost_amount`；新增 `approval_days` 审批耗时；暴露完整审批/财务挂钩字段
- `dwd_change`：申请/确认双角色 + `confirm_lag_days` + `has_goods_swap` + `settlement_time_delta_days`
- `dwd_recovery`：新增 `recovery_cost_amount` 派生
- `dwd_log`：log.biz_type 与 main.biz_type 区分；新增 `operation_kind` (initiate/milestone/logistic/close/rollback/other)

### DWS
- 全部移除 amount_direction / amount_in / amount_out / amount_neutral
- 改用 4 列分类金额：`rent_amount_finished` / `cost_amount_finished` / `sale_amount_finished` / `extra_cost_amount_finished` 与对应 `_all`
- 用 `customer_name` 反范式取代 `customer_id`

### ADS
- 全部 10 个 mart 字段对齐
- `lease_summary`：直接 SUM(rent_amount)，自然得到加摆-撤摆净额
- `sale_summary`：sale_amount (来自 total_amount) + cost_amount，gift 仅 cost
- `pending`：4 列金额 + urgent 字段
- `change_log`：完整 before/after 货物对 + 双角色 + delta 派生
- `audit_trail`：用 main.biz_type；新增 operation_kind 语义化分类

### Tests
- accepted_values 对齐真实分布：biz_type ∈ {1,2,3,4,6,7,8,10,11,12}（不含 5/9/13）
- change_type ∈ {1,2,3}（不是 4）
- relationships 对 item_detailed → item 设 severity=warn（25.5% 已知孤儿率）

## 参考

- 业务字段口径：`docs-copilot worklog/v1.0.0/sprint-22-202605/assets/flowerbiz-source-catalog.md`
- review 报告：`worklog/v1.0.0/sprint-22-202605/assets/dbt-model-review-against-prod-2026-05-02.md`
- mart 设计清单：`worklog/v1.0.0/sprint-22-202605/assets/flowerbiz-mart-catalog.md`
- 命名 / tag 规范：`worklog/v1.0.0/sprint-22-202605/assets/dts-stack-dbt-conventions.md`
- 5 个口径决策：`worklog/v1.0.0/sprint-22-202605/assets/flowerbiz-caliber-decisions.md`
