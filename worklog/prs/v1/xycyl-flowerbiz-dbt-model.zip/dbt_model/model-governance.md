# 馨懿诚 报花域建模治理说明（xycyl-flowerbiz）

## 1. 目标架构

```text
ODS → STG → DWD → DWS → ADS
```

| 层 | 物化 | schema | 职责 |
|----|--------|--------|------|
| `ODS` | 现有物理表 | `xycyl_ods` | 原始入湖（全 varchar），只做落地与追溯，无业务语义 |
| `STG` | view | `xycyl_stg` | 类型转换 + 占位符归 NULL + 字段改名 + 软删过滤 + 来源元数据 |
| `DWD` | table | `xycyl_dwd` | 业务解释：alias 归一化、dim 打标签、派生口径 |
| `DWS` | table | `xycyl_dws` | 主题汇总（项目/客户/养护人 × 月度） |
| `ADS` | table/view | `xycyl_ads` | 看板/接口直接消费 |

## 2. STG 层宪法（强制）

**允许做**：
- `parse_numeric_safe` / `parse_date_safe` 类型转换
- `nullif_placeholder` 占位符归 NULL
- `btrim` 收敛空白
- 字段改名
- 软删过滤 `WHERE COALESCE(del_flag, '0') = '0'`
- 来源元数据：`source_row_id` / `source_table` / `source_system` / `imported_at`

**禁止做（一条不能出现）**：
- `CASE WHEN` 任何形式的分类判断
- `LIKE '%xxx%'` / `column IN ('a','b')` 分类映射
- `to_char(date, 'YYYY-MM')` 月份格式化
- `EXTRACT(YEAR/QUARTER FROM ...)`
- `split_part` 复合字符串解析
- `abs()` 或任何跨列/同列派生运算
- 派生布尔字段（`is_finished` / `has_xxx` 等）
- JOIN 多表（STG 一进一出）

一句话：**STG 从 ODS 读一行，出来的行与 ODS 一一对应，字段只做"同位变换"，不做"跨列变换"或"值翻译"。**

## 3. DWD 层职责

### 3.1 两类 dim 表

| 类型 | 命名 | 内容 |
|------|------|------|
| Canonical dim | `xycyl_dim_flowerbiz_*` | code → label → is_* flags，业务分类**唯一真值源** |
| Alias dim | `xycyl_dim_flowerbiz_*_alias` | `alias_raw` → `canonical_code`，负责别名归一化 |

报花域 4 套 canonical + 4 套 alias：

| Canonical | Alias |
|---|---|
| `xycyl_dim_flowerbiz_status`（8 状态） | `xycyl_dim_flowerbiz_status_alias` |
| `xycyl_dim_flowerbiz_biztype`（10 类，含 amount_direction / biz_category）| `xycyl_dim_flowerbiz_biztype_alias` |
| `xycyl_dim_flowerbiz_recovery_type`（报损/回购/留用） | `xycyl_dim_flowerbiz_recovery_type_alias` |
| `xycyl_dim_flowerbiz_change_type`（金额/库房/成本/起租）| `xycyl_dim_flowerbiz_change_type_alias` |

### 3.2 biz_dwd 三段论

```
stg
  → normalized  (LEFT JOIN alias dim → 归一化 *_raw 到 canonical code)
  → derived     (派生 business_date / biz_month / biz_year / amount_abs / pending_days 等)
  → final       (LEFT JOIN canonical dim_*_v2 → 打 label + is_* flags)
```

报花域 4 张 biz fact：

- `xycyl_dwd_flowerbiz_main`：报花单主表
- `xycyl_dwd_flowerbiz_item`：报花明细（LEFT JOIN main，孤儿用 `is_orphan` 标识）
- `xycyl_dwd_flowerbiz_change`：变更单
- `xycyl_dwd_flowerbiz_recovery`：回收（主表 + 明细 + main 三方 JOIN）

## 4. 依赖规则

- `dwd/*` 禁止直接 `source(...)`
- `dws/*` 禁止直接 `source(...)` 或 `ref('xycyl_stg_*')`
- `ads/*` 禁止直接 `source(...)` 或 `ref('xycyl_stg_*')`
- 所有下游模型必须经由 `xycyl_stg_*` 进入语义链路
- DWS/ADS 只消费 `xycyl_dwd_*` 或 `xycyl_dws_*`
- 跨命名空间引用（如复用 dts-stack 的 PM/Fund 资产）须走 source 显式声明，**禁止 `ref('某基金或 PM 业务模型')`**

## 5. 命名规则

完整结构：`{namespace}_{layer}_{domain}_{topic}[_{variant}]`

- namespace = `xycyl`
- layer = `stg` / `dwd` / `dws` / `ads` / `dim`
- domain = `flowerbiz`
- topic = `lease_summary` / `pending` 等
- variant = `monthly` / `daily` 等

| 层 | 字段后缀 | 含义 |
|---|---------|------|
| STG | `xxx_raw` | ODS 原值（trim + nullif 后） |
| DWD | `xxx` | canonical code（归一化后） |
| DWD | `xxx_id` | dim 表稳定 ID |
| DWD | `xxx_label` | dim 表中文 label |
| DWD | `is_xxx` | 来自 canonical dim 的布尔 flag |
| DWD | `xxx_month` / `xxx_year` | 从日期派生的时间分组键 |
| ADS | 中文列名 | 直接面向业务消费 |

## 6. STG 元数据字段

所有 STG 必须保留：

- `source_row_id`（unique + not_null）
- `source_table`
- `source_system`（默认 `rs_cloud_flower`）
- `imported_at`

## 7. 5 个口径决策落地

| 决策 | 当前实现 | 待业务方拍板后调整位置 |
|---|---|---|
| 1. 业务时间 | `business_date = COALESCE(start_lease_time, apply_time)` | `xycyl_dwd_flowerbiz_main.derived` |
| 2. bizType 分组 | 5 类 `biz_category`（lease/sale/gift/baddebt/material）+ 13 bizType 单独标记 | `xycyl_dim_flowerbiz_biztype.biz_category` |
| 3. 异步滞后 | DWS 同时输出 `*_finished`（已结束）+ `*_all`（含在途）两套口径 | `xycyl_dws_flowerbiz_*_monthly` |
| 4. 金额符号 | 统一变正 + `amount_direction` 字段 | `xycyl_dwd_flowerbiz_main.amount_abs / amount_direction` |
| 5. 销售独立 | `xycyl_ads_flowerbiz_sale_summary` 与 `lease_summary` 分两张 mart，不做 UNION | `models/ads/` |

## 8. 6 个真实陷阱与处理

| 陷阱 | 处理 |
|---|---|
| 异步触发（@Async）：PlanPurchaseItem 不立刻有 | DWS 提供 finished/all 两套口径，ads_pending 单独 mart |
| 软外键满天飞（item.flower_biz_id 等无 DB 约束） | DWD 全部 LEFT JOIN，schema.yml `relationships` 测试 severity=warn，孤儿用 `is_orphan` 标识 |
| 状态字段 4 service 写 | DWD 用 alias dim 翻译，下游不直接读 status_raw |
| 金额符号因 bizType 异 | DWD 派生 `amount_abs + amount_direction`，DWS 按 direction 拆 in/out |
| bizType=7/8 走 SaleAccount | `biz_category` 拆 lease/sale/gift/baddebt/material，ADS 严格分 mart |
| `start_lease_time` 可事后改 | 业务时间用 `COALESCE(start_lease_time, apply_time)`，rent_time_log 仅审计 |

## 9. tests 规范

每个 ads / dwd 模型必须在 schema.yml 中至少：

- 主键字段 `unique` + `not_null`（severity: warn）
- 状态/类型字段 `accepted_values`
- 软外键 `relationships` severity=warn
- 时间分组键 `not_null`

## 10. 治理原则

- ODS 保留"原样"和"可追溯"
- STG 负责"结构化"和"收敛"，**禁止引入业务语义**
- 所有业务分类 / 映射 / 派生口径由 DWD 承担，且必须以 dim 表为真值源
- 指标定义优先于 SQL 实现
- 血缘必须可解释到 "rs_cloud_flower 字段 → ODS 列 → STG *_raw → DWD canonical → DWD 派生 → DWS → ADS"
