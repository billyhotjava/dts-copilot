{{ config(materialized='table', tags=['xycyl', 'xycyl-flowerbiz', 'ads', 'curing', 'workload', 'monthly']) }}

-- 8. 养护人工作量：养护人 × 业务月份 × biz_category（v2: 用 4 列金额）

SELECT
  d.period_year                                          AS 年份,
  d.period_month                                         AS 业务月份,
  d.curing_user_id                                       AS 养护人id,
  d.curing_user_name                                     AS 养护人,
  d.biz_category                                         AS 业务大类,

  d.biz_count                                            AS 经手单数,
  d.finished_biz_count                                   AS 已结束单数,
  d.in_progress_biz_count                                AS 在途单数,

  d.biz_count_lease                                      AS 租赁单数,
  d.biz_count_sale                                       AS 销售单数,
  d.biz_count_gift                                       AS 赠送单数,

  d.rent_amount_finished                                 AS 租金净额已结束,
  d.cost_amount_finished                                 AS 处理成本已结束,
  d.sale_amount_finished                                 AS 销售金额已结束,
  d.rent_amount_all                                      AS 租金净额全口径,
  d.cost_amount_all                                      AS 处理成本全口径,
  d.sale_amount_all                                      AS 销售金额全口径,

  now() AS etl_time
FROM {{ ref('xycyl_dws_flowerbiz_curing_user_monthly') }} d
