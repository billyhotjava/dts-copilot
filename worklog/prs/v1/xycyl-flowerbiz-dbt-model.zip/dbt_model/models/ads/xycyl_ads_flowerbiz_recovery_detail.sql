{{ config(materialized='view', tags=['xycyl', 'xycyl-flowerbiz', 'ads', 'recovery', 'detail']) }}

-- 7. 回收明细（v2: 字段对齐 dwd_recovery; recovery_info 没有 code; 用 customer_name）
-- 主要问句: 本月回收清单、报损了多少、回购量、X 库房收到的回收

WITH proj AS (
  SELECT * FROM {{ ref('xycyl_stg_project') }}
),
src AS (
  SELECT * FROM {{ ref('xycyl_dwd_flowerbiz_recovery') }}
)

SELECT
  r.recovery_item_id                                     AS 回收明细id,
  r.recovery_id                                          AS 回收单id,
  r.biz_id                                               AS 报花单id,
  r.biz_code                                             AS 报花单号,
  r.biz_item_id                                          AS 报花明细id,

  r.project_id                                           AS 项目id,
  COALESCE(p.project_name, '未知项目')                   AS 项目,
  COALESCE(r.customer_name, '未知客户')                  AS 客户,

  r.main_biz_type_label                                  AS 报花业务类型,

  r.recovery_type                                        AS 回收类型code,
  r.recovery_type_label                                  AS 回收类型,
  r.is_loss                                              AS 是否报损,
  r.is_buyback                                           AS 是否回购,
  r.is_keep                                              AS 是否留用,
  r.recovery_status_label                                AS 回收状态,

  r.goods_price_id                                       AS 绿植定价id,
  r.good_name                                            AS 绿植名,
  r.good_norms                                           AS 规格,
  r.good_specs                                           AS 规格描述,
  r.good_unit                                            AS 单位,

  r.recovery_number                                      AS 计划回收数,
  r.real_recovery_number                                 AS 实际回收数,
  r.effective_recovery_number                            AS 实际或计划回收数,
  r.good_cost                                            AS 单棵成本,
  r.recovery_cost_amount                                 AS 回收成本金额,

  r.distribution_user_id                                 AS 配送人id,
  r.distribution_user_name                               AS 配送人,
  r.distribution_time                                    AS 配送时间,
  r.recovery_user_id                                     AS 回收人id,
  r.recovery_user_name                                   AS 回收人,
  r.store_house_id                                       AS 入库库房id,
  r.store_house_name                                     AS 入库库房,

  r.plan_recovery_time                                   AS 计划回收时间,
  r.head_recovery_time                                   AS 单据回收时间,
  r.item_recovery_time                                   AS 明细回收时间,
  r.effective_date                                       AS 业务时间,
  r.recovery_month                                       AS 业务月份

FROM src r
LEFT JOIN proj p ON p.project_id = r.project_id
