{{ config(materialized='table', tags=['xycyl', 'xycyl-flowerbiz', 'ads', 'lease', 'summary', 'monthly']) }}

-- 1. 租赁汇总：项目 × 客户 × 业务月份（v2: 用 customer_name + rent_amount）
-- bizType 范围: 1/2/3/4（换/加/减/调）—— biz_category='lease'
-- 主要问句: 本月加摆撤摆净增减、项目租金变动、月度报花趋势
--
-- 关键：rent_amount 已自带正负号，SUM 自然得到加摆-撤摆净额

WITH proj AS (
  SELECT * FROM {{ ref('xycyl_stg_project') }}
),
src AS (
  SELECT * FROM {{ ref('xycyl_dws_flowerbiz_project_monthly') }}
  WHERE biz_category = 'lease'
)

SELECT
  s.period_year                                          AS 年份,
  s.period_month                                         AS 业务月份,
  s.project_id                                           AS 项目id,
  COALESCE(s.project_name, p.project_name, '未知项目')   AS 项目,
  COALESCE(s.customer_name, '未知客户')                  AS 客户,
  s.biz_category                                         AS 业务大类,

  -- 单数
  s.biz_count                                            AS 报花单数,
  s.finished_biz_count                                   AS 已结束单数,
  s.in_progress_biz_count                                AS 在途单数,
  s.biz_count_change                                     AS 换花单数,
  s.biz_count_add                                        AS 加摆单数,
  s.biz_count_cut                                        AS 撤摆单数,
  s.biz_count_transfer                                   AS 调花单数,

  -- 金额（rent_amount 已含正负号；正=加摆收入、负=撤摆扣减）
  s.rent_amount_finished                                 AS 租金净额已结束,
  s.cost_amount_finished                                 AS 处理成本已结束,
  s.extra_cost_amount_finished                           AS 额外费用已结束,
  s.rent_amount_all                                      AS 租金净额全口径,
  s.cost_amount_all                                      AS 处理成本全口径,

  now() AS etl_time
FROM src s
LEFT JOIN proj p ON p.project_id = s.project_id
