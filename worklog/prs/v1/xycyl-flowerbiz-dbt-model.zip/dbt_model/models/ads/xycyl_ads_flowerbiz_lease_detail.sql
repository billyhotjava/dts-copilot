{{ config(materialized='view', tags=['xycyl', 'xycyl-flowerbiz', 'ads', 'lease', 'detail']) }}

-- 2. 租赁明细：单据 × 摆位 × 绿植（v2: 字段对齐 dwd_item; 用 customer_name）
-- bizType 范围: 1/2/3/4
-- 主要问句: 万象城最近的报花单、养护人 X 经手的报花、近 N 天报花列表

WITH proj AS (
  SELECT * FROM {{ ref('xycyl_stg_project') }}
),
items AS (
  SELECT * FROM {{ ref('xycyl_dwd_flowerbiz_item') }}
  WHERE is_lease_biz = true
)

SELECT
  i.biz_id                                               AS 报花单id,
  i.biz_code                                             AS 报花单号,
  i.biz_type                                             AS 业务类型code,
  i.biz_type_label                                       AS 业务类型,
  i.main_status                                          AS 状态code,
  i.main_status_label                                    AS 状态,

  i.project_id                                           AS 项目id,
  COALESCE(i.project_name, p.project_name, '未知项目')   AS 项目,
  COALESCE(i.customer_name, '未知客户')                  AS 客户,

  i.position_id                                          AS 摆位id,
  i.position_name                                        AS 摆位,
  i.position_full_name                                   AS 摆位全路径,
  i.good_price_id                                        AS 绿植定价id,
  i.green_name                                           AS 绿植名,
  i.good_norms                                           AS 规格,
  i.good_specs                                           AS 规格描述,
  i.good_unit                                            AS 单位,
  i.plant_number                                         AS 数量,
  i.rent                                                 AS 单棵月租金,
  i.cost                                                 AS 单棵成本,
  i.line_rent_total                                      AS 行租金合计,
  i.line_cost_total                                      AS 行成本合计,

  i.business_date                                        AS 业务时间,
  i.biz_month                                            AS 业务月份,
  i.start_time                                           AS 起租时间,
  i.end_time                                             AS 停租时间,
  i.put_time                                             AS 摆放时间,
  i.confirm_put_time                                     AS 确认摆放时间,

  i.curing_user_id                                       AS 养护人id,
  i.curing_user_name                                     AS 养护人,

  i.is_orphan                                            AS 主表缺失标记,
  i.biz_item_id                                          AS 明细id

FROM items i
LEFT JOIN proj p ON p.project_id = i.project_id
