{{ config(materialized='view', tags=['xycyl', 'xycyl-flowerbiz', 'ads', 'change', 'audit']) }}

-- 6. 变更日志：变更单粒度（v2: 字段对齐 dwd_change; 完整 before/after 货物对; 双角色）
-- 主要问句: 金额变更、货物变更、起租期变更、X 单的变更链

WITH proj AS (
  SELECT * FROM {{ ref('xycyl_stg_project') }}
),
src AS (
  SELECT * FROM {{ ref('xycyl_dwd_flowerbiz_change') }}
)

SELECT
  c.change_id                                            AS 变更id,
  c.change_code                                          AS 变更单号,
  c.change_title                                         AS 变更标题,

  c.biz_id                                               AS 报花单id,
  c.biz_code                                             AS 报花单号,
  c.project_id                                           AS 项目id,
  COALESCE(c.project_name, p.project_name, '未知项目')   AS 项目,
  COALESCE(c.customer_name, '未知客户')                  AS 客户,
  c.main_biz_type_label                                  AS 报花业务类型,

  c.change_type                                          AS 变更类型code,
  c.change_type_label                                    AS 变更类型,
  c.is_amount_only                                       AS 是否纯金额变更,
  c.is_goods_change                                      AS 是否货物变更,
  c.is_rate_change                                       AS 是否比率变更,

  c.change_status                                        AS 变更状态code,
  c.change_status_label                                  AS 变更状态,
  c.change_number                                        AS 变更数量,

  -- 申请/确认
  c.apply_user_id                                        AS 申请人id,
  c.apply_user_name                                      AS 申请人,
  c.apply_time                                           AS 申请时间,
  c.confirmed_user_id                                    AS 确认人id,
  c.confirmed_user_name                                  AS 确认人,
  c.confirmed_time                                       AS 确认时间,
  c.confirm_lag_days                                     AS 确认耗时天数,

  -- 金额
  c.before_total_amount                                  AS 变更前金额,
  c.after_total_amount                                   AS 变更后金额,
  c.amount_delta                                         AS 金额差额,

  -- 起租期
  c.before_settlement_time                               AS 变更前起租期,
  c.after_settlement_time                                AS 变更后起租期,
  c.settlement_time_delta_days                           AS 起租期变化天数,

  -- 货物
  c.before_good_name                                     AS 变更前绿植名,
  c.before_good_norms                                    AS 变更前规格,
  c.before_good_specs                                    AS 变更前规格描述,
  c.after_good_name                                      AS 变更后绿植名,
  c.after_good_norms                                     AS 变更后规格,
  c.after_good_specs                                     AS 变更后规格描述,
  c.has_goods_swap                                       AS 是否更换绿植,

  c.change_month                                         AS 变更月份,
  c.remark                                               AS 备注

FROM src c
LEFT JOIN proj p ON p.project_id = c.project_id
