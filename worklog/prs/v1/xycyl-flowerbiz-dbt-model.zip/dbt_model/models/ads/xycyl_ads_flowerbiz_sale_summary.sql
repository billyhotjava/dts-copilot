{{ config(materialized='table', tags=['xycyl', 'xycyl-flowerbiz', 'ads', 'sale', 'summary', 'monthly']) }}

-- 4. 销售/赠花汇总：项目 × 客户 × 业务月份（v2: 用 sale_amount/cost_amount; customer_name）
-- bizType 范围: 7/8（售/赠）—— biz_category IN ('sale', 'gift')
-- 关键事实：sale_amount（=total_amount）只对 biz_type=7 有意义
--           gift（biz_type=8）没有租金/售价，仅 cost_amount 表征处理成本
-- sprint-25 接入 a_sale_account 后会有"实收/未收/开票"，此 mart 仅"业务发起金额"

WITH proj AS (
  SELECT * FROM {{ ref('xycyl_stg_project') }}
),
src AS (
  SELECT * FROM {{ ref('xycyl_dws_flowerbiz_project_monthly') }}
  WHERE biz_category IN ('sale', 'gift')
),
agg AS (
  SELECT
    period_year,
    period_month,
    project_id,
    project_name,
    customer_name,

    SUM(biz_count)                                                                AS biz_count_total,
    SUM(CASE WHEN biz_category='sale' THEN biz_count ELSE 0 END)                  AS sale_count,
    SUM(CASE WHEN biz_category='gift' THEN biz_count ELSE 0 END)                  AS gift_count,

    SUM(CASE WHEN biz_category='sale' THEN sale_amount_finished ELSE 0 END)       AS sale_amount_finished,
    SUM(CASE WHEN biz_category='sale' THEN cost_amount_finished ELSE 0 END)       AS sale_cost_finished,
    SUM(CASE WHEN biz_category='gift' THEN cost_amount_finished ELSE 0 END)       AS gift_cost_finished,

    SUM(CASE WHEN biz_category='sale' THEN sale_amount_all ELSE 0 END)            AS sale_amount_all,
    SUM(CASE WHEN biz_category='sale' THEN cost_amount_all ELSE 0 END)            AS sale_cost_all,
    SUM(CASE WHEN biz_category='gift' THEN cost_amount_all ELSE 0 END)            AS gift_cost_all
  FROM src
  GROUP BY period_year, period_month, project_id, project_name, customer_name
)

SELECT
  a.period_year                                              AS 年份,
  a.period_month                                             AS 业务月份,
  a.project_id                                               AS 项目id,
  COALESCE(a.project_name, p.project_name, '未知项目')       AS 项目,
  COALESCE(a.customer_name, '未知客户')                      AS 客户,

  a.biz_count_total                                          AS 总单数,
  a.sale_count                                               AS 销售单数,
  a.gift_count                                               AS 赠送单数,

  ROUND(a.sale_amount_finished, 2)                           AS 销售金额已结束,
  ROUND(a.sale_cost_finished, 2)                             AS 销售成本已结束,
  ROUND(a.gift_cost_finished, 2)                             AS 赠送成本已结束,

  ROUND(a.sale_amount_all, 2)                                AS 销售金额全口径,
  ROUND(a.sale_cost_all, 2)                                  AS 销售成本全口径,
  ROUND(a.gift_cost_all, 2)                                  AS 赠送成本全口径,

  now() AS etl_time
FROM agg a
LEFT JOIN proj p ON p.project_id = a.project_id
