{{ config(materialized='table', tags=['xycyl', 'xycyl-flowerbiz', 'ads', 'extra_cost', 'summary', 'monthly']) }}

-- 10. 报花额外费用汇总（v2: 用 customer_name; cost_type 标签更新）
-- 主要问句: 本月运费、人工成本、垃圾清理费、附加成本 TOP 项目

WITH proj AS (
  SELECT * FROM {{ ref('xycyl_stg_project') }}
),
src AS (
  SELECT * FROM {{ ref('xycyl_dwd_flowerbiz_extra_cost') }}
  WHERE biz_month IS NOT NULL
)

SELECT
  s.biz_year                                             AS 年份,
  s.biz_month                                            AS 业务月份,
  s.project_id                                           AS 项目id,
  COALESCE(s.project_name, p.project_name, '未知项目')   AS 项目,
  COALESCE(s.customer_name, '未知客户')                  AS 客户,

  COUNT(DISTINCT s.biz_id)                               AS 涉及单数,
  COUNT(DISTINCT s.extra_cost_id)                        AS 费用条数,

  ROUND(SUM(s.free_amount), 2)                           AS 不含税成本合计,
  ROUND(SUM(s.price_amount), 2)                          AS 含税金额合计,

  ROUND(SUM(CASE WHEN s.is_freight THEN s.price_amount ELSE 0 END), 2) AS 运费合计,
  ROUND(SUM(CASE WHEN s.is_labor   THEN s.price_amount ELSE 0 END), 2) AS 人工费合计,
  ROUND(SUM(CASE WHEN s.is_garbage THEN s.price_amount ELSE 0 END), 2) AS 垃圾清理费合计,
  ROUND(SUM(CASE WHEN s.is_other   THEN s.price_amount ELSE 0 END), 2) AS 其他费用合计,

  COUNT(DISTINCT CASE WHEN s.is_freight THEN s.extra_cost_id END) AS 运费条数,
  COUNT(DISTINCT CASE WHEN s.is_labor   THEN s.extra_cost_id END) AS 人工费条数,
  COUNT(DISTINCT CASE WHEN s.is_garbage THEN s.extra_cost_id END) AS 垃圾清理费条数,
  COUNT(DISTINCT CASE WHEN s.is_other   THEN s.extra_cost_id END) AS 其他费用条数,

  now() AS etl_time
FROM src s
LEFT JOIN proj p ON p.project_id = s.project_id
GROUP BY s.biz_year, s.biz_month, s.project_id, s.project_name, s.customer_name, p.project_name
