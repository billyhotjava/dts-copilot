{{ config(materialized='table', tags=['xycyl', 'xycyl-flowerbiz', 'ads', 'baddebt', 'summary', 'monthly']) }}

-- 5. 坏账汇总：项目 × 客户 × 业务月份（v2: 用 cost_amount + rent_amount; customer_name）
-- bizType 范围: 6（坏账）—— biz_category='baddebt'
-- 短期可用；sprint-25 finance 域上线后客户欠款问句应走 finance.a_sale_account
-- 主要问句: 本月坏账客户、坏账 TOP、客户坏账历史
--
-- 实测: biz_type=6 cost_amount=87k+, rent_amount=11k+ (loss of rent income)

WITH proj AS (
  SELECT * FROM {{ ref('xycyl_stg_project') }}
),
src AS (
  SELECT * FROM {{ ref('xycyl_dws_flowerbiz_project_monthly') }}
  WHERE biz_category = 'baddebt'
)

SELECT
  s.period_year                                          AS 年份,
  s.period_month                                         AS 业务月份,
  s.project_id                                           AS 项目id,
  COALESCE(s.project_name, p.project_name, '未知项目')   AS 项目,
  COALESCE(s.customer_name, '未知客户')                  AS 客户,

  s.biz_count_baddebt                                    AS 坏账单数,

  s.cost_amount_finished                                 AS 坏账成本已结束,
  s.rent_amount_finished                                 AS 坏账租金损失已结束,
  s.cost_amount_all                                      AS 坏账成本全口径,
  s.rent_amount_all                                      AS 坏账租金损失全口径,

  '坏账' AS 业务大类,

  now() AS etl_time
FROM src s
LEFT JOIN proj p ON p.project_id = s.project_id
