{{ config(materialized='table', tags=['xycyl', 'xycyl-flowerbiz', 'dws', 'monthly']) }}

-- 报花域 客户 × 月份 × biz_category 汇总（v2: 用 customer_name 反范式）
-- 用于"客户级"问句（坏账客户、客户欠款、销售排行）

WITH src AS (
  SELECT
    biz_year,
    biz_month,
    customer_name,
    biz_category,
    biz_type,
    biz_id,
    rent_amount,
    cost_amount,
    sale_amount,
    extra_cost_amount,
    is_finished,
    is_cancelled,
    is_in_progress
  FROM {{ ref('xycyl_dwd_flowerbiz_main') }}
  WHERE biz_month IS NOT NULL
    AND customer_name IS NOT NULL
    AND NOT is_cancelled
)

SELECT
  s.biz_year                                                                AS period_year,
  s.biz_month                                                               AS period_month,
  s.customer_name,
  s.biz_category,

  COUNT(DISTINCT s.biz_id)                                                  AS biz_count,
  COUNT(DISTINCT CASE WHEN s.is_finished THEN s.biz_id END)                 AS finished_biz_count,
  COUNT(DISTINCT CASE WHEN s.is_in_progress THEN s.biz_id END)              AS in_progress_biz_count,

  -- 已结束口径
  ROUND(SUM(CASE WHEN s.is_finished THEN s.rent_amount ELSE 0 END), 2)        AS rent_amount_finished,
  ROUND(SUM(CASE WHEN s.is_finished THEN s.cost_amount ELSE 0 END), 2)        AS cost_amount_finished,
  ROUND(SUM(CASE WHEN s.is_finished THEN s.sale_amount ELSE 0 END), 2)        AS sale_amount_finished,
  ROUND(SUM(CASE WHEN s.is_finished THEN s.extra_cost_amount ELSE 0 END), 2)  AS extra_cost_amount_finished,

  -- 全口径
  ROUND(SUM(s.rent_amount), 2)        AS rent_amount_all,
  ROUND(SUM(s.cost_amount), 2)        AS cost_amount_all,
  ROUND(SUM(s.sale_amount), 2)        AS sale_amount_all,
  ROUND(SUM(s.extra_cost_amount), 2)  AS extra_cost_amount_all,

  -- 关键 bizType 单数
  COUNT(DISTINCT CASE WHEN s.biz_type = '6' THEN s.biz_id END)              AS biz_count_baddebt,
  COUNT(DISTINCT CASE WHEN s.biz_type = '7' THEN s.biz_id END)              AS biz_count_sale,
  COUNT(DISTINCT CASE WHEN s.biz_type = '8' THEN s.biz_id END)              AS biz_count_gift

FROM src s
GROUP BY s.biz_year, s.biz_month, s.customer_name, s.biz_category
