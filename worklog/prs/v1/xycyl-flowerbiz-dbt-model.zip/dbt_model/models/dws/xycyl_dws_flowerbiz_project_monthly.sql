{{ config(materialized='table', tags=['xycyl', 'xycyl-flowerbiz', 'dws', 'monthly']) }}

-- 报花域 项目 × 客户 × 月份 × biz_category 汇总（v2）
-- 关键改动：
--   • 移除 amount_direction → 直接 SUM(rent_amount)，rent_amount 已自带正负号
--   • 拆 4 类金额：rent / cost / sale / extra_cost
--   • customer_id → customer_name（反范式，源自主表）
--   • _finished 与 _all 双口径（决策 3）

WITH src AS (
  SELECT
    biz_year,
    biz_month,
    project_id,
    project_name,
    customer_name,
    biz_category,
    biz_type,
    biz_type_label,
    biz_id,
    rent_amount,
    cost_amount,
    sale_amount,
    extra_cost_amount,
    is_finished,
    is_cancelled,
    is_in_progress
  FROM {{ ref('xycyl_dwd_flowerbiz_main') }}
  WHERE biz_month IS NOT NULL
    AND project_id IS NOT NULL
    AND NOT is_cancelled                  -- 已作废不计入
)

SELECT
  s.biz_year                                                              AS period_year,
  s.biz_month                                                             AS period_month,
  s.project_id,
  MAX(s.project_name)                                                     AS project_name,
  s.customer_name,
  s.biz_category,

  -- 单数
  COUNT(DISTINCT s.biz_id)                                                AS biz_count,
  COUNT(DISTINCT CASE WHEN s.is_finished THEN s.biz_id END)               AS finished_biz_count,
  COUNT(DISTINCT CASE WHEN s.is_in_progress THEN s.biz_id END)            AS in_progress_biz_count,

  -- ─── 已结束口径（_finished） ───
  ROUND(SUM(CASE WHEN s.is_finished THEN s.rent_amount ELSE 0 END), 2)        AS rent_amount_finished,
  ROUND(SUM(CASE WHEN s.is_finished THEN s.cost_amount ELSE 0 END), 2)        AS cost_amount_finished,
  ROUND(SUM(CASE WHEN s.is_finished THEN s.sale_amount ELSE 0 END), 2)        AS sale_amount_finished,
  ROUND(SUM(CASE WHEN s.is_finished THEN s.extra_cost_amount ELSE 0 END), 2)  AS extra_cost_amount_finished,

  -- ─── 全口径（_all：包含在途，仅排除作废） ───
  ROUND(SUM(s.rent_amount), 2)        AS rent_amount_all,
  ROUND(SUM(s.cost_amount), 2)        AS cost_amount_all,
  ROUND(SUM(s.sale_amount), 2)        AS sale_amount_all,
  ROUND(SUM(s.extra_cost_amount), 2)  AS extra_cost_amount_all,

  -- ─── 按 bizType 拆单数（lease 内 4 类换/加/减/调） ───
  COUNT(DISTINCT CASE WHEN s.biz_type = '1'  THEN s.biz_id END)  AS biz_count_change,
  COUNT(DISTINCT CASE WHEN s.biz_type = '2'  THEN s.biz_id END)  AS biz_count_add,
  COUNT(DISTINCT CASE WHEN s.biz_type = '3'  THEN s.biz_id END)  AS biz_count_cut,
  COUNT(DISTINCT CASE WHEN s.biz_type = '4'  THEN s.biz_id END)  AS biz_count_transfer,
  COUNT(DISTINCT CASE WHEN s.biz_type = '6'  THEN s.biz_id END)  AS biz_count_baddebt,
  COUNT(DISTINCT CASE WHEN s.biz_type = '7'  THEN s.biz_id END)  AS biz_count_sale,
  COUNT(DISTINCT CASE WHEN s.biz_type = '8'  THEN s.biz_id END)  AS biz_count_gift,
  COUNT(DISTINCT CASE WHEN s.biz_type = '10' THEN s.biz_id END)  AS biz_count_material,
  COUNT(DISTINCT CASE WHEN s.biz_type = '11' THEN s.biz_id END)  AS biz_count_add_basket,
  COUNT(DISTINCT CASE WHEN s.biz_type = '12' THEN s.biz_id END)  AS biz_count_cut_basket

FROM src s
GROUP BY s.biz_year, s.biz_month, s.project_id, s.customer_name, s.biz_category
