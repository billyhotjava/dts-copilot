{{ config(materialized='table', tags=['xycyl', 'xycyl-flowerbiz', 'dwd', 'biz', 'flowerbiz_item']) }}

-- 报花明细事实层（v2: 列名对齐 STG, 移除 amount_direction）
-- 软外键 biz_id LEFT JOIN main（实测 0% 孤儿但保留兜底逻辑）

WITH item AS (
  SELECT * FROM {{ ref('xycyl_stg_flower_biz_item') }}
),
main AS (
  SELECT * FROM {{ ref('xycyl_dwd_flowerbiz_main') }}
),
normalized AS (
  SELECT
    i.*,
    bta.canonical_code AS biz_type
  FROM item i
  LEFT JOIN {{ ref('xycyl_dim_flowerbiz_biztype_alias') }} bta
    ON bta.alias_raw = i.biz_type_raw
)

SELECT
  i.biz_item_id,
  i.source_row_id,
  i.source_table,

  i.biz_id,
  i.parent_item_id,
  m.biz_code,
  m.project_id,
  m.project_name,
  m.customer_name,
  m.curing_user_id,
  m.curing_user_name,

  -- 摆位 / 商品
  i.position_id,
  i.position_name,
  i.position_full_name,
  i.good_price_id,
  i.green_name,
  i.good_norms,
  i.good_specs,
  i.good_unit,
  i.good_type_raw,
  i.project_green_id,
  i.old_green_id,

  -- bizType（明细自身的 biz_type，理论上与主表一致）
  i.biz_type_raw,
  i.biz_type,
  bt.label             AS biz_type_label,
  bt.biz_category,
  COALESCE(bt.is_lease, false)    AS is_lease_biz,
  COALESCE(bt.is_sale, false)     AS is_sale_biz,
  COALESCE(bt.is_gift, false)     AS is_gift_biz,
  COALESCE(bt.is_baddebt, false)  AS is_baddebt_biz,
  COALESCE(bt.is_material, false) AS is_material_biz,

  -- 数量
  i.plant_number,
  i.total_number,
  i.good_number,
  i.reject_number,
  i.frm_loss_number,
  i.buyback_number,
  i.keep_number,
  i.net_receipts_number,
  i.transfer_number,
  i.distribute_purchase_number,
  i.distribute_base_number,
  i.distribute_slow_number,
  i.real_purchase_number,
  i.real_out_number,
  i.finish_number,
  i.finish_distribute_number,

  -- 金额（行级 — 不做符号处理）
  i.rent,
  i.cost,
  i.real_purchase_price,
  i.real_out_price,
  i.real_slow_price,
  COALESCE(i.rent, 0) * COALESCE(i.plant_number, 0) AS line_rent_total,
  COALESCE(i.cost, 0) * COALESCE(i.plant_number, 0) AS line_cost_total,

  -- 时间
  i.put_time,
  i.confirm_put_time,
  i.confirm_put_user_id,
  i.start_time,
  i.end_time,

  -- 库房
  i.distribute_store_house_id,
  i.distribute_slow_house_id,
  i.back_storehouse_id,
  i.transfer_cut_green_id,

  -- 派生月份（用 main.business_date，孤儿用 item.start_time 兜底）
  COALESCE(m.business_date, i.start_time, i.put_time)                      AS business_date,
  to_char(COALESCE(m.business_date, i.start_time, i.put_time), 'YYYY-MM')  AS biz_month,
  EXTRACT(YEAR FROM COALESCE(m.business_date, i.start_time, i.put_time))::int AS biz_year,

  -- main 状态透传
  m.status              AS main_status,
  m.status_label        AS main_status_label,
  m.is_finished         AS main_is_finished,
  m.is_cancelled        AS main_is_cancelled,
  m.is_in_progress      AS main_is_in_progress,

  -- 孤儿标记（实测 0%，保留兜底）
  CASE WHEN m.biz_id IS NULL THEN true ELSE false END AS is_orphan,

  -- 业务子标签
  i.transfer_type_raw,
  i.combination_to_scene_raw,
  i.force_change_flowers_raw,
  i.reduction_flower_way_raw,
  i.expense_status_raw,
  i.source_text,
  i.rent_des,
  i.bad_debt_reason,
  i.remark,

  i.created_by,
  i.created_at,
  i.updated_by,
  i.updated_at,
  now() AS etl_time

FROM normalized i
LEFT JOIN main m
  ON m.biz_id = i.biz_id
LEFT JOIN {{ ref('xycyl_dim_flowerbiz_biztype') }} bt
  ON bt.code = i.biz_type
