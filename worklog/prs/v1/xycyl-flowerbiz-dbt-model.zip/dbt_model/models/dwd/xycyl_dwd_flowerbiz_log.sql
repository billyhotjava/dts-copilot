{{ config(materialized='table', tags=['xycyl', 'xycyl-flowerbiz', 'dwd', 'biz', 'flowerbiz_log']) }}

-- 报花单操作日志事实层（v2: log.biz_type 98% NULL，重命名为 log_biz_type；用 main.biz_type 作真实）
-- 关键派生：上一次操作到本次操作的间隔（用于回答"审批耗时""挂起天数"）
-- 真实操作标题示例：现场接收/采购完成/开始配送/结束/单据回退/发起换花/发起调花/...

WITH stg AS (
  SELECT * FROM {{ ref('xycyl_stg_flower_biz_log') }}
),
main AS (
  SELECT * FROM {{ ref('xycyl_dwd_flowerbiz_main') }}
),
normalized AS (
  SELECT
    s.*,
    sa.canonical_code  AS log_status
  FROM stg s
  LEFT JOIN {{ ref('xycyl_dim_flowerbiz_status_alias') }} sa
    ON sa.alias_raw = s.status_raw
),
ordered AS (
  SELECT
    n.*,
    LAG(n.operation_time) OVER (PARTITION BY n.biz_id ORDER BY n.sorts NULLS LAST, n.operation_time) AS prev_operation_time
  FROM normalized n
)

SELECT
  o.log_id,
  o.source_row_id,
  o.source_table,

  o.biz_id,
  m.biz_code,
  m.project_id,
  m.project_name,
  m.customer_name,

  o.sorts,

  -- 父表 biz_type（真实，从 main JOIN 来）
  m.biz_type                                   AS main_biz_type,
  m.biz_type_label                             AS main_biz_type_label,
  m.biz_category                               AS main_biz_category,

  -- 日志自身的 biz_type（98% NULL，仅作 raw 字段保留）
  o.log_biz_type_raw,

  -- 日志记录时该单据的状态
  o.status_raw                                 AS log_status_raw,
  o.log_status,
  st.label                                     AS log_status_label,
  COALESCE(st.is_finished, false)              AS is_finished_at_log,
  COALESCE(st.is_cancelled, false)             AS is_cancelled_at_log,

  -- 操作内容
  o.operation_title,
  o.operation_user_id,
  o.operation_user_name,
  o.operation_time,
  o.operation_content,

  -- 操作类型语义化（基于真实 title 取值）
  CASE
    WHEN o.operation_title LIKE '发起%'         THEN 'initiate'
    WHEN o.operation_title IN ('复核完成','确认租金','现场接收','采购完成') THEN 'milestone'
    WHEN o.operation_title IN ('开始配送','库房出库','库房提货','分配市场采购','分配库房出库','分配回收') THEN 'logistic'
    WHEN o.operation_title IN ('结束','完善减花去处')  THEN 'close'
    WHEN o.operation_title = '单据回退'              THEN 'rollback'
    ELSE 'other'
  END AS operation_kind,

  -- 间隔
  o.prev_operation_time,
  CASE
    WHEN o.prev_operation_time IS NULL THEN NULL
    ELSE GREATEST((o.operation_time::date - o.prev_operation_time::date)::int, 0)
  END                                         AS days_since_prev,

  to_char(o.operation_time, 'YYYY-MM')         AS operation_month,
  EXTRACT(YEAR FROM o.operation_time)::int     AS operation_year,

  now() AS etl_time

FROM ordered o
LEFT JOIN main m
  ON m.biz_id = o.biz_id
LEFT JOIN {{ ref('xycyl_dim_flowerbiz_status') }} st
  ON st.code = o.log_status
