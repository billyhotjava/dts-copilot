{{ config(materialized='table', tags=['xycyl', 'xycyl-flowerbiz', 'dwd', 'biz', 'change']) }}

-- 变更单事实层（v2: 列名对齐 STG; 申请/确认双角色; before/after 货物对完整暴露）

WITH stg AS (
  SELECT * FROM {{ ref('xycyl_stg_change_info') }}
),
main AS (
  SELECT * FROM {{ ref('xycyl_dwd_flowerbiz_main') }}
),
normalized AS (
  SELECT
    s.*,
    cta.canonical_code AS change_type,
    sa.canonical_code  AS status
  FROM stg s
  LEFT JOIN {{ ref('xycyl_dim_flowerbiz_change_type_alias') }} cta
    ON cta.alias_raw = s.change_type_raw
  LEFT JOIN {{ ref('xycyl_dim_flowerbiz_status_alias') }} sa
    ON sa.alias_raw = s.status_raw
)

SELECT
  s.change_id,
  s.change_code,
  s.change_title,
  s.source_row_id,
  s.source_table,

  s.biz_id,
  m.biz_code,
  m.project_id,
  m.project_name,
  m.customer_name,
  m.biz_type           AS main_biz_type,
  m.biz_type_label     AS main_biz_type_label,

  -- 变更类型
  s.change_type_raw,
  s.change_type,
  ct.change_type_id,
  ct.label                              AS change_type_label,
  COALESCE(ct.is_amount_only, false)    AS is_amount_only,
  COALESCE(ct.is_goods_change, false)   AS is_goods_change,
  COALESCE(ct.is_rate_change, false)    AS is_rate_change,

  -- 状态
  s.status_raw,
  s.status                              AS change_status,
  CASE
    WHEN s.status = '2'  THEN '已结束'
    WHEN s.status = '-1' THEN '作废'
    ELSE '确认中'
  END AS change_status_label,

  -- 双角色
  s.apply_user_id,
  s.apply_user_name,
  s.apply_time,
  s.confirmed_user_id,
  s.confirmed_user_name,
  s.confirmed_time,
  CASE
    WHEN s.apply_time IS NOT NULL AND s.confirmed_time IS NOT NULL
      THEN GREATEST((s.confirmed_time::date - s.apply_time::date)::int, 0)
    ELSE NULL
  END AS confirm_lag_days,

  -- 数量变更
  s.change_number,

  -- 金额变更
  s.before_total_amount,
  s.after_total_amount,
  COALESCE(s.after_total_amount, 0) - COALESCE(s.before_total_amount, 0) AS amount_delta,

  -- 起租期变更
  s.before_settlement_time,
  s.after_settlement_time,
  CASE
    WHEN s.before_settlement_time IS NOT NULL AND s.after_settlement_time IS NOT NULL
      THEN (s.after_settlement_time::date - s.before_settlement_time::date)::int
    ELSE NULL
  END AS settlement_time_delta_days,

  -- 货物变更（before / after）
  s.before_good_price_id,
  s.before_good_name,
  s.before_good_type_raw,
  s.before_good_norms,
  s.before_good_specs,
  s.before_good_unit,
  s.after_good_price_id,
  s.after_good_name,
  s.after_good_type_raw,
  s.after_good_norms,
  s.after_good_specs,
  s.after_good_unit,
  CASE
    WHEN s.before_good_price_id IS NULL AND s.after_good_price_id IS NULL THEN false
    WHEN s.before_good_price_id IS DISTINCT FROM s.after_good_price_id THEN true
    ELSE false
  END AS has_goods_swap,

  -- 月份分桶（按申请时间）
  to_char(s.apply_time, 'YYYY-MM')         AS change_month,
  EXTRACT(YEAR FROM s.apply_time)::int     AS change_year,

  s.remark,
  s.created_by,
  s.created_at,
  s.updated_by,
  s.updated_at,
  now() AS etl_time

FROM normalized s
LEFT JOIN main m
  ON m.biz_id = s.biz_id
LEFT JOIN {{ ref('xycyl_dim_flowerbiz_change_type') }} ct
  ON ct.code = s.change_type
