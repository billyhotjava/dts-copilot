{{ config(materialized='table', tags=['xycyl', 'xycyl-flowerbiz', 'dim', 'dwd']) }}

-- 报花 bizType canonical 维度表（v2: 移除 amount_direction）
-- 真值源: rs_cloud_flower t_flower_biz_info.biz_type
--
-- 关键事实（生产数据画像 2026-05-02 验证）：
--   • biz_total_rent **已自带正负号** — biz_type=3 全负、biz_type=4 正负皆有
--   • biz_total_cost **始终为正** — 不区分方向
--   • total_amount **几乎只对 biz_type=7（售）有值** — 其他场景 NULL
-- 因此 fact 层使用 raw biz_total_rent / biz_total_cost / total_amount 即可，
-- 不需要乘 amount_direction 符号。
--
-- biz_category: 5 类合并 lease/sale/gift/baddebt/material（决策 2）
-- prod_volume: 真实数据中 biz_type 的活跃度，nl2sql/dim_lookup 引用
--   active = 已规模化使用; pilot = 试运行; unused = 0 行

SELECT biztype_id, code, label,
       biz_category,
       is_lease, is_sale, is_gift, is_baddebt, is_material,
       prod_volume,
       sort_order
FROM (VALUES
  ('flowerbiz_biztype_change',     '1',  '换花',     'lease',     true,  false, false, false, false, 'active', 10),
  ('flowerbiz_biztype_add',        '2',  '加花',     'lease',     true,  false, false, false, false, 'active', 20),
  ('flowerbiz_biztype_cut',        '3',  '减花',     'lease',     true,  false, false, false, false, 'active', 30),
  ('flowerbiz_biztype_transfer',   '4',  '调花',     'lease',     true,  false, false, false, false, 'active', 40),
  ('flowerbiz_biztype_baddebt',    '6',  '坏账',     'baddebt',   false, false, false, true,  false, 'active', 50),
  ('flowerbiz_biztype_sale',       '7',  '售花',     'sale',      false, true,  false, false, false, 'active', 60),
  ('flowerbiz_biztype_gift',       '8',  '赠花',     'gift',      false, false, true,  false, false, 'active', 70),
  ('flowerbiz_biztype_material',   '10', '配料',     'material',  false, false, false, false, true,  'active', 80),
  ('flowerbiz_biztype_add_basket', '11', '加盆架',   'material',  false, false, false, false, true,  'pilot',  90),
  ('flowerbiz_biztype_cut_basket', '12', '减盆架',   'material',  false, false, false, false, true,  'unused', 100)
) AS t(biztype_id, code, label,
       biz_category,
       is_lease, is_sale, is_gift, is_baddebt, is_material,
       prod_volume,
       sort_order)
