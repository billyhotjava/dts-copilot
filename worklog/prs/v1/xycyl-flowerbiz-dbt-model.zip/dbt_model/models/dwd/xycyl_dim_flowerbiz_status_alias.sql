{{ config(materialized='table', tags=['xycyl', 'xycyl-flowerbiz', 'dim', 'dwd', 'alias']) }}

-- 报花单状态码别名表: alias_raw → canonical_code
-- 处理 status_raw 中可能出现的多种字面（数字、中文、英文别名）

SELECT alias_raw, canonical_code FROM (VALUES
  ('20',    '20'),
  ('草稿',   '20'),
  ('DRAFT', '20'),

  ('1',          '1'),
  ('审核中',      '1'),
  ('待审核',      '1'),
  ('PENDING_AUDIT','1'),

  ('21',     '21'),
  ('驳回',    '21'),
  ('已驳回',  '21'),
  ('REJECTED','21'),

  ('2',         '2'),
  ('备货中',     '2'),
  ('PICKING',   '2'),

  ('3',           '3'),
  ('核算中',       '3'),
  ('ACCOUNTING',  '3'),

  ('4',                  '4'),
  ('待结算',              '4'),
  ('PENDING_SETTLEMENT', '4'),

  ('5',         '5'),
  ('已结束',     '5'),
  ('已完成',     '5'),
  ('FINISHED',  '5'),

  ('-1',         '-1'),
  ('作废',        '-1'),
  ('已作废',      '-1'),
  ('CANCELLED',  '-1')
) AS t(alias_raw, canonical_code)
