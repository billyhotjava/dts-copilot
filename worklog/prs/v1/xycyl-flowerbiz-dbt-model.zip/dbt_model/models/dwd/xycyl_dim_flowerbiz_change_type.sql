{{ config(materialized='table', tags=['xycyl', 'xycyl-flowerbiz', 'dim', 'dwd']) }}

-- 变更类型 canonical 维度表（v2: 真实只有 3 个值，非 4 个）
-- 真值源: rs_cloud_flower t_change_info.change_type
--
-- 通过字段分布推断语义（2026-05-02 production 数据画像）：
--   1: 纯金额变更        — 4 行（仅有 before/after_total_amount，无货物）
--   2: 货物变更          — 1139 行（has_goods=1139, has_goods_change=1129）— 96.5% 都是这种
--   3: 同货物金额变更    — 24 行（has_goods=24 但 has_goods_change=0，金额变化）
--
-- 注意：起租期变更走 t_flower_rent_time_log，不在 change_info 里

SELECT change_type_id, code, label,
       is_amount_only, is_goods_change, is_rate_change,
       prod_volume,
       sort_order
FROM (VALUES
  ('flowerbiz_change_type_amount_only',  '1', '金额变更',         true,  false, false, 'rare',   10),
  ('flowerbiz_change_type_goods',        '2', '货物变更',         false, true,  false, 'common', 20),
  ('flowerbiz_change_type_rate',         '3', '同货物金额调整',   false, false, true,  'rare',   30)
) AS t(change_type_id, code, label,
       is_amount_only, is_goods_change, is_rate_change,
       prod_volume,
       sort_order)
