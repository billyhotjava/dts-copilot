{{ config(materialized='table', tags=['xycyl', 'xycyl-flowerbiz', 'dwd', 'biz', 'flowerbiz_main']) }}

-- 报花单主表事实层（v2: 列名/口径全面对齐生产；移除 amount_direction 重复加签）
-- 三段论：normalized → derived → final
--
-- 关键事实（生产数据画像 2026-05-02）：
--   • biz_total_rent **已自带正负号**（biz_type=3 全负，4 正负皆有）
--   • biz_total_cost **始终为正**（绝对值口径）
--   • total_amount **几乎只对 biz_type=7（售）有值**
--   • start_lease_time 仅 biz_type 2/3/4 有值（24.7% 总覆盖率）；其它走 apply_time
--   • 6.4% start_lease_time 被 t_flower_rent_time_log 事后修改（DWS 取当前值）

WITH stg AS (
  SELECT * FROM {{ ref('xycyl_stg_flower_biz_info') }}
),
normalized AS (
  SELECT
    s.*,
    bta.canonical_code AS biz_type,
    sa.canonical_code  AS status
  FROM stg s
  LEFT JOIN {{ ref('xycyl_dim_flowerbiz_biztype_alias') }} bta
    ON bta.alias_raw = s.biz_type_raw
  LEFT JOIN {{ ref('xycyl_dim_flowerbiz_status_alias') }} sa
    ON sa.alias_raw = s.status_raw
),
derived AS (
  SELECT
    n.*,
    -- 业务时间 = COALESCE(start_lease_time, apply_time)
    COALESCE(n.start_lease_time, n.apply_time) AS business_date,
    to_char(COALESCE(n.start_lease_time, n.apply_time), 'YYYY-MM') AS biz_month,
    EXTRACT(YEAR FROM COALESCE(n.start_lease_time, n.apply_time))::int AS biz_year,
    EXTRACT(QUARTER FROM COALESCE(n.start_lease_time, n.apply_time))::int AS biz_quarter,

    -- 4 列分类金额（v2 替代 amount_signed/amount_abs）
    -- 核心：biz_total_rent 已是有符号；DWS 直接 SUM 即可
    COALESCE(n.biz_total_rent, 0)  AS rent_amount,        -- 租金净额（含正负号）
    COALESCE(n.biz_total_cost, 0)  AS cost_amount,        -- 处理成本（绝对值）
    COALESCE(n.total_amount, 0)    AS sale_amount,        -- 销售总价（仅 biz_type=7 有意义）
    COALESCE(n.total_extra_cost, 0) + COALESCE(n.fare, 0) + COALESCE(n.labor_cost, 0) + COALESCE(n.cleaning_fee, 0) AS extra_cost_amount,

    -- 在途天数（基于 apply_time，业务请求日开始计算）
    CASE
      WHEN n.status_raw IN ('5','-1','21') THEN 0
      WHEN n.apply_time IS NULL THEN 0
      ELSE GREATEST((current_date - n.apply_time::date)::int, 0)
    END AS pending_days,

    -- 审批耗时（apply → finish）
    CASE
      WHEN n.apply_time IS NOT NULL AND n.finish_time IS NOT NULL
        THEN GREATEST((n.finish_time::date - n.apply_time::date)::int, 0)
      ELSE NULL
    END AS approval_days
  FROM normalized n
)

SELECT
  -- ─── 业务键 ───
  d.biz_id,
  d.biz_code,
  d.biz_title,
  d.batch_code,
  d.source_row_id,
  d.source_table,
  d.source_system,
  d.imported_at AS source_imported_at,

  -- ─── 项目/客户（反范式） ───
  d.project_id,
  d.project_name,
  d.customer_name,
  d.customer_phone,
  d.customer_address,
  d.tenant_id,

  -- ─── 人员链 ───
  d.apply_user_id,
  d.apply_user_name,
  d.examine_user_id,
  d.examine_user_name,
  d.review_user_id,
  d.review_user_name,
  d.sign_user_id,
  d.sign_user_name,
  d.reject_user_id,
  d.reject_user_name,
  d.curing_user_id,
  d.curing_user_name,
  d.project_manage_id,
  d.project_manage_name,
  d.biz_manage_id,
  d.biz_manage_name,

  -- ─── bizType（归一化 + 维度） ───
  d.biz_type_raw,
  d.biz_type,
  bt.biztype_id,
  bt.label                        AS biz_type_label,
  bt.biz_category,
  COALESCE(bt.is_lease, false)    AS is_lease_biz,
  COALESCE(bt.is_sale, false)     AS is_sale_biz,
  COALESCE(bt.is_gift, false)     AS is_gift_biz,
  COALESCE(bt.is_baddebt, false)  AS is_baddebt_biz,
  COALESCE(bt.is_material, false) AS is_material_biz,

  -- ─── 状态（归一化 + 维度） ───
  d.status_raw,
  d.status,
  st.status_id,
  st.label                                  AS status_label,
  COALESCE(st.is_draft, false)              AS is_draft,
  COALESCE(st.is_pending_audit, false)      AS is_pending_audit,
  COALESCE(st.is_rejected, false)           AS is_rejected,
  COALESCE(st.is_picking, false)            AS is_picking,
  COALESCE(st.is_accounting, false)         AS is_accounting,
  COALESCE(st.is_pending_settlement, false) AS is_pending_settlement,
  COALESCE(st.is_finished, false)           AS is_finished,
  COALESCE(st.is_cancelled, false)          AS is_cancelled,
  COALESCE(st.is_in_progress, false)        AS is_in_progress,

  -- ─── 业务子分类 raw ───
  d.urgent_raw,
  d.bad_debt_type_raw,
  d.transfer_type_raw,
  d.source_type_raw,
  d.bear_cost_type_raw,
  d.sales_payment_type_raw,
  d.changer_type_raw,
  d.change_flower_type_raw,
  d.rent_update_type_raw,
  d.accounting_status_raw,
  d.cut_confirm_status_raw,
  d.print_status_raw,

  -- ─── 金额（4 列 — 替代 amount_signed/abs） ───
  d.rent_amount,
  d.cost_amount,
  d.sale_amount,
  d.extra_cost_amount,
  d.biz_total_rent,                                      -- raw fallback
  d.biz_total_cost,
  d.total_amount,
  d.total_extra_cost,
  d.total_extra_price,
  d.fare,
  d.labor_cost,
  d.cleaning_fee,
  d.tax_rate,
  d.rent_discount_ratio,
  d.lease_term,

  -- ─── 时间链 ───
  d.apply_time,
  d.examine_time,
  d.review_time,
  d.sign_time,
  d.reject_time,
  d.start_lease_time,
  d.plan_finish_time,
  d.cut_confirm_time,
  d.settlement_time,
  d.finish_time,
  d.document_finish_time,
  d.business_date,
  d.biz_year,
  d.biz_quarter,
  d.biz_month,

  -- ─── 派生指标 ───
  d.pending_days,
  d.approval_days,

  -- ─── 财务/任务挂钩（sprint-25 接） ───
  d.expense_id,
  d.expense_code,
  d.settle_id,
  d.settle_code,
  d.task_info_id,
  d.task_item_id,
  d.task_code,

  -- ─── 备注 ───
  d.remark,
  d.give_describe,
  d.sale_describe,
  d.reject_reason,
  d.back_reason,

  -- ─── 元数据 ───
  d.created_by,
  d.created_at,
  d.updated_by,
  d.updated_at,
  now() AS etl_time

FROM derived d
LEFT JOIN {{ ref('xycyl_dim_flowerbiz_biztype') }} bt
  ON bt.code = d.biz_type
LEFT JOIN {{ ref('xycyl_dim_flowerbiz_status') }} st
  ON st.code = d.status
