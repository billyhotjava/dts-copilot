{{ config(materialized='table', tags=['xycyl', 'xycyl-flowerbiz', 'dim', 'dwd', 'alias']) }}

-- 变更类型别名表（v2: 真实仅 1/2/3 三个值，移除 4）
-- 1=纯金额变更 / 2=货物变更 / 3=同货物比率调整

SELECT alias_raw, canonical_code FROM (VALUES
  ('1',         '1'),
  ('金额',       '1'),
  ('纯金额',     '1'),
  ('销售金额',   '1'),
  ('AMOUNT',    '1'),

  ('2',         '2'),
  ('货物',       '2'),
  ('货物变更',   '2'),
  ('物品类型',   '2'),
  ('库房物品类型','2'),
  ('GOODS',     '2'),

  ('3',         '3'),
  ('比率',       '3'),
  ('比率调整',   '3'),
  ('成本',       '3'),
  ('RATE',      '3')
) AS t(alias_raw, canonical_code)
