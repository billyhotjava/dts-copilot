{{ config(materialized='table', tags=['xycyl', 'xycyl-flowerbiz', 'dim', 'dwd', 'alias']) }}

-- 报花 bizType 别名表: alias_raw → canonical_code
-- 收录 13 bizType 的常见中文/英文/同义词写法
-- 业务用语见 assets/flowerbiz-source-catalog.md §二

SELECT alias_raw, canonical_code FROM (VALUES
  ('1',     '1'),
  ('换花',   '1'),
  ('CHANGE','1'),

  ('2',     '2'),
  ('加花',   '2'),
  ('加摆',   '2'),
  ('增订',   '2'),
  ('ADD',   '2'),

  ('3',    '3'),
  ('减花',  '3'),
  ('撤摆',  '3'),
  ('退订',  '3'),
  ('CUT',  '3'),

  ('4',         '4'),
  ('调花',       '4'),
  ('调拨',       '4'),
  ('TRANSFER',  '4'),

  ('6',         '6'),
  ('坏账',       '6'),
  ('死账',       '6'),
  ('BADDEBT',   '6'),

  ('7',     '7'),
  ('售花',   '7'),
  ('销售',   '7'),
  ('卖花',   '7'),
  ('SALE',  '7'),

  ('8',     '8'),
  ('赠花',   '8'),
  ('赠送',   '8'),
  ('GIFT',  '8'),

  ('10',         '10'),
  ('配料',        '10'),
  ('辅料',        '10'),
  ('MATERIAL',   '10'),

  ('11',          '11'),
  ('加盆架',       '11'),
  ('增盆架',       '11'),
  ('ADD_BASKET',  '11'),

  ('12',          '12'),
  ('减盆架',       '12'),
  ('撤盆架',       '12'),
  ('CUT_BASKET',  '12')
) AS t(alias_raw, canonical_code)
