{{ config(materialized='table', tags=['xycyl', 'xycyl-flowerbiz', 'dim', 'dwd']) }}

-- 报花单状态码 canonical 维度表
-- 真值源: rs_cloud_flower t_flower_biz_info.status
-- 业务含义见 sprint-22 assets/flowerbiz-source-catalog.md §一 生命周期总览

SELECT status_id, code, label,
       is_draft, is_pending_audit, is_rejected, is_picking,
       is_accounting, is_pending_settlement, is_finished, is_cancelled,
       is_in_progress,
       sort_order
FROM (VALUES
  ('flowerbiz_status_draft',              '20', '草稿',     true,  false, false, false, false, false, false, false, true,  10),
  ('flowerbiz_status_pending_audit',      '1',  '审核中',   false, true,  false, false, false, false, false, false, true,  20),
  ('flowerbiz_status_rejected',           '21', '驳回',     false, false, true,  false, false, false, false, false, true,  30),
  ('flowerbiz_status_picking',            '2',  '备货中',   false, false, false, true,  false, false, false, false, true,  40),
  ('flowerbiz_status_accounting',         '3',  '核算中',   false, false, false, false, true,  false, false, false, true,  50),
  ('flowerbiz_status_pending_settlement', '4',  '待结算',   false, false, false, false, false, true,  false, false, true,  60),
  ('flowerbiz_status_finished',           '5',  '已结束',   false, false, false, false, false, false, true,  false, false, 70),
  ('flowerbiz_status_cancelled',          '-1', '作废',     false, false, false, false, false, false, false, true,  false, 99)
) AS t(status_id, code, label,
       is_draft, is_pending_audit, is_rejected, is_picking,
       is_accounting, is_pending_settlement, is_finished, is_cancelled,
       is_in_progress, sort_order)
