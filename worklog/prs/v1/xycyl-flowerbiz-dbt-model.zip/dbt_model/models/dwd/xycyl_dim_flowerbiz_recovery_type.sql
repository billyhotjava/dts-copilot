{{ config(materialized='table', tags=['xycyl', 'xycyl-flowerbiz', 'dim', 'dwd']) }}

-- 回收类型 canonical 维度表
-- 真值源: rs_cloud_flower t_recovery_info_item.recovery_type

SELECT recovery_type_id, code, label,
       is_loss, is_buyback, is_keep,
       sort_order
FROM (VALUES
  ('flowerbiz_recovery_type_loss',    '1', '报损', true,  false, false, 10),
  ('flowerbiz_recovery_type_buyback', '2', '回购', false, true,  false, 20),
  ('flowerbiz_recovery_type_keep',    '3', '留用', false, false, true,  30)
) AS t(recovery_type_id, code, label,
       is_loss, is_buyback, is_keep, sort_order)
