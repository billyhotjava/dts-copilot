{{ config(materialized='table', tags=['xycyl', 'xycyl-flowerbiz', 'dim', 'dwd', 'alias']) }}

SELECT alias_raw, canonical_code FROM (VALUES
  ('1',     '1'),
  ('报损',   '1'),
  ('损失',   '1'),
  ('LOSS',  '1'),

  ('2',        '2'),
  ('回购',      '2'),
  ('回收回购',   '2'),
  ('BUYBACK',  '2'),

  ('3',     '3'),
  ('留用',   '3'),
  ('KEEP',  '3')
) AS t(alias_raw, canonical_code)
