{{ config(materialized='table', tags=['xycyl', 'xycyl-flowerbiz', 'dim', 'dwd']) }}

-- 报花额外费用类型 canonical 维度（v2: 据真实 title 分布修正语义）
-- 真值源: rs_cloud_flower t_flower_extra_cost.cost_type
-- 生产数据画像 2026-05-02:
--   1=运费 (380), 2=人工费 (27), 3=其他费用-旧 (3), 4=其他费用 (162), 5=垃圾清理费 (2)
-- 备注: cost_type=3 与 4 都标 title="其他费用"，3 是历史值，4 是当前规范值

SELECT cost_type_id, code, label,
       is_freight, is_labor, is_other, is_garbage,
       prod_volume,
       sort_order
FROM (VALUES
  ('flowerbiz_cost_type_freight',     '1', '运费',           true,  false, false, false, 'common', 10),
  ('flowerbiz_cost_type_labor',       '2', '人工费',         false, true,  false, false, 'rare',   20),
  ('flowerbiz_cost_type_other_legacy','3', '其他费用（旧）', false, false, true,  false, 'legacy', 30),
  ('flowerbiz_cost_type_other',       '4', '其他费用',       false, false, true,  false, 'common', 40),
  ('flowerbiz_cost_type_garbage',     '5', '垃圾清理费',     false, false, false, true,  'rare',   50)
) AS t(cost_type_id, code, label,
       is_freight, is_labor, is_other, is_garbage,
       prod_volume,
       sort_order)
