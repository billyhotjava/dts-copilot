{{ config(materialized='table', tags=['xycyl', 'xycyl-flowerbiz', 'dim', 'dwd', 'alias']) }}

-- 报花额外费用类型别名表（v2: 对齐生产真实分布与 title 对应）
-- 1=运费 / 2=人工费 / 3=其他费用-旧 / 4=其他费用 / 5=垃圾清理费

SELECT alias_raw, canonical_code FROM (VALUES
  ('1',          '1'),
  ('运费',        '1'),
  ('物流费',      '1'),
  ('FREIGHT',    '1'),

  ('2',          '2'),
  ('人工费',      '2'),
  ('人工',        '2'),
  ('人工费用',    '2'),
  ('LABOR',      '2'),

  ('3',          '3'),
  ('其他费用-旧', '3'),

  ('4',          '4'),
  ('其他',        '4'),
  ('其他费用',    '4'),
  ('OTHER',      '4'),

  ('5',          '5'),
  ('垃圾清理',    '5'),
  ('垃圾清理费',  '5'),
  ('清理费',      '5'),
  ('GARBAGE',    '5')
) AS t(alias_raw, canonical_code)
